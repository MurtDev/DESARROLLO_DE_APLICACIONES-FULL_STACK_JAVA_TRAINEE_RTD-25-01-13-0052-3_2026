package interfaces;

public interface Vacunable {
	String TIPO_VACUNA = "ANTIRRÁBICA";//Java agrega el public static final de forma automática
	public static final int DOSIS_ANUALES = 1;//solo ejemplo con public static final 
	
	void vacunar();//Java agrega public abstract de forma automática
	public abstract boolean estaVacunado();//solo ejemplo con public abstract
}

/*
 La regla general para nombres

En Java, las interfaces suelen nombrarse con un adjetivo 
o una palabra que describa una capacidad, normalmente terminada en:

-able
-ible
-dor / -ora (en español)

Porque responden a la pregunta:
¿Qué puede hacer o qué capacidad tiene este objeto?

| Interfaz       | Significado        |
| -------------- | ------------------ |
| `Vacunable`    | Puede vacunarse    |
| `Imprimible`   | Puede imprimirse   |
| `Comparable`   | Puede compararse   |
| `Serializable` | Puede serializarse |
| `Volador`      | Puede volar        |
| `Nadador`      | Puede nadar        |
| `Recargable`   | Puede recargarse   |
| `Pagable`      | Puede pagarse      |
| `Editable`     | Puede editarse     |
| `Exportable`   | Puede exportarse   |

 */

/*
 
9. Comparación

| Clase Abstracta                   | Interfaz                             |
| --------------------------------- | ------------------------------------ |
| Representa qué es un objeto       | Representa qué puede hacer           |
| Puede tener atributos             | No almacena estado del objeto        |
| Tiene constructor                 | No tiene constructor                 |
| Puede tener métodos implementados | Declara comportamientos obligatorios |
| Se utiliza con `extends`          | Se utiliza con `implements`          |
 
 */
