package interfaces;

public interface Domesticable {
	int EDAD_MAXIMA_DOMESTICACION = 10;
	String TIPO_IDEDNTIFICACION = "Microchip";
	
	void domesticar();
	boolean estaDomesticado();
	void jugar();
}
