package model;

public abstract class Animal {
	protected String nombre;
	protected double peso;
	protected int edad;
	
	//Constructor
	public Animal(String nombre, double peso, int edad) {
		this.nombre = nombre;
		this.peso = peso;
		this.edad = edad;
	}
	
	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}
		
	public abstract void comer();
	
	public void dormir() {
		System.out.println("El animal está durmiendo");
	}
	
	/*Métodos abstractos
	 * 
	 ¿Qué son y para qué se utilizan?:
	Un método abstracto para Java es un método que nunca va a ser ejecutado
	porque no tiene cuerpo . Simplemente, un método abstracto referencia a otros
	métodos de las subclases.
	¿Qué utilidad tiene un método abstracto? Podemos ver un método abstracto como una
	palanca que fuerza dos cosas: la primera, que no se puedan crear objetos de una
	clase . La segunda, que todas las subclases sobreescriban el método declarado
	como abstracto.*/
	public abstract String emitirSonido();//--> Animal obliga a todas las clases hijas a implementar ese método
	
	
	public void mostrarInformación() {
		System.out.printf("Nombre: %s %nPeso: %.2f kg%n", nombre, peso);
	}
}
