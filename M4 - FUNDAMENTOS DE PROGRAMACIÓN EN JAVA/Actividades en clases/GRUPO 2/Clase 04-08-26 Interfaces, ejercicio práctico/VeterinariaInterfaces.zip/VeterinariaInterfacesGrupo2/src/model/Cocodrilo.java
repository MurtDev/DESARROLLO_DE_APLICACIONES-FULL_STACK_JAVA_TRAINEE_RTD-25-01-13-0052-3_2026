package model;

public class Cocodrilo extends Animal {
	private int cantidadDientes;
	private String tipoMordida;
	
	
	public Cocodrilo(String nombre, double peso, int cantidadDientes, String tipoMordida, int edad) {
		super(nombre, peso, edad);
		this.cantidadDientes = cantidadDientes;
		this.tipoMordida = tipoMordida;
	}

	@Override
	public String emitirSonido() {
		return "¡grrr... grrr!";
	}
	
	@Override
	public void comer() {
		System.out.println("ñam ñam El cocodrilo está comiendo");		
	}
	
	public int getCantidadDientes() {
		return cantidadDientes;
	}


	public void setCantidadDientes(int cantidadDientes) {
		this.cantidadDientes = cantidadDientes;
	}


	public String getTipoMordida() {
		return tipoMordida;
	}


	public void setTipoMordida(String tipoMordida) {
		this.tipoMordida = tipoMordida;
	}
	
	
	
}
