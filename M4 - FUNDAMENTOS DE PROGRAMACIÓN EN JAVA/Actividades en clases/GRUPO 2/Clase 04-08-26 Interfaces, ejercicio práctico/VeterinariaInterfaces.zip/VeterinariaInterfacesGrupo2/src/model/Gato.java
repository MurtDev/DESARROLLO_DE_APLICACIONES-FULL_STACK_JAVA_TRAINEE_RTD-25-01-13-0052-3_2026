package model;

import interfaces.*;

public class Gato extends Animal implements Vacunable, Domesticable{
	private String raza;
	private String color;
	private boolean vacunado;
	private boolean domesticado;
	
	public Gato(String nombre, double peso, String raza, String color, int edad) {
		super(nombre, peso, edad);
		this.raza = raza;
		this.color = color;
	}
	
	@Override
	public void vacunar() {
		vacunado = true;
		
		System.out.printf(
				"%s ha sido vacunado con la vacuna %s %nDosis anual recomendada: %d %n", 
				nombre, 
				Vacunable.TIPO_VACUNA,
				Vacunable.DOSIS_ANUALES);
		
	}
	
	@Override
	public boolean estaVacunado() {
		return vacunado;
	}
	

	@Override
	public void domesticar() {
		
		if(edad <= Domesticable.EDAD_MAXIMA_DOMESTICACION) {
		
			domesticado = true;
		
			System.out.printf(
					"%s ha sido domesticado. Tipo de identificación %s%n", 
					getNombre(), 
					Domesticable.TIPO_IDEDNTIFICACION
					);
			return; 
		} 
		
		System.out.printf("La edad de %s supera la edad máxima de domesticación%n", nombre);
		
	}
	
	@Override
	public boolean estaDomesticado() {
		return domesticado;
	}
	
	@Override
	public void jugar() {
		System.out.printf("%s esta jugando con una lana...%n", nombre);
	}

	
	public String getRaza() {
		return raza;
	}

	public void setRaza(String raza) {
		this.raza = raza;
	}
	
	@Override
	public void mostrarInformación() {
		super.mostrarInformación();
		System.out.printf("Raza: %s %nColor: %s", raza, color);
	}

	
	@Override
	public String emitirSonido() {
		return "Miaaaauu!! Miaaaauu!!";
	}
	
	@Override
	public void comer() {
		System.out.println("El gato está comiendo ratones");		
	}
}
