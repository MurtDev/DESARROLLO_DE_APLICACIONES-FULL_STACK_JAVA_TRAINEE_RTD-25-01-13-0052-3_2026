package app;

import model.Gato;
import model.Perro;

import java.util.ArrayList;

import interfaces.Vacunable;
//import model.*;
import model.Animal;
import model.Cocodrilo;

public class Main {
		
	//Perro firulais
	public static void presentarAnimal(Animal animal) {
		System.out.println("Nombre: " + animal.getNombre());
		System.out.println("Peso: " + animal.getPeso());
		//System.out.println("Color: " + animal.getColor()); no podemos hacerlo, animal no tiene getColor solo Gato
		System.out.println("Sonido: " + animal.emitirSonido());
	}
	
	/*Sin polimorfismo tendríamos que crear métodos separados para acada animal
	 presentarPerro(Perro perro)
	 presentarGato(Gato gato)
	 presentarCaballo(Caballo caballo)
	 presentarConejo(Conejo conejo)
	 presentarAve(Ave ave)
	 presentarPorcino(Porcino porcino)
	 
	 
	 con Polimorfismo hacemos
	 
	 presentarAnimal(Animal animal) --> perro, gato, caballo, conejo, ave, porcino
	 */
	
	public static void vacunarPaciente(Vacunable paciente) {
		paciente.vacunar();
	}
	
	public static void main(String[] args) {
		
		Perro firulais = new Perro("Firulais", 14.4, "Labrador", 4);
		
		firulais.mostrarInformación();
		firulais.comer();
		firulais.dormir();
		System.out.println(firulais.emitirSonido());
		System.out.println(firulais.getRaza());
		
		System.out.println(firulais.estaVacunado());
		
		vacunarPaciente(firulais);
		
		System.out.println(firulais.estaVacunado());
		
		System.out.println("Esta domesticado: " + firulais.estaDomesticado());
		firulais.domesticar();
		System.out.println("Esta domesticado: " + firulais.estaDomesticado());
		firulais.jugar();
		
		System.out.println("-----------------");
		Gato gatuno = new Gato("Gatuno", 8.4, "Angora", "gris", 12);
		gatuno.mostrarInformación();
		gatuno.comer();
		gatuno.dormir();
		System.out.println(gatuno.emitirSonido());
		
		System.out.println("Esta domesticado: " + gatuno.estaDomesticado());
		gatuno.domesticar();
		System.out.println("Esta domesticado: " + gatuno.estaDomesticado());
		gatuno.jugar();
		
		vacunarPaciente(gatuno);
				
				
		System.out.println("-------------------------------------");
		Cocodrilo coco = new Cocodrilo("Coco", 50.0, 32, "Fuerte", 17);
		
		presentarAnimal(coco);
		
		//vacunarPaciente(coco); --> No lo pedemos  hacer, ya que coco el cocodrilo no es vacunable
		//no implementa la interface vacunable
		
		
		
	}

}
