package Clase_13_07_26;

public class Estructuras_repetitivas_11 {

	public static void main(String[] args) {
		//***************** Estructuras  Repetitivas**************
		/*
		¿Qué es una estructura repetitiva?

		Antes de escribir código, plantea una situación cotidiana.

		Pregunta

		Si quiero imprimir mi nombre 100 veces, ¿debería escribir System.out.println() 100 veces?

		La respuesta es no.

		Las estructuras repetitivas permiten ejecutar un mismo bloque de código varias veces sin tener que escribirlo repetidamente.
		*/
		
		System.out.println("1");
		System.out.println("2");
		System.out.println("3");
		System.out.println("4");
		System.out.println("5");
		System.out.println("10");
		System.out.println("20");
		System.out.println("30");
		System.out.println("40");
		System.out.println("90");
		System.out.println("99");
		System.out.println("100");
		
		//1. While
		/*Definición

		El ciclo while ejecuta un bloque de código mientras una 
		condición sea verdadera.
		Primero verifica la condición y luego ejecuta el bloque.
		Si la condición es falsa desde el inicio, nunca entra al ciclo.*/
		
		//Sintaxis
		/*
		while (condición) {

		    instrucciones;

		}
		*/
		int contador = 1;
		        
		        // 101   <= 100 --> false
		while (contador <= 100){
			System.out.println(contador);//--> 100
			contador++;//101
		}	
		
		//Error común olvidar incrementar la variable para verificar la condición
		
		
		/*2. do-while 
		El ciclo do-while ejecuta el bloque al menos una vez, porque la condición se evalúa al final.
		 */

		/* Sintaxis
		do {
		
		    instrucciones;
		
		} while (condición);
		*/
		System.out.println("------------------------");
		int contador2 = 1;
		
		do {
			System.out.println(contador2);
			contador2++;
			
		} while (contador2 <= 100);
			

		/*
		
		¿Cuándo usar do-while?
		
		Cuando una acción debe ejecutarse al menos una vez.
		
		Ejemplos:
		
		Menús.
		Validación de datos.
		Juegos.
		*/
		
		
		/*3. for
		El ciclo for se utiliza cuando sabemos cuántas veces queremos repetir una acción.*/
		
		//Sintaxis
		/*
		for (inicio; condición; incremento) {
		
		    instrucciones;
		
		}*/
		
		for (int indice = 1; indice <= 10; indice++) {
			System.out.println(indice);
		} 
		
		
		//4. for-each
		//Sintaxis
		/*
		for (Tipo variable : colección) {

		}
		*/
				//Posiciones  0       1        2
		String[] nombres = {"Ana", "Pedro", "Juan"};//Cantidad de elementos 3
	
		//Ejemplo  con variios tipos de datos
		 // Declaramos e inicializamos un array de tipo Object
        /*Object[] miArray = new Object[4];

        miArray[0] = "Hola mundo"; // String
        miArray[1] = 42;          // Integer (Autoboxing)
        miArray[2] = 3.1416;      // Double (Autoboxing)
        miArray[3] = true;        // Boolean (Autoboxing)*/
		
		for (String nombre : nombres) {
			System.out.println(nombre);
		}
		
		//Comparación con for tradicional
		for (int indice = 0; indice < nombres.length; indice++) {
			System.out.println(nombres[indice]);
		}
		
		

		/*¿Cuándo usar for-each?
		
		Cuando solo necesitas leer los elementos y no utilizar su posición (índice).*/

	   //Break en bucles
		for (int i=1; i<=10; i++) {
			System.out.println("Inicio del bucle");
			if (i == 6) {
				System.out.println("Encontre el número " + i);
				break;
			}else {
				System.out.println("No encontre el número");
			}
			System.out.println(i);
		}
		
		//continue
		for (int i=1; i<=10; i++) {
			System.out.println("Inicio del bucle");
			if (i == 6) {
				System.out.println("Encontre el número " + i);
				continue;
			}else {
				System.out.println("No encontre el número");
			}
			System.out.println(i);
			System.out.println("Fin del bucle");
		}
		

		//¿Cuándo utilizar cada ciclo?

		/* 

		| Estructura | ¿Cuándo utilizarla?                                     | Ejemplo                                        |
		| ---------- | ------------------------------------------------------- | ---------------------------------------------- |
		| `while`    | No sabes cuántas veces se repetirá.                     | Validar una contraseña hasta que sea correcta. |
		| `do-while` | Debe ejecutarse al menos una vez.                       | Menús interactivos.                            |
		| `for`      | Sabes cuántas repeticiones habrá.                       | Imprimir los números del 1 al 100.             |
		| `for-each` | Recorrer todos los elementos de un arreglo o colección. | Mostrar una lista de nombres.                  |

		*/

		
	
	}

}
