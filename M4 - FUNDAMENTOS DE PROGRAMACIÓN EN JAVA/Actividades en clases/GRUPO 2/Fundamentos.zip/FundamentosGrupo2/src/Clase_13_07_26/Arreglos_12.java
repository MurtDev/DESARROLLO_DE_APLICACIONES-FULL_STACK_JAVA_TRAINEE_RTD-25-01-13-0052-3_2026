package Clase_13_07_26;

import java.util.Scanner;

public class Arreglos_12 {

	public static void main(String[] args) {
		//********************** Arreglos en Java **************
	
	/*
	¿Qué es un arreglo?:
	Un arreglo, también conocido como array , es una estructura de datos que puede
	almacenar una colección de elementos del mismo tipo . En Java, los arrays tienen un
	tamaño fijo que se define en el momento de su creación. Cada elemento del array se puede
	acceder mediante un índice numérico que representa su posición en el array.
	
	Para declarar un array en Java, debes especificar su tipo y su tamaño:
	
	int[] numeros = new int[4];
	
	Los corchetes indican que esta variable es del tipo arreglo y el prefijo int informa que
	almacenará números enteros. Además, especificamos su tamaño en 4 espacios.
	*/
	
	int[] numeros = new int[4];// Declaración sin inicialización
	
	
	numeros[3] = 10;
	numeros[0] = 20;
	numeros[2] = 30;
	numeros[1] = 40;
	
	for (int numero : numeros) {
		System.out.println(numero);
	}
	
	//Declaración e inicialización 
	int[] numeros2 = {10,  20, 30, 40};
	
	System.out.println("Largo del array2 " + numeros2.length);
	
	System.out.println("Elementoel la última posición " + numeros2[numeros2.length - 1]);
	
	//la última posición siempre será:
	//numeros2.length - 1
	
	//Recorrer un arreglo con for
	for (int indice = 0; indice <= numeros2.length - 1; indice++) {
		System.out.println(numeros2[indice]);
	}
	

	//2. Calcular promedio
	double[] notas = {5.5, 6.0, 4.8, 6.5};

	double suma = 0;

	for (double nota : notas) {
	    suma += nota;
	}

	double promedio = suma / notas.length;

	System.out.println("Promedio: " + promedio);

	//3. Buscar el Mayor
	int[] numeros3 = {18, 7, 35, 22, 10};

	int mayor = numeros3[0];

	for (int i = 1; i < numeros3.length; i++) {

	    if (numeros3[i] > mayor) {
	        mayor = numeros3[i];
	    }
	}

	System.out.println("El número mayor es: " + mayor);

	//4. Entrada por teclado
	/*Scanner teclado = new Scanner(System.in);
	double[] notas2 = new double[4];

	for (int i = 0; i < notas2.length; i++) {
	    System.out.print("Ingrese la nota " + (i + 1) + ": ");
	    notas2[i] = teclado.nextDouble();
	}

	System.out.println("\nNotas registradas:");

	for (int i = 0; i < notas.length; i++) {
	    System.out.println("Nota " + (i + 1) + ": " + notas[i]);
	}

	teclado.close();
	
	*/
	
	//***** Arreglos bidimensionales

	/*
	Matrices:
	Los arreglos bidimensionales o matrices tienen el mismo tratamiento que los arrays. La
	diferencia de sintaxis se centra en la creación:

	Declaración y creación de una Matriz

	int[][] arregloM = new int [Filas][Columnas] ;

	De esta manera podemos crear dos dimensiones diferentes para el mismo arreglo, es por esto
	que lleva dos corchetes.
	*/

	/*
	Esto crea una matriz con:

	2 filas.
	3 columnas.
	*/
	
	
	int[][] matriz = new int[2][3];
	
	matriz[0][0] = 10;
	matriz[0][1] = 20;
	matriz[0][2] = 30;
	
	matriz[1][0] = 10;
	matriz[1][1] = 20;
	matriz[1][2] = 30;
	
	//Declaración e inicialización 
	
	int[][] numeros4 = {
			{10, 20, 30},//[0][1] --> 20
			{40, 50, 60}//[1][2] --> 60
	};
	
	//Obtener la cantidad de fila
	//numeros4.length
	
	//Obtener la cantidad de columnas
	//numeros4[fila].length
	
	//Recorrer una matriz con for
	System.out.println("-------------- MATRIZ 2 -----------");
	for (int fila = 0; fila <= numeros4.length-1; fila++) {
		System.out.println("Iteración fila: " + fila);
		
		for (int columna = 0; columna <= numeros4[fila].length-1; columna++) {
			System.out.println("Iteración columna: " + columna);
			System.out.printf("[%d][%d] --> %d %n",fila, columna, numeros4[fila][columna]);
		}
	}
	

	
	
	
	
	
	}

}
