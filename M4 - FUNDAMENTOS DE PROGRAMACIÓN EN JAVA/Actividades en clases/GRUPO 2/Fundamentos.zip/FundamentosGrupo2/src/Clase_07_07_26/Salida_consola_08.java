package Clase_07_07_26;

public class Salida_consola_08 {

	public static void main(String[] args) {
		//********************** Salida por consola ****************
		/*
		¿Qué es la salida por consola?

		La salida por consola consiste en mostrar información al usuario 
		a través de la ventana de la terminal o consola.

		Es una de las formas más simples de interactuar con el usuario y 
		resulta muy útil para:

		Mostrar resultados.
		Verificar el contenido de variables.
		Depurar programas.
		Mostrar mensajes e instrucciones.

		En Java, la salida por consola se realiza utilizando el objeto System.out.


		System es una clase que forma parte de la biblioteca estándar de Java.
		Su función es proporcionar acceso a recursos importantes del sistema, como:

		La consola.
		La fecha y hora.
		Variables del sistema.
		Manejo de memoria.
		Finalización de programas.

		En otras palabras:

		System actúa como un puente entre nuestro programa y el sistema operativo.
		*/
		
		//1. print()
		//El método print() imprime información sin realizar un salto de línea
		System.out.print("Hola mundo 🌎");
		System.out.print("Hola mundo2 🌎");
		
		//2. println()
		//El método println() imprime información con un salto de línea
		System.out.println("");
		System.out.println("Hola mundo3 🌎");
		System.out.println("Hola mundo4 🌎");
		
		//3. printf
		/*
		El método printf() permite mostrar información con un formato específico.

		Es muy útil para:

		Mostrar tablas.
		Limitar decimales.
		Alinear información.
		Insertar variables dentro de un texto.
		*/
		
		//Especificadores de formato

		/*
		| Especificador | Tipo de dato                             | Ejemplo     |
		| ------------- | ---------------------------------------- | ----------- |
		| %d            | Enteros (byte, short, int, long)         | 25          |
		| %f            | Decimales (float, double)                | 3.14        |
		| %c            | Carácter (char)                          | A           |
		| %s            | Cadenas (String)                         | "Hola"      |
		| %b            | Boolean                                  | true        |
		| %n            | Salto de línea                           | Nueva línea |

		*/
		
		String nombre = "María";
		int edad = 28;
		double promedio = 6.45;
		char curso = 'A';
		boolean aprobado = true;
		
		System.out.printf(
				"%n%nNombre: %s %n Edad: %d %nPromedio: %.2f%nCurso: %c%nAprobado: %b%n", 
				nombre, 
				edad, 
				promedio, 
				curso, 
				aprobado
		);
		
		
		
		//Alinear columnas
		System.out.println("-----------------------------");
		System.out.printf("%-15s %10d", "Juan", 25);
		
		//¿Qué significa "%-15s %10d"?
		
		/*
		%-15s

		| Parte | Significado              |
		| ----- | ------------------------ |
		| %     | Aquí comienza un formato |
		| -     | Alinear a la izquierda   |
		| 15    | Reservar 15 espacios     |
		| s     | Tipo texto, String       |


		Reserva una columna de 15 posiciones.
		El texto queda alineado a la izquierda.
		Los espacios sobrantes se agregan a la derecha.


		%10d

		| Parte | Significado              |
		| ----- | ------------------------ |
		| %     | Aquí comienza un formato |
		| 10    | Reservar 10 espacios     |
		| d     | Número entero            |

		Muestra un número entero ocupando 10 espacios, alineado a la derecha.

		%n

		Representa un salto de línea.

		*/

		
		
		
		
		
		


	}

}
