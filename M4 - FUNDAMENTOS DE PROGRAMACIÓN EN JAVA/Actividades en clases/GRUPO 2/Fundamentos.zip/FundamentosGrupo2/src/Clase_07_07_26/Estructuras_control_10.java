package Clase_07_07_26;

import java.util.Scanner;

public class Estructuras_control_10 {

	public static void main(String[] args) {
		//******************* Estructuras de Control *****************
		/*
		¿Qué es una estructura de control?

		Concepto de toma de decisiones.

		Ejemplo cotidiano:

		Si llueve, llevo paraguas.
		Si tengo dinero, compro.
		Si apruebo, paso de curso.

		¿Está lloviendo?

		SI
		 ↓
		Llevar paraguas

		NO
		 ↓
		No llevar paraguas
		*/
		
		//***** if (Condicional simple) ******
		/*La estructura if ejecuta un bloque de código solo cuando la condición es verdadera.
		Si la condición es falsa, simplemente continúa con la siguiente instrucción.*/

		//Sintaxis
		/*
		if (condición) {

		    instrucciones;

		}*/
		
		//ejemplo 
		int edad = 16;
		
		if (edad >= 18) {
			System.out.println("Es mayor de edad");
		}
		
		
		//Pedir al usuario la edad.
		/*Scanner teclado = new Scanner(System.in);
		System.out.print("Ingrese su edad: ");
		int edad2 = teclado.nextInt();

		if (edad2 >= 18) {

		    System.out.println("Puede votar");

		}*/
		
		
		//if - else
		//Permite ejecutar un bloque cuando la condición es verdadera y otro cuando es falsa.

		//Sintaxis
		/*
		
		if(condición){

		}

		else{

		}
		
		*/
		
		
		//ejemplo
		int nota = 65;
		String mensaje;
		
		if (nota >= 60) {
			mensaje = "Aprobado";
		}
		
		else {
			mensaje = "Reprobado";
		}
		
		System.out.println(mensaje);
		
		
		//ejemplo 2
		int saldo = 5000;
		int montoCompra = 10000;
		
		
		if (saldo >= montoCompra) {

		    System.out.println("Compra realizada");

		} else {

		    System.out.println("Saldo insuficiente");

		}


		//if anidado
		/*Un if dentro de otro if.

		Se utiliza cuando una decisión depende de otra.*/
		
		//ejemplo
		boolean tieneEntrada = true;
		int edad3 = 16;

		if (tieneEntrada) {

		    if (edad3 >= 18) {

		        System.out.println("Puede ingresar");

		    }
		    else {
		    	System.out.println("Es menor de edad");
		    }

		}
		
		else {
			System.out.println("No tiene entrada");
		}
		

		//if - else if
		//Se utiliza cuando existen varias condiciones posibles.

		//Sintaxis
		/*
		 if(){

		}

		else if(){

		}

		else if(){

		}

		else{

		}
		
		*/	
		

		//ejemplo : Clasificar una nota.

		double promedio = 4.5;

		if (promedio >= 6.0) {
		    System.out.println("Excelente");
		}

		else if (promedio >= 5.0) {
		    System.out.println("Bueno");
		}

		else if (promedio >= 4.0) {
		    System.out.println("Suficiente");
		}

		else {
		    System.out.println("Reprobado");
		}

		//otro ejemplo : Descuento.
		int compra = 120000;

		if (compra >= 100000) {
		    System.out.println("20% descuento");
		}

		else if (compra >= 50000) {
		    System.out.println("10% descuento");
		}

		else {
		    System.out.println("Sin descuento");
		}

		
		//**** switch *****
		/*¿Qué pasa si tenemos muchas opciones?

		1 Registrar
		2 Buscar
		3 Modificar
		4 Eliminar
		5 Salir

		Con muchos if el código comienza a verse desordenado.
		*/

		//Switch clásico
		//Sintaxis
		/*
		switch(variable){

		case valor:

		break;

		default:

		}*/

		//ejemplo
		int opcion = 2;

		switch (opcion) {
		    case 1:
		        System.out.println("Registrar");
		        break;

		    case 2:
		        System.out.println("Buscar");
		        break;

		    case 3:
		        System.out.println("Eliminar");
		        break;

		    default:
		        System.out.println("Opción incorrecta");		        
		}


		//otra versión int opcion = 1;
		String resultado;

		switch (opcion) {
		    case 1:
		        resultado = "Registrar";
		        break;
		    case 2:
		        resultado = "Buscar";
		        break;
		    case 3:
		        resultado = "Eliminar";
		        break;
		    default:
		        resultado = "Opción incorrecta";
		        break;
		}

		System.out.println(resultado);
		/*
		¿Qué hace el break?
		Detiene el switch.*/

		//*Switch moderno (desde la versión Java 14)
		String dia = "LUNES";

		switch (dia) {

		    case "LUNES" -> System.out.println("Inicio de semana");

		    case "VIERNES" -> System.out.println("Ya casi es fin de semana");

		    default -> System.out.println("Otro día");

		}


		//otra version devolviendo valor 
		int nota2 = 6;

		String mensaje2 = switch (nota) {
		    case 7 -> "Excelente";
		    case 6 -> "Muy bueno";
		    case 5 -> "Bueno";
		    default -> "Debe mejorar";
		};

		System.out.println(mensaje);


		/*
		¿Cuándo usar cada estructura?

		| Estructura   | ¿Cuándo utilizarla?                                         | Ejemplo                                                               |
		| ------------ | ----------------------------------------------------------- | --------------------------------------------------------------------- |
		| `if`         | Cuando solo hay una condición.                              | Si la edad es mayor a 18.                                             |
		| `if-else`    | Cuando existen dos caminos posibles.                        | Aprobado o reprobado.                                                 |
		| `if` anidado | Cuando una decisión depende de otra.                        | ¿Tiene entrada? → ¿Es mayor de edad?                                  |
		| `if-else if` | Cuando existen varias condiciones o rangos.                 | Clasificar notas o edades.                                            |
		| `switch`     | Cuando una variable puede tomar varios valores específicos. | Menús, meses del año, días de la semana, opciones de una calculadora. |

		*/
		
		


	}

}
