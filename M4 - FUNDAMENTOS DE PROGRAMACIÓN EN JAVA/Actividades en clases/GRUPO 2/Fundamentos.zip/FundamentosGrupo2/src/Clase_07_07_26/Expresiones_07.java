package Clase_07_07_26;

public class Expresiones_07 {

	public static void main(String[] args) {
		//********************* Expresiones *******************
		/*
		¿Qué es una expresión?
		Una expresión es una combinación de valores, variables, 
		operadores y/o llamadas a métodos que, 
		al ser evaluada por Java, produce un único resultado.

		En otras palabras:
		Una expresión es todo aquello que Java puede evaluar para obtener un valor.

		Ese valor puede ser:

		Un número (15)
		Un decimal (3.5)
		Un texto ("Hola Juan")
		Un carácter ('A')
		Un valor lógico (true o false)
		*/
		
		//ejemplo sencillo
		int resultado = 5 + 3;//Expresión 5 + 3

		//ejemplo con variables
		int nota1 = 60;
		int nota2 = 70;
		
		int promedio = (nota1 + nota2) / 2;//
		
		//Tipos de expresiones
		
		//1. Expresión aritmética
		int total = 10 + 5 * 2;
		
		//2. Expresión relacional
		int edad = 21;
		
		boolean mayor = edad >= 18;//Exprersión --> edad >= 18
		
		//3. Expresión lógica
		//Combina varias condiciones
		int edad2 = 21;
		boolean tieneEntrada = true;
		
		boolean ingresar = edad >= 18 && tieneEntrada;
		
		//4. Expresión de asignación
		int numero = 50;
		int resultado2 = numero + 3;
		
		//5. Expresión de concatenación
		//Unir textos
		
		String nombre = "Roberto";
		String saludo = "Hola " + nombre;
		
		System.out.println(saludo);
		
		System.out.println("Voy ".concat("casa").concat("a ver a mi abuelita"));
		//Existe la interpolación?
		//console.log("Hola ${nombre}");
		
		//Usando printf()
		String nombre2 = "Juan";
		int edad3 = 37;
		
		System.out.printf("Hola %s, tienes %d años. %n", nombre2, edad3);
		
		// Salto de línea %n

		/*
		 * %s → String 
		 * %d → entero (int) 
		 * %f → decimal (float o double), podedmos indicar la cantidad de decimales %.2f 
		 * %c → carácter 
		 * %b → booleano
		 */

		String nombre3 = "Juan";
		double estatura = 1.76;//1.76

		System.out.printf("Hola %s, tu estatura es %.2f %n", nombre3, estatura);

		// ======================== Otro ejemplo =================
		/*
		 * "|%cantidad de espacios a la izquerda s|%n
		 * 
		 * ejemplo: "|%10s|%n
		 * 
		 * cantidad de especios a la derecha : "|%-cantidad de espacios s|%n"
		 * 
		 * ejemplo: "|%-10s|%n"
		 * 
		 * %-10s : 10 espacios a la derecha. %10s: espacios a la izquerda.
		 */

		// Encabezado de la tabla
		System.out.printf("%-15s %-10s %-10s %-10s %n", "Producto", "Marca", "Precio", "Stock");

		System.out.println("-----------------------------------------------");

		// Datos de productos
		System.out.printf("%-15s %-10s %-10s %-10s%n", "Notebook", "Lenovo", "$650000", "12");

		System.out.printf("%-15s %-10s %-10s %-10s%n", "Mouse", "Logitech", "$12000", "35");

		System.out.printf("%-15s %-10s %-10s %-10s%n", "Teclado", "HP", "$25000", "20");

		System.out.printf("%-15s %-10s %-10s %-10s%n", "Monitor", "Samsung", "$180000", "8");

		//Usando String.format()
		//Muy útil cuando quieres construir una cadena sin imprimirla inmediatamente o para almacenar
		String nombre4 = "Javiera";
		int edad4 = 31;
		
		String mensaje = String.format(
				"Hola %s, tienes %d años. %n", 
				nombre4, 
				edad4
				);
		
		System.out.println(mensaje);
		
		
		//Usando formatted() (Java 15+)
		String nombre5 = "Marcelo";
		int edad5 = 31;
		
		String mensaje2 = "Hola %s, tienes %d años. %n".formatted(nombre5, edad5); 
				
		System.out.println(mensaje2);
		
		//6. Expresión condicional (Operador ternario)
		int edad6 = 16;
		
					    //condición   ? resultado si true : resultado si false
		String mensaje3 = edad6 >= 18 ? "Mayor de edad" : "Menor de edad";
		
		if (edad6 >= 18) {
			mensaje3 = "Mayor de edad";
		}
		
		else {
			mensaje3 = "Menor de edad"; 
		}
		
		//7.Expresión con métodos
		//Una llamada a un método también puede forma parte de una expresión
		/*El método Math.sqrt() en Java calcula la raíz cuadrada de un número. 
		 * Pertenece a la clase java.lang.Math y siempre devuelve un valor 
		 * de tipo double. Si el argumento es negativo, devuelve NaN (Not a Number), 
		 * ya que la raíz cuadrada de números negativos no es un valor real.*/
		double raiz = Math.sqrt(25);
		System.out.println(raiz);
		
	}

}
