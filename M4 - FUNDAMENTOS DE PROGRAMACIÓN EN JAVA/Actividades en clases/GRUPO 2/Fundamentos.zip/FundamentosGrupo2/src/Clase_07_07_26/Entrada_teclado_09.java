package Clase_07_07_26;

import java.util.Locale;
import java.util.Scanner;

public class Entrada_teclado_09 {

	public static void main(String[] args) {
		//********************* Entrada por teclado ********************
		/*
		¿Qué es la entrada por teclado?

		La entrada por teclado es el proceso mediante el cual un programa 
		solicita información al usuario mientras se está ejecutando.

		Por ejemplo:

		Ingresar un nombre.
		Ingresar la edad.
		Escribir una nota.
		Ingresar el precio de un producto.

		En Java, la forma más común de leer datos desde el teclado es utilizando 
		la clase Scanner.
		*/

		/*
		¿Qué es Scanner?

		Scanner es una clase de la biblioteca estándar de Java que permite leer 
		información desde diferentes fuentes, como:

		El teclado.
		Un archivo.
		Un texto.
		Un flujo de datos.
		*/
		Scanner teclado = new Scanner(System.in); 
		teclado.useLocale(Locale.US);
		/*
		System.in

		↓

		Entrada estándar (teclado)
		*/
		
		//System.out.print("Ingrese su nombre: ");
		//String nombre = teclado.nextLine();
		//System.out.printf("Hola %s%n", nombre);
		
		//Métodos más utilizados de Scanner

		/*
		| Método          | Tipo de dato leído | Ejemplo    |
		| --------------- | ------------------ | ---------- |
		| next()          | Una palabra        | Juan       |
		| nextLine()      | Una línea completa | Juan Pérez |
		| nextInt()       | Entero             | 25         |
		| nextDouble()    | Decimal            | 15.8       |
		| nextFloat()     | Decimal float      | 5.5f       |
		| nextLong()      | Entero largo       | 1000000000 |
		| nextBoolean()   | Boolean            | true       |
		| nextByte()      | Byte               | 100        |
		| nextShort()     | Short              | 300        |

		*/
		
		
		//next()
		//Lee una sola palabra
		//System.out.print("Ingrese su nombre: ");
		//String nombre2 = teclado.next();
		//System.out.printf("Hola %s%n", nombre2);
		
		//nextLine()
		//Lee toda la línea independiente de la cantidad de palabras
		//System.out.print("Ingrese su nombre completo: ");
		//String nombre3 = teclado.nextLine();
		//System.out.printf("Hola %s%n", nombre3);
		
		//nextInt()
		//Lee un número entero
		//System.out.print("Ingrese su edad: ");
		//int edadUsuario = teclado.nextInt();
		//System.out.printf("Hola tu edad es %d%n", edadUsuario);
		
		
		//nextDouble()
		//Lee un número decimal
		//System.out.print("Ingrese su estatura en metros: ");
		//double estatura = teclado.nextDouble();
		//System.out.printf("Hola tu estatura es %.2f %n", estatura);
		
		//nextBoolean
		//Lee true o false
		//System.out.print("Es estudiante? : ");
		//boolean esEstudiante = teclado.nextBoolean();
		//System.out.printf("Es estudiante --> %b %n", esEstudiante);
		
		
		//**************************** EJEMPLO **********************
        System.out.print("Nombre: ");
        String nombre = teclado.nextLine();

        System.out.print("Edad: ");
        int edad = teclado.nextInt();

        System.out.print("Promedio: ");
        double promedio = teclado.nextDouble();

        System.out.println();

        System.out.println("===== INFORMACIÓN =====");

        System.out.println("Nombre : " + nombre);
        System.out.println("Edad   : " + edad);
        System.out.println("Nota   : " + promedio);
        
        teclado.close();
		
	}

}
