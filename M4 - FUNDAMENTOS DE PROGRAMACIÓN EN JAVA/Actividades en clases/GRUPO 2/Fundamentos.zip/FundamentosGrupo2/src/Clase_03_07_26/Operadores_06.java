package Clase_03_07_26;

public class Operadores_06 {

	public static void main(String[] args) {
		//******************** Operadores ***************
		//*** Aritméticos ****
		int num1 = 20;
		int num2 = 6;
		
		System.out.println(num1 + num2);
		System.out.println(num1 - num2);
		System.out.println(num1 * num2);
		System.out.println(num1 / num2);
		System.out.println(num1 % num2);
		
		//Relacionales
		/*
		Los operadores relacionales permiten comparar dos valores.

		El resultado siempre será un boolean, es decir:
		- true
		- false
		*/
		//Mayor que (>)
		int edad = 20;
		System.out.println(edad > 18);//true o false
		
		//Menor que (<)
		int temperatura = 4;
		System.out.println(temperatura < 10);//true o false
		
		//Mayor o igual (>=)
		int edad2 = 20;
		System.out.println(edad2 >= 18);//true o false
		
		//Menor o igual (<=)
		int temperatura2 = 4;
		System.out.println(temperatura2 <= 10);//true o false
		
		//Igual que (==)
		int numero = 10;
		
		System.out.println(numero == 100);//true o false
		//Importante: == compara, mientras que el = asigna un valor
		
		//Distinto (!=)
		int edad3 = 28;
		System.out.println(edad3 != 18);//true o false
		
		//Operadores lógicos
		

		//Operador AND (&&)
		//Todas las condiciones deben cumplirse.

		/*
		Tabla de verdad

		| A     | B     | A && B |
		| ----- | ----- | ------ |
		| true  | true  | true   |
		| true  | false | false  |
		| false | true  | false  |
		| false | false | false  |

		*/
		
		boolean tieneEntrada = true;
		int edad4 = 17;
						//             true     &&     true  -->  true
		System.out.println(tieneEntrada == true && edad4 >= 18);
		System.out.println(tieneEntrada && edad4 >= 18);
		
		
		//Operador OR (||)
		//Basta con que una condición sea verdadera.

		/*
		Tabla de verdad

		| A     | B     | A || B |
		| ----- | ----- | ------ |
		| true  | true  | true   |
		| true  | false | true   |
		| false | true  | true   |
		| false | false | false  |

		*/
		
		boolean estudiante = false;
		boolean profesor = false;
		System.out.println(estudiante || profesor);
		
		//Operador NOT (!)
		//Invierte el valor lógico
		
		boolean llueve = true;
		System.out.println(!llueve);
		
		//Operadores de asignación 
		//Permiten asignar o modificar el valor de una variable
		

		//Asignación simple (=)
		int nuemro3 = 10;
		
		//Suma e incremento (+=)
		int numero4 = 10;
		numero4 += 5; //equivale a decir numero4 = numero4 + 5
		
		//Resta y asigna (-=)
		int numero5 = 10;
		numero5 -= 3;// numero5 = numero5 - 3 --> numero5 = 7
		
		//Multiplica y asigna (*=)
		int numero6 = 10;
		numero6 *= 5;
		
		//Divide y asigna (/=)
		int numero7 = 10;
		numero7 /= 5;
		
		//Módulo y asigna (%=)
		int numero8 = 10;
		numero8 %= 5; //  numero8 = numero8 % 5 --> numero8= 0
		
		//Incremento y decremento
		//Permite aumentar o disminuir el valor de una variable en una unidad
		
		//Incremento (++)
		int contador = 1;
		contador++;// contador --> 2
		
		//Decremento (--)
		int contador2 = 5;
		contador2--;  // contador --> 4
		
		
		
		
		
		
	}

}
