package Clase_03_07_26;

public class Comentario_01 {

	public static void main(String[] args) {
		//***************** Cometarios *******************
		/*1. De una sola línea Se utilizan para notas cortas, explicar instrucciones 
		simples o desactivar temporalmente una línea de código.*/
		
		//Esto es un comentario de una sola línea
		
		/*
		2. De varias líneas Ideales para explicaciones más extensas, 
		detallar algoritmos o bloquear bloques enteros de código.
		*/
		

		/*
		Este es un comentario de varias líneas.
		Puedes escribir todo el texto que necesites
		y saltar líneas sin que afecte el programa.
		 */
		

		/*
		3. De documentación (Javadoc)
		Documentar en Java se realiza principalmente utilizando Javadoc, un estándar de Oracle.
		Sirven para generar documentación oficial sobre clases, interfaces y métodos. 
		*/
		
		/*
		| Etiqueta       | ¿Para qué sirve?                                       |
		| -------------- | ------------------------------------------------------ |
		| @author        | Indicar el autor del código.                           |
		| @version       | Especificar la versión del programa.                   |
		| @since         | Indicar desde qué versión existe el código.            |
		| @param         | Documentar los parámetros de un método.                |
		| @return        | Explicar el valor que devuelve un método.              |
		| @throws        | Documentar las excepciones que puede lanzar un método. |
		| @see           | Referenciar otra clase o método relacionado.           |
		| @deprecated    | Marcar código que ya no debería utilizarse.            |
		| {@code}        | Mostrar código con formato.                            |
		| {@link}        | Crear un enlace hacia otra clase o método.             |
		| {@linkplain}   | Crear un enlace con formato de texto normal.           |
		| {@literal}     | Mostrar texto sin interpretar HTML.                    |
		| {@summary}     | Escribir el resumen principal de la documentación.     |
		| {@value}       | Mostrar el valor de una constante.                     |
		| {@index}       | Agregar términos al índice de la documentación.        |

		*/
		System.out.print(calculadoraArea(5));
		
	}
	
	/*
	 * @author Nombre Autor
	 * @version 1.0
	 * Calcula el área de un círculo
	 * @param radio El radio del círculo
	 * @return El área del círculo
	 * */
	public static double calculadoraArea(double radio) {
		return Math.PI * radio * radio;
	}

}
