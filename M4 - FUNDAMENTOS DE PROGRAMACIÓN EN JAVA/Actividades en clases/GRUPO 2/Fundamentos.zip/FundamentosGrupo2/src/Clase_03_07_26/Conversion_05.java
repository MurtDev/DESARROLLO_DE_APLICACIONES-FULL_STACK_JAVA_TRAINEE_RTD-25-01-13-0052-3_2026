package Clase_03_07_26;

public class Conversion_05 {

	public static void main(String[] args) {
		//************ Conversión de tipos de datos (Casting) *************
		//Conversión implícita
		int edad = 25;
		
		double numero = edad;//25.0 --> No se pierde información
		 System.out.println(numero);
		
		 //Conversión explícita
		 double estatura = 1.72;
		 
		 int entero = (int) estatura;//--> 1 , se pierde información
		 System.out.println(entero);
		 
		 //métodos utilitarios para convertir cadenas
		 String texto = "25";
		 
		 int numero2 = Integer.parseInt(texto);
		 
		 int numero3 = Integer.valueOf("123");
		 
		 //y a la inversa, numero a cadena
		 String numero4 = String.valueOf(25);
		 
		 //a decimal
		 double decimal = Double.parseDouble("123.45");
		 
		 //a boolean
		 boolean estado = Boolean.parseBoolean("true");
		 System.out.println(estado);
			

	}

}
