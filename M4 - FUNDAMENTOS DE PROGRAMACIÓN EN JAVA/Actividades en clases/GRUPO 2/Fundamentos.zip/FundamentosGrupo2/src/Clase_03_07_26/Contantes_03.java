package Clase_03_07_26;

public class Contantes_03 {

	public static void main(String[] args) {
		//*********************** Constantes ****************
		
		/*
		En Java, una constante es un valor inmutable que no puede modificarse durante la ejecución del programa. 
		Se declaran utilizando la palabra reservada final. Por convención, sus nombres se escriben completamente 
		en mayúsculas, separando las palabras con guiones bajos (ej. VALOR_MAXIMO).
		*/

		final int VALOR_MAXIMO = 1500;
		final String URL = "https://ejemplo.com";
		//URL = "Hola" nos da error, no podemos cambiar el valor, es inmutable

	}

}
