package Clase_03_07_26;

public class Variables_02 {

	public static void main(String[] args) {
		//********************** Variables ****************************
		
		/*
		Una variable es una caja etiquetada.
		
		+------------+
		|  	edad     |
		+------------+
		|     25     |
		+------------+
		
		La caja puede cambiar su contenido.
		*/
		
		/*Nombrar variables correctamente en Java mejora la legibilidad y el mantenimiento del código. 
		Aplica siempre la convención camelCase, donde la primera letra es minúscula y 
		la primera letra de cada palabra posterior es mayúscula (ej. precioTotal).
		
		
		Sigue estas reglas y recomendaciones clave:
		
		- camelCase estricto: Comienza con minúscula y pon en mayúscula la primera letra de las siguientes palabras (ej. nombreUsuario, fechaNacimiento).
		- Nombres descriptivos: Usa nombres que expliquen el propósito de la variable. Evita abreviaturas confusas; es mejor escribir numeroDeIntentos que nIntentos.
		- Distinción de mayúsculas: Recuerda que Java es sensible a las mayúsculas; edad y Edad son variables distintas.
		- Constantes: Escríbelas en MAYÚSCULAS y separa las palabras con guiones bajos (ej. MAXIMO_INTENTOS, TASA_IMPUESTO).
		- Evita caracteres extraños: No uses el símbolo de dólar $ ni guiones bajos _ al inicio del nombre.
		- Palabras reservadas: Nunca utilices palabras clave de Java (como class, int, for, static) como nombres.*/
		
		//Forma 1
		//Declaración
		int edad;
		
		//Inicialización
		edad = 25;
		
		//Forma 2
		//Declaración e inicialización
		int edad2 = 25;
		
		
		//Java moderno (JDK 25) --> También infiere los tipos de datos con "var"
		var edad3 = 25;
		var nombre = "Juan";
		var estatura = 1.67;
		
		//Ojo var no significa "tipo o sin tipo de datos". 
		//El compilador deduce automáticamente el tipo
		
		//Muy importante aclarar que el tipo no cambia
		//edad3 = "Hola"; //no se puede hacer
		
		
		
		
		
		

	}

}
