package Clase_15_07_26;
import java.util.ArrayList;
import java.util.Arrays;

public class Colecciones_13 {

	public static void main(String[] args) {
		// ******************** Colecciones ********************
		/*
		¿Qué son las colecciones?:
		Una colección representa un grupo de objetos ,
		conocidos como elementos. 

		Podemos crear una colección con cualquier tipo de objeto, 
		incluso los creados por nosotros. La única restricción es que no podremos crear
		una colección sólo de tipo primitivo , para eso
		usaremos los tipos de objetos equivalentes a los
		primitivos.

		Por ejemplo: en vez de int, hay que utilizar
		Integer.
		*/

		/*Una colección es una estructura que permite almacenar y administrar grupos de objetos.

		Java incluye diferentes tipos de colecciones:*/

		/*

		Collection
		├── List
		│   ├── ArrayList
		│   └── LinkedList
		│
		├── Set
		│   └── HashSet
		│
		└── Map
		    └── HashMap
		*/
		
		//Equivalencias:
		/*

		| Tipo primitivo | Clase envolvente |
		| -------------- | ---------------- |
		| `int`          | `Integer`        |
		| `double`       | `Double`         |
		| `boolean`      | `Boolean`        |
		| `char`         | `Character`      |
		| `long`         | `Long`           |
		| `float`        | `Float`          |
		*/
		
		//ArrayList
		//No es correcto
		//ArrayList<int> numeros;
		
		//Correcto
		//ArrayList<Integer> numeros = new ArrayList<>();
		
		/*
		Un ArrayList almacena elementos en una lista ordenada.

		Características:

		Mantiene el orden de inserción.
		Permite elementos repetidos.
		Permite acceder por índice.
		Su tamaño puede cambiar.
		*/
		
		//Importación
		//import java.util.ArrayList;
		
		//Creación 
		//Sin inicialización
		ArrayList<String> productos = new ArrayList<>();
		
		//declaración con inicialización
		ArrayList<String> alumnos = new ArrayList<>(Arrays.asList("Roberto", "Luis", "Alejandro"));
		
		//Agregar elementos
		productos.add("Teclado");
		productos.add("Mouse");
		productos.add("Monitor");
		
		alumnos.add("Erick");
		
		//Mostar lista por consola
		System.out.println(productos);
		System.out.println(alumnos);
		
		
		//Obtener o recuper elemento
		String producto = productos.get(2);
		System.out.printf("Producto recuperado: %s %n", producto);
		
		//Modificar un elemento
		productos.set(1, "Mouse inalámbrico");
		System.out.println(productos);
		
		//Eliminar elementos
		//Por indice:
		//productos.remove(2);
		//.out.println(productos.toString());
		
		//Por contenido o por elemento
		//productos.remove("Teclado");
		//System.out.println(productos);
		
		//Cantidad de elementos
		int cantElementos = productos.size();
		System.out.println("Cantidad de elementos: " + cantElementos);
		
		//Cantidad de elementos
		int ultPosicion = productos.size() - 1;//--> 3 - 1 = 2
		System.out.println("última posición: " + ultPosicion);
		
		//Recuperar el último elemento con productos.size() - 1 
		System.out.println(productos.get(ultPosicion));
		
		
		//Verificar si contiene un elemento
		String productoBuscar = "Teclado";
		boolean contieneTeclado = productos.contains(productoBuscar);
		
		if (contieneTeclado) {
			System.out.printf("El producto buscado (%s) se encontro en la lista %n", productoBuscar);
		}
		else {
			System.out.printf("El producto buscado (%s) no se encontro en la lista %n", productoBuscar);
		}
		
		//Vaciar la lista
		//productos.clear();
		System.out.println(productos);
		
		
		//Saber si la lista está vacía
		//1° opción
		if (productos.size() == 0) {
			System.out.println("La lista está vacía");
		}
		
		//2° opción
		if (productos.isEmpty()) {
			System.out.println("La lista está vacía");
		}
		
		//Recorrer un ArrayList elemento por elemento
		//Con for
		//                       3  <= (3 - 1)
		for (int indice = 0; indice <= productos.size() - 1; indice++) {
			System.out.printf("Producto en la posición %d : %s %n", indice, productos.get(indice));
		}
		
		//Con for each
		for (String pto : productos) {
			System.out.printf("Producto %s %n", pto);
		}
		
		//Usando método forEach
		productos.forEach(producto2 -> System.out.println(producto2));
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
