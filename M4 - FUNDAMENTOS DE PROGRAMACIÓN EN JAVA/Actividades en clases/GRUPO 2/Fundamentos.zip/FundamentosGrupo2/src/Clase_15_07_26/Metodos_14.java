package Clase_15_07_26;

public class Metodos_14 {
	
	//Partes de un método

	/*
	| Elemento | Descripción               |
	| -------- | ------------------------- |
	| public   | Modificador de acceso.    |
	| static   | Pertenece a la clase.     |
	| void     | No devuelve ningún valor. |
	| saludar  | Nombre del método.        |
	| ()       | Parámetros.               |
	| {}       | Bloque de instrucciones.  |

	*/
	
	//Parámetros vs Argumentos
	/*
	 * Parámetro: Variable definida en el método
	 * Argumento: Valor enviado al método
	 * */
	
	
	//******* Método sin parámetros y sin retorno **********
	public static void saludar() {
		System.out.println("Hola Mundo 🌎");
	}
	
	
	//********* Método con parámetros y sin retorno ******
	                                     //Parámetro
	public static void saludarUsuario(String nombreUsuario) {
		System.out.println("Hola Usuario " + nombreUsuario);
	}
	
	public static void saludarUsuarioConEdad(String nombreUsuario, int edadUsuario) {
		System.out.printf("Hola Usuario %s tienes %d años %n", nombreUsuario, edadUsuario);
	}
	
	//********** Método con parámetros y con retorno ********
	public static int sumar(int num1, int num2) {
		int resultadoSuma = num1 + num2; //Solo existe dentro del método (Scope --> Ámbito)
		return resultadoSuma;
	}
	
	//Otro ejemplo                                  100      10
	public static double calcularTotalConImpuesto(int monto, double impuesto) {
		//Paso 1
		double impuestoPorcentaje = impuesto / 100; // 10 --> 0.10 
		
		//Paso 2               100  *   0.10   --> 10
		double montoImpuesto = monto * impuestoPorcentaje;
		
		//Paso 3
		double montoTotal = monto + montoImpuesto;// 100 + 10 --> 110 
		
		//Paso 4
		return montoTotal;
		
	}
	
	//********************** Sobrecarga de métodos (OverLoading)****************
	//Versión 1
	public static int multiplicar(int num1, int num2) {
		System.out.println("Versión 1");
		return num1 * num2;
	}
	
	//Versión 2
	public static double multiplicar(double num1, double num2) {
		System.out.println("Versión 2");
		return num1 * num2;
	}
	
	//Versión 3
	public static int multiplicar(int num1, int num2, int num3) {
		System.out.println("Versión 3");
		return num1 * num2 * num3;
	}
	
	
	public static void main(String[] args) {
		//? ************************* Métodos ***********************
		/*
		¿Qué es un método?

		Un conjunto de instrucciones que realizan una tarea específica 
		y que pueden reutilizarse cada vez que sea necesario.

		"un método en Java es lo mismo que una función en otros lenguajes"
		*/

		//¿Por qué utilizar métodos?


		/*Sintaxis de un método 
		 
		modificador tipoRetorno nombreMetodo(){

		}
		*/
		
		//ejemplo de invocación del método saludar
		saludar();
		saludar();
		saludar();
		saludar();
		saludar();
		
		
		//Método con parámetros y sin retorno
		               //Argumento
		saludarUsuario("Roberto");
		
		String nombre = "Sandra";
		saludarUsuario(nombre);
		
		saludarUsuarioConEdad(nombre, 34);
		saludarUsuarioConEdad("Mario", 34);
		
		int resultado = sumar(15, 32);
		System.out.println(resultado);
		
		//Calculo del total con impuesto
		System.out.println(calcularTotalConImpuesto(1000, 19));
		
		
		//Sobrecarga
		System.out.println(multiplicar(25.4, 31.58));
		System.out.println(multiplicar(12, 15));
		System.out.println(multiplicar(2, 3, 15));
	}

}
