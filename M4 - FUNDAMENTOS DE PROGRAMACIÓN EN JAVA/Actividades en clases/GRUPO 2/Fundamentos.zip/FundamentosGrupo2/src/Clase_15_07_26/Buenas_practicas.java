package Clase_15_07_26;

public class Buenas_practicas {

	public static void main(String[] args) {

		//*************** Buenas Prácticas para métodos en Java */
		//1. Usar nombres claros y descriptivos
		//El nombre debe indicar qué tarea realiza el método

		/*
		calcularPromedio();
		mostrarMenu();
		validarEdad();
		obtenerNombreCompleto();

		Evitar nombres poco claros:

		hacer();
		proceso();
		dato();
		metodo1();

		Normalmente, los métodos se nombran con un verbo porque realizan una acción.
		*/

		//2. Utilizar camelCase
		/*
		En Java, los nombres de métodos comienzan con minúscula y cada palabra siguiente comienza con mayúscula.

		calcularPromedio();
		mostrarDatosUsuario();
		obtenerPrecioFinal();

		Incorrecto:

		CalcularPromedio();
		calcular_promedio();
		CALCULARPROMEDIO();
		*/

		//3. Cada método debe realizar una sola tarea
		/*
		Un método debería tener una responsabilidad específica.

		Incorrecto:
		*/
		public static void procesarEstudiante() {
		    // Solicita datos
		    // Calcula promedio
		    // Evalúa aprobación
		    // Imprime resultados
		    // Guarda información
		}

		//Mejor:
		public static double calcularPromedio(
		        double nota1,
		        double nota2,
		        double nota3) {

		    return (nota1 + nota2 + nota3) / 3;
		}

		public static boolean estaAprobado(double promedio) {
		    return promedio >= 4.0;
		}

		public static void mostrarResultado(
		        double promedio,
		        boolean aprobado) {

		    System.out.println("Promedio: " + promedio);
		    System.out.println(aprobado ? "Aprobado" : "Reprobado");
		}

		//Esto hace que el código sea más fácil de leer, probar y modificar.


		//4. Evitar métodos demasiado largos
		//Un método muy largo suele indicar que está realizando demasiadas tareas.
		public static void registrarCompra() {
		    // 100 líneas de código
		}

		//Conviene dividirlo:
		leerDatosCompra();
		calcularSubtotal();
		calcularDescuento();
		calcularTotal();
		mostrarBoleta();
		//No existe un límite obligatorio de líneas, pero el método debe poder entenderse rápidamente.

		//5. Elegir correctamente el tipo de retorno
		//Usa void únicamente cuando el método no necesita devolver un resultado.
		public static void mostrarMensaje() {
		    System.out.println("Bienvenido");
		}

		//Cuando el método calcula u obtiene un dato, es mejor retornarlo:
		public static double calcularArea(double base, double altura) {

		    return base * altura;
		}

		//Evitar imprimir un resultado cuando podría devolverse:
		public static void sumar(int a, int b) {
		    System.out.println(a + b);
		}

		//Mejor:
		public static int sumar(int a, int b) {
		    return a + b;
		}

		//Después quien llama al método decide qué hacer:
		int resultado = sumar(10, 5);
		System.out.println(resultado);

		//6. Usar pocos parámetros
		//Un método con demasiados parámetros se vuelve difícil de utilizar.
		public static void registrarPersona(
		        String nombre,
		        String apellido,
		        int edad,
		        String direccion,
		        String telefono,
		        String correo,
		        String ciudad) {
		}

		//CUANDO VEAMOS OBJETOS PODEMOS HACER
		public static void registrarPersona(Persona persona) {
		}

		//7. Usar nombres descriptivos en los parámetros
		public static double calcularDescuento(
		        double precio,
		        double porcentajeDescuento) {

		    return precio * porcentajeDescuento / 100;
		}

		//Evitar:
		public static double calcular(double x, double y) {
		    return x * y / 100;
		}
		//Los nombres x e y no explican qué representa cada valor.

		//7. Evitar valores “mágicos”
		//Un número mágico es un valor escrito directamente sin explicar su significado.
		public static double calcularTotal(double precio) {
		    return precio * 1.19;
		}

		//Mejor:
		public static double calcularTotal(double precio) {

		    final double IVA = 0.19;

		    return precio + precio * IVA;
		}


		//8. Documentar métodos cuando sea necesario
		/**
		 * Calcula el promedio de tres notas.
		 *
		 * @param nota1 primera nota
		 * @param nota2 segunda nota
		 * @param nota3 tercera nota
		 * @return promedio de las tres notas
		 */
		public static double calcularPromedio(
		        double nota1,
		        double nota2,
		        double nota3) {

		    return (nota1 + nota2 + nota3) / 3;
		}


	}

}
