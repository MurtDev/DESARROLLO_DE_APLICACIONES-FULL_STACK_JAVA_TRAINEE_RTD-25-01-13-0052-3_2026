package app;

import model.Perro;
import model.Gato;

public class Main {

	public static void main(String[] args) {
		Perro firulais = new Perro("Firulias", 14.8, "Chauchau");
		
		firulais.mostrarInformacionPerro();
		
		Gato gatuno = new Gato("Gatuno", 8.5, "Grande", 15);
		
		System.out.println(gatuno.getNombre());
		
		firulais.comer();
		firulais.dormir();
		System.out.println(firulais.emitirSonido());
		System.out.println(gatuno.emitirSonido());
		
		

	}

}
