/**
 * 
 */
/**
 * 
 */
module VeterinariaHerenciaG2 {
}