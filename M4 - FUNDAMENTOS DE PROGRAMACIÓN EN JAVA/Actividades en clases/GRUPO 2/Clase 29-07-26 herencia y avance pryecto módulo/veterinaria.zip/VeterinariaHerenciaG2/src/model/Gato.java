package model;

public class Gato extends Animal{
	protected String tamano;
	protected int duracion;
	
	public Gato(String nombre, double peso, String tamano, int duracion) {
		super(nombre, peso);
		
		this.tamano = tamano;
		this.duracion = duracion;
	}
	
	public Gato(String nombre, String tamanio, int duracion) {
		super(nombre);
		this.tamano = tamanio;
		this.duracion = duracion;
	}

	public String getTamano() {
		return tamano;
	}

	public void setTamano(String tamano) {
		this.tamano = tamano;
	}

	public int getDuracion() {
		return duracion;
	}

	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}
	
	@Override
	public String emitirSonido() {
		return "miaaauuuu!";
	}
	
}
