package model;

public class Perro extends Animal{
	String raza;
	
	public Perro(String nombre, double peso, String raza) {
		super(nombre, peso);
		this.raza = raza;
	}

	public String getRaza() {
		return raza;
	}

	public void setRaza(String raza) {
		this.raza = raza;
	}
	
	public void mostrarInformacionPerro() {
		System.out.println("Nombre: " + nombre);
		System.out.println("Peso: " + peso);
		System.out.println("Raza: " + raza);
	}
	
	
	@Override
	public void comer() {
		super.comer();
	}
	
	@Override
	public void dormir() {
		super.dormir();
	}
	
	
	@Override
	public String emitirSonido() {
		return "Gau! Gau!";
	}
	
}
