package model;

public class Animal {
	protected String nombre;
	protected double peso;
	
	public Animal(String nombre, double peso) {
		this.nombre = nombre;
		this.peso = peso;
	}
	
	public Animal(String nombre) {
		this.nombre = nombre;
	}
	
	public void comer() {
		System.out.println("El animal esta comiendo...");
	}
	
	public void dormir() {
		System.out.println("El animal esta durmiendo...");
	}
	
	public String emitirSonido() {
		return "Sonido del animal";
	}
	
	
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}
	
	
}
