package app;

import models.Tarea;
import models.GestorTareas;

public class Main {

	public static void main(String[] args) {
		
		//Crear instancia de una tarea
		GestorTareas gestor = new GestorTareas();
		
		//Crear tareas
		gestor.agregarTarea("Estudiar POO con Java", "ALTA");
		gestor.agregarTarea("Avanzar en el proyecto de módulo 4", "ALTA");
		gestor.agregarTarea("Descanzar", "MEDIA");
		
		gestor.listarTareas();
		
		gestor.marcarComoCompletada(2);
		
		gestor.listarTareas();
		
		gestor.eliminarTarea(1);
		
		gestor.agregarTarea("Ir a break!!", "ALTA");
		
		gestor.listarTareas();
	}

}
