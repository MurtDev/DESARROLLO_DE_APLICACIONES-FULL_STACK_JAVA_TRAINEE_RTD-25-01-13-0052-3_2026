/**
 * 
 */
/**
 * 
 */
module SmartTask2 {
}