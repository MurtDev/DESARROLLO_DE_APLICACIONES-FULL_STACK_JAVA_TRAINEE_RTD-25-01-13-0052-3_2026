package models;

import java.util.ArrayList;

public class GestorTareas {
	private ArrayList<Tarea> tareas;
	private int siguienteId;
	
	
	public GestorTareas() {
		this.tareas = new  ArrayList<>();
		this.siguienteId = 1;
	}
	
	
	 /**
     * Genera un identificador único para una nueva tarea.
     *
     * Después de generar el identificador, incrementa el valor
     * para que la siguiente tarea tenga un ID diferente.
     *
     * @return identificador generado para la nueva tarea
     */
	private int generarId() {
		int idGenerado = siguienteId;//1
		siguienteId++;//2
		
		return idGenerado;
	}
	
	public void agregarTarea(String nombreTarea, String prioridad) {
		int id = generarId();
		
		Tarea  nuevaTarea = new Tarea(id, nombreTarea, prioridad);
		tareas.add(nuevaTarea);
		
		System.out.println("Tarea agregada correctamente con el id: " + id);
	}
	
	
	public void listarTareas() {
		//Verificar que la lista de tareas tenga elementos
		if (tareas.isEmpty()) {
			System.out.println("No existen tareas registradas.");
			return;
		}
		
		// Encabezado de la tabla
		System.out.println("----------------------------------------------------------------");
		System.out.printf("%-4s %-40s %-10s %-10s %n", "ID", "Nombre", "Prioridad", "Estado");
		System.out.println("----------------------------------------------------------------");
		
		String estado = "Activa";
		
		for (Tarea tarea : tareas) {//"Completada"
			   //true o false 
			if(tarea.isCompletada()) {//false
				estado = "Completada";
			}
			
			// Datos de tareas
			System.out.printf(
					"%-4d %-40s %-10s %-10s%n", 
					tarea.getId(), 
					tarea.getNombre(), 
					tarea.getPrioridad(), 
					estado);//Completada
			
			//estado = "Activa";
			
		}		
	}
			
			
	public void marcarComoCompletada(int id) {
		//Verificar que la lista de tareas tenga elementos
		if (tareas.isEmpty()) {
			System.out.println("No existen tareas registradas.");
			return;
		}
		
		for (Tarea tarea : tareas) {
			if (tarea.getId() == id) {
				tarea.marcarTareaCompletada();
				System.out.println("Tarea marcada como completada.");
				return;
			}
		}
		
		System.out.println("Tarea no encontrada, verifique el id correspondiente y vuelva a intentar.");
	}	
	
	
	public void eliminarTarea(int id) {
		//Verificar que la lista de tareas tenga elementos
		if (tareas.isEmpty()) {
			System.out.println("No existen tareas registradas.");
			return;
		}
		
		for (Tarea tarea : tareas) {
			if (tarea.getId() == id) {
				tareas.remove(tarea);
				System.out.println("Tarea eliminada correctamente.");
				return;
			}
		}
		
		System.out.println("Tarea no encontrada, verifique el id correspondiente y vuelva a intentar.");
	}

	
	public ArrayList<Tarea> getTareas() {
		return tareas;
	}
		
	
}
