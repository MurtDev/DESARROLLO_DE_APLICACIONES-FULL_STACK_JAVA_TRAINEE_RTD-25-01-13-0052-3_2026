package models;

public class Tarea {
	private int  id;//Crear método para incrementar
	private String nombre;
	private String prioridad;//Alta,  media y baja
	private boolean completada;
	
	public Tarea() {
		
	}
	
	/*
	 * Constructor parametrizado
	 * 
	 * @param id identifacador de la tarea
	 * @param nombre nombre de la tarea
	 * @param  prioridad prioridad de la tarea
	 * */
	
	public Tarea(int id, String nombre, String prioridad) {
		this.id  = id;
		this.nombre = nombre;
		this.prioridad = prioridad;
		this.completada = false; 
	}

	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the prioridad
	 */
	public String getPrioridad() {
		return prioridad;
	}

	/**
	 * @param prioridad the prioridad to set
	 */
	public void setPrioridad(String prioridad) {
		this.prioridad = prioridad;
	}

	/**
	 * @return the completada
	 */
	public boolean isCompletada() {
		return completada;
	}

	/**
	 * @param completada the completada to set
	 */
	public void setCompletada(boolean completada) {
		this.completada = completada;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	
	public void marcarTareaCompletada() {
		
		//También  podemos dejarlo sin this acá
		//ya que no tenemos que hacer  diferencia entre  parámetros y atributos de la clase
		//completada = true;
		this.completada = true;
	} 
	
	public void mostrarInformacionTarea() {
		String estado = "Activa";
		
		if(completada) {//true
			estado = "Completada";
		}/*else {
			estado = "Activa";
		}*/
		
		System.out.printf(
				"ID: %d %nNombre: %s %nPrioridad: %s %nEstado: %s %n", 
				id, 
				nombre, 
				prioridad, 
				estado
				);
	}
	
	@Override
	public String toString() {
		return "Tarea [id=" + id + ", nombre=" + nombre + ", prioridad=" + prioridad + ", completada=" + completada
				+ "]";
	}
	
		
}
