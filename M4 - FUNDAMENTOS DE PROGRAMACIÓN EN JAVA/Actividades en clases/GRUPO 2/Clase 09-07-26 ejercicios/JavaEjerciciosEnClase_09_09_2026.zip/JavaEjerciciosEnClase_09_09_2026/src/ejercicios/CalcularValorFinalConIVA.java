/**
 * 
 */
package ejercicios;

import java.util.Scanner;

/**
 * 
 */
public class CalcularValorFinalConIVA {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Creamos nuestro objeto scanner:
		Scanner objScanner = new Scanner(System.in);

		System.out.println("Ingrese Precio Producto:");
		int precio = objScanner.nextInt();

		if (precio >= 0) {
			
			double iva = (precio * 0.19);
			
			System.out.println("Precio               :"+ precio);
			System.out.println("IVA                  :"+ iva);
			System.out.println("Precio (IVA Incluido):"+ (precio + iva));
			
		}else {
			System.out.println("El precio ingresado no es válido.");
		}

		// Cerramos el scanner
		objScanner.close();

	}

}

/*
 ******* Ejercicio 6: Calcular valor final con IVA *********
 * 
 * Crea un programa en Java que solicite al usuario ingresar el precio de un
 * producto.
 * 
 * El programa debe calcular el valor final agregando un IVA del 19%.
 * 
 * Luego debe mostrar:
 * 
 * El precio original. El monto del IVA. El precio final con IVA.
 * 
 * Además:
 * 
 * Si el precio ingresado es menor o igual a 0, debe mostrar:
 * 
 * El precio ingresado no es válido.
 */
