package ejercicios;

import java.util.Scanner;

public class SistemaDeTurnosMedicos {

	public static void main(String[] args) {
		// Creamos nuestro objeto scanner:
		Scanner objScanner = new Scanner(System.in);

		System.out.println("Edad del paciente:");
		int edad = objScanner.nextInt();

		System.out.println("Nivel de urgencia del 1 al 5.");
		int nivelUrgencia = objScanner.nextInt();

		if (nivelUrgencia < 1 || nivelUrgencia > 5) {
			System.out.println("Nivel de urgencia no válido.");
		} else {
			if (nivelUrgencia == 5) {
				System.out.println("Atención inmediata.");
			} else if (nivelUrgencia == 4 && edad >= 60) {
				System.out.println("Atención prioritaria.");
			} else if (nivelUrgencia == 3 || nivelUrgencia == 4) {
				System.out.println("Atención normal.");
			} else if (nivelUrgencia == 1 || nivelUrgencia == 2) {
				System.out.println("Atención de baja prioridad.");
			}
		}

		// Cerramos el scanner
		objScanner.close();

	}

}

/*
 ****** Ejercicio 7: Sistema de turnos médicos *********
 * 
 * Solicita al usuario:
 * 
 * Edad del paciente. Nivel de urgencia del 1 al 5.
 * 
 * El programa debe clasificar la atención:
 * 
 * Si la urgencia es 5, mostrar: Atención inmediata. Si la urgencia es 4 y el
 * paciente tiene 60 años o más, mostrar: Atención prioritaria. Si la urgencia
 * es 3 o 4, mostrar: Atención normal. Si la urgencia es 1 o 2, mostrar:
 * Atención de baja prioridad. Si ingresa un nivel fuera del rango 1 a 5,
 * mostrar: Nivel de urgencia no válido.
 * 
 */
