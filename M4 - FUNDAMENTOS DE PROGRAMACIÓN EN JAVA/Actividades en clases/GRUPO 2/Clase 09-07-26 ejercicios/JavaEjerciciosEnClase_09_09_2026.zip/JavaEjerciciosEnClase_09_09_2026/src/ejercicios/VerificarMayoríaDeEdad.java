package ejercicios;

import java.util.Scanner;

public class VerificarMayoríaDeEdad {

	public static void main(String[] args) {
		// Creamos nuestro objeto scanner:
		Scanner objScanner = new Scanner(System.in);
		
		
		System.out.println("Ingrese su edad:");
		int edad = objScanner.nextInt();
		
		if (edad >= 18) {
			System.out.println("Puede votar.");
		}else {
			System.out.println("Aún no puede votar.");
		}
		
		
		// Cerramos el scanner
		objScanner.close();

	}

}

/*
***** Ejercicio 1: Verificar mayoría de edad para votar **********

Crea un programa en Java que solicite al usuario ingresar su edad.
El programa debe evaluar si la edad es mayor o igual a 18.
Si cumple la condición, debe mostrar:

Puede votar.

En caso contrario, debe mostrar:

Aún no puede votar.
*/

/*
System.out.println("Ingrese su edad:");
int edad = objScanner.nextInt();

System.out.println("Ingrese nota 1: ");
double nota1 = ObjScanner.nextDouble();


System.out.println("Ingrese su usuario:");
String nombre = objScanner.nextLine();

*/

