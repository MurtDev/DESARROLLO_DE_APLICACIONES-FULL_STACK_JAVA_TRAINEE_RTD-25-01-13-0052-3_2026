package ejercicios;

import java.util.Scanner;

public class EvaluacionDePrestamo {

	public static void main(String[] args) {
		// Creamos nuestro objeto scanner:
		Scanner objScanner = new Scanner(System.in);

		System.out.println("Edad:");
		int edad = objScanner.nextInt();
		
		System.out.println("Sueldo mensual:");
		int sueldo = objScanner.nextInt();
		
		
		System.out.println("Antigüedad laboral en años:");
		int aniosAntiguedaLaboral = objScanner.nextInt();

		if (edad >= 21 && sueldo >= 700000 && aniosAntiguedaLaboral >= 1) {
			System.out.println("Préstamo aprobado.");
		} else {
			System.out.println("Préstamo rechazado.");
		} 

		// Cerramos el scanner
		objScanner.close();

	}

}

/*
 ******* Ejercicio 5: Evaluación de préstamo *******
 * 
 * Solicita al usuario:
 * 
 * Edad. Sueldo mensual. Antigüedad laboral en años.
 * 
 * El programa debe aprobar un préstamo solo si:
 * 
 * Tiene 21 años o más. Su sueldo es mayor o igual a 700000. Tiene al menos 1
 * año de antigüedad laboral.
 * 
 * Si cumple todo, mostrar:
 * 
 * Préstamo aprobado.
 * 
 * En caso contrario, mostrar:
 * 
 * Préstamo rechazado.
 */