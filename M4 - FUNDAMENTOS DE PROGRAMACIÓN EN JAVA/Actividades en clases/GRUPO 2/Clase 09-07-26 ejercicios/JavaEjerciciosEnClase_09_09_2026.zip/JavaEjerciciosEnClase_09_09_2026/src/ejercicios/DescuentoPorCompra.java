package ejercicios;

import java.util.Scanner;

public class DescuentoPorCompra {

	public static void main(String[] args) {
		// Creamos nuestro objeto scanner:
		Scanner objScanner = new Scanner(System.in);

		System.out.println("Ingrese Monto Total Compra:");
		int montoCompra = objScanner.nextInt();

		if (montoCompra >= 50000) {
			System.out.println("Tiene descuento del 10%");
		} else {
			System.out.println("No tiene descuento.");
		}

		// Cerramos el scanner
		objScanner.close();

	}

}

/*
 ***** Ejercicio 2: Descuento por compra *****************
 * 
 * Crea un programa en Java que solicite al usuario ingresar el monto total de
 * una compra.
 * 
 * El programa debe evaluar el monto ingresado:
 * 
 * Si la compra es mayor o igual a 50000, mostrar: Tiene descuento del 10%. Si
 * la compra es menor a 50000, mostrar: No tiene descuento.
 * 
 */
