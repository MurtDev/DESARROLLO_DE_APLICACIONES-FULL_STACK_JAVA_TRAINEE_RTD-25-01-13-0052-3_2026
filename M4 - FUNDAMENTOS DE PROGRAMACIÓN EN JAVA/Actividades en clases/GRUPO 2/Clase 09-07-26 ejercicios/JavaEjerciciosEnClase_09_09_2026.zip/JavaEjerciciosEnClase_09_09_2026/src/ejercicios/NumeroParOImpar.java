package ejercicios;

import java.util.Scanner;

public class NumeroParOImpar {
	public static void main(String[] args) {
		// Creamos nuestro objeto scanner:
		Scanner objScanner = new Scanner(System.in);

		System.out.println("Ingrese número a evaluar:");
		int numero = objScanner.nextInt();

		if (numero % 2 == 0) {
			System.out.println("El número es par.");
		} else {
			System.out.println("El número es impar.");
		} 

		// Cerramos el scanner
		objScanner.close();

	}

}

/*
 ******** Ejercicio 4: Número par o impar **********
 * 
 * Crea un programa en Java que solicite al usuario ingresar un número entero.
 * 
 * El programa debe evaluar si el número es par o impar.
 * 
 * Si el número es divisible por 2, mostrar: El número es par. En caso
 * contrario, mostrar: El número es impar.
 */