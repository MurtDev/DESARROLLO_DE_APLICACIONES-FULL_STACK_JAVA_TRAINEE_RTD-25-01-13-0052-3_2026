package ejercicios;

import java.util.Locale;
import java.util.Scanner;

public class CalculadoraSimple {

	public static void main(String[] args) {
		// Creamos nuestro objeto scanner:
		Scanner objScanner = new Scanner(System.in);

		// Configuramos el Scanner para que acepte el punto como decimal
		objScanner.useLocale(Locale.US);

		System.out.println("Primer número: ");
		double n1 = objScanner.nextDouble();

		System.out.println("Segundo número:");
		double n2 = objScanner.nextDouble();

		System.out.println("");

		System.out.println("1. Sumar");
		System.out.println("2. Restar");
		System.out.println("3. Multiplicar");
		System.out.println("4. Dividir");

		System.out.println("");

		System.out.println("Seleccione Opción de Menú");
		int operacion = objScanner.nextInt();

		System.out.println("");

		if (operacion < 1 || operacion > 4) {
			System.out.println("Operación no válida.");
		} else {
			if (operacion == 1) {
				double suma = n1 + n2;
				System.out.println("Resultado: " + suma);
			} else if (operacion == 2) {
				double resta = n1 - n2;
				System.out.println("Resultado: " + resta);
			} else if (operacion == 3) {
				double multiplicacion = n1 * n2;
				System.out.println("Resultado: " + multiplicacion);
			} else if (operacion == 4) {
				if (n2 != 0) {
					double division = (n1 / n2);
					System.out.println("Resultado: " + division);
				} else {
					System.out.println("No se puede dividir por cero.");
				}

			}
		}

		// Cerramos el scanner
		objScanner.close();

	}

}

/*
 ***** Ejercicio 9: Calculadora simple ******
 * 
 * Crea un programa en Java que solicite al usuario ingresar dos números.
 * 
 * Luego debe mostrar el siguiente menú:
 * 
 * Sumar Restar Multiplicar Dividir
 * 
 * Según la opción seleccionada, debe mostrar el resultado de la operación.
 * 
 * Además:
 * 
 * Si selecciona la opción 4 y el segundo número es 0, debe mostrar: No se puede
 * dividir por cero. Si ingresa una opción distinta, debe mostrar: Operación no
 * válida.
 */