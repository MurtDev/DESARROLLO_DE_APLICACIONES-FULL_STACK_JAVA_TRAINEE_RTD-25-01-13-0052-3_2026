package ejercicios;

import java.util.Scanner;

public class ClasificacionDeVelocidad {

	public static void main(String[] args) {
		// Creamos nuestro objeto scanner:
		Scanner objScanner = new Scanner(System.in);

		System.out.println("Velocidad de un vehículo:");
		int velocidad = objScanner.nextInt();

		if (velocidad <= 50) {
			System.out.println("Velocidad segura.");
		} else if (velocidad >= 51 && velocidad <= 80) {
			System.out.println("Velocidad moderada.");
		} else if (velocidad >= 81 && velocidad <= 100) {
			System.out.println("Velocidad alta.");
		} else if (velocidad > 100) {
			System.out.println("Exceso de velocidad.");
		}

		// Cerramos el scanner
		objScanner.close();

	}

}

/*
 ***** Ejercicio 3: Clasificación de velocidad **************
 * 
 * Crea un programa en Java que solicite al usuario ingresar la velocidad de un
 * vehículo.
 * 
 * El programa debe mostrar una categoría según la velocidad ingresada:
 * 
 * Si la velocidad es menor o igual a 50, mostrar: Velocidad segura. Si la
 * velocidad está entre 51 y 80, mostrar: Velocidad moderada. Si la velocidad
 * está entre 81 y 100, mostrar: Velocidad alta. Si la velocidad es mayor a 100,
 * mostrar: Exceso de velocidad.
 */
