package ejercicios;

import java.util.Scanner;

public class EvaluaciónDeStock {

	public static void main(String[] args) {
		// Creamos nuestro objeto scanner:
		Scanner objScanner = new Scanner(System.in);

		System.out.println("Ingresar cantidad de productos:");
		int stock = objScanner.nextInt();

		if (stock == 0) {
			System.out.println("Sin stock.");
		} else if (stock >= 1 && stock <= 10) {
			System.out.println("Stock bajo.");
		} else if (stock >= 11 && stock <= 50) {
			System.out.println("Stock suficiente.");
		} else if (stock > 50) {
			System.out.println("Stock alto.");
		}

		// Cerramos el scanner
		objScanner.close();

	}

}

/*
 ******* Ejercicio 8: Evaluación de stock **********
 * 
 * Crea un programa en Java que solicite al usuario ingresar la cantidad de
 * productos disponibles en bodega.
 * 
 * El programa debe evaluar el stock:
 * 
 * Si el stock es igual a 0, mostrar: Sin stock. Si el stock está entre 1 y 10,
 * mostrar: Stock bajo. Si el stock está entre 11 y 50, mostrar: Stock
 * suficiente. Si el stock es mayor a 50, mostrar: Stock alto.
 */