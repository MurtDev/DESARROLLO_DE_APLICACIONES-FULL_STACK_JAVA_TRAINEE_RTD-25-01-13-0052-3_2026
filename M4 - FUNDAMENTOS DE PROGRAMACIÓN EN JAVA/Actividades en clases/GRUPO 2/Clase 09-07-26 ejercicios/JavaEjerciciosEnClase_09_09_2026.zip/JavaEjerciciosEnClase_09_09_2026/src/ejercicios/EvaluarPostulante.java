package ejercicios;

import java.util.Scanner;

public class EvaluarPostulante {

	public static void main(String[] args) {
		// Creamos nuestro objeto scanner:
		Scanner objScanner = new Scanner(System.in);

		System.out.println("Edad del postulante:");
		int edad = objScanner.nextInt();

		System.out.println("Años de experiencia");
		int aniosExperiencia = objScanner.nextInt();

		if(edad >= 18 && aniosExperiencia >= 1) {
			System.out.println("Puede postular al cargo.");
		}else{
			System.out.println("No cumple los requisitos para postular.");
		}

		// Cerramos el scanner
		objScanner.close();

	}

}

/*
 ******* Ejercicio 10: Evaluar postulante *******
 * 
 * Crea un programa en Java que solicite al usuario ingresar:
 * 
 * Su edad. Sus años de experiencia.
 * 
 * El programa debe evaluar si puede postular a un cargo.
 * 
 * Para postular debe cumplir:
 * 
 * Tener 18 años o más. Tener al menos 1 año de experiencia.
 * 
 * Si cumple ambas condiciones, mostrar:
 * 
 * Puede postular al cargo.
 * 
 * En caso contrario, mostrar:
 * 
 * No cumple los requisitos para postular.
 */
