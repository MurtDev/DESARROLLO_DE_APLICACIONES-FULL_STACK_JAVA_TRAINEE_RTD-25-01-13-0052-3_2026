/**
 * 
 */
/**
 * 
 */
module VeterinariaHerencia {
}