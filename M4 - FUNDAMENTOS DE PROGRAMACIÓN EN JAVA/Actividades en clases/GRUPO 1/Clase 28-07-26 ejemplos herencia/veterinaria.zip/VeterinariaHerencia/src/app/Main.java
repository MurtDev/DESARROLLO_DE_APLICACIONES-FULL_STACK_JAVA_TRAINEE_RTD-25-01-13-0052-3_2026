package app;

import model.Gato;
import model.Perro;

public class Main {

	public static void main(String[] args) {
		
		Perro firulais = new Perro("Firulais", 14.4, "Labrador");
		
		firulais.mostrarInformación();
		firulais.comer();
		firulais.dormir();
		System.out.println(firulais.emitirSonido());
		
		//System.out.println(firulais.getPeso());
		//recuperación del peso usando el método de la padre "Animal"
		
		System.out.println("-----------------");
		Gato gatuno = new Gato("Gatuno", 8.4, "Angora", "gris");
		gatuno.mostrarInformación();
		gatuno.comer();
		gatuno.dormir();
		System.out.println(gatuno.emitirSonido());

	}

}
