package model;

public class Gato extends Animal{
	private String raza;
	private String color;
	
	public Gato(String nombre, double peso, String raza, String color) {
		super(nombre, peso);
		this.raza = raza;
		this.color = color;
	}

	public String getRaza() {
		return raza;
	}

	public void setRaza(String raza) {
		this.raza = raza;
	}
	
	public void mostrarInformación() {
		System.out.printf("Nombre: %s %nPeso: %.2f kg %nRaza: %s %nColor: %s", nombre, peso, raza, color);
	}

	@Override
	public String emitirSonido() {
		return "Miaaaauu!! Miaaaauu!!";
	}
}
