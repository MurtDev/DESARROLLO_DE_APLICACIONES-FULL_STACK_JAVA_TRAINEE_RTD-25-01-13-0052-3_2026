package model;

public class Perro extends Animal{
	private String raza;
	
	public Perro(String nombre, double peso, String raza) {
		super(nombre, peso);
		this.raza = raza;
	}

	public String getRaza() {
		return raza;
	}

	public void setRaza(String raza) {
		this.raza = raza;
	}
	
	public void mostrarInformación() {
		System.out.printf("Nombre: %s %nPeso: %.2f kg %nRaza: %s %n", nombre, peso, raza);
	}
	
	@Override
	public String emitirSonido() {
		return "Guau!! Guau!!";
	}
	
	@Override
	public void dormir() {
		super.dormir();
	}
}
