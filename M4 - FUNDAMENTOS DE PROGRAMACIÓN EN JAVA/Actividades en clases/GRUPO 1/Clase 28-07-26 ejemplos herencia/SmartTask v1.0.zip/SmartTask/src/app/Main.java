package app;

import model.GestorTareas;
import model.Tarea;

public class Main {

	public static void main(String[] args) {
		GestorTareas gestor = new GestorTareas();
		
		gestor.agregarTarea("Trabajar en proyecto módulo", "ALTA");
		gestor.agregarTarea("Estudiar Fundamentos de Java", "ALTA");
		
		gestor.listarTareas();
		
		

	}

}
