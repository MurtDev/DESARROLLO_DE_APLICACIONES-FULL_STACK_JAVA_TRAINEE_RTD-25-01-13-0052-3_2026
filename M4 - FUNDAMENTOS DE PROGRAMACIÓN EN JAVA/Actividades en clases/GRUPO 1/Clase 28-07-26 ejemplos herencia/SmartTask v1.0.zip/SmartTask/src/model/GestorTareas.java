package model;
import java.util.ArrayList;


public class GestorTareas {
	private ArrayList<Tarea> tareas;
	private int siguienteId;
	
	public GestorTareas() {
		this.tareas = new ArrayList<>();
		this.siguienteId = 1;
	}
	
	public void agregarTarea(String nombre, String prioridad) {
		//Conseguir id
		int id = generarId();//un valor int
		
		//Crear una instancia de tarea
		Tarea nuevaTarea = new Tarea(id, nombre, prioridad);
		
		//Almacenar en nuestra lista de tareas
		tareas.add(nuevaTarea);
		
		System.out.println("Tarea agregada correctamente");
		
	}
	
	public void listarTareas() {
		if (tareas.isEmpty()) {
			System.out.println("NO EXISTEN TAREAS REGISTRADAS");
			return;
		}
		
		System.out.printf("%-3s %-40s %-10s %-10s%n", "ID", "Nombre", "Prioridad", "Estado");
		System.out.println("-----------------------------------------------");
		
		for (Tarea tarea : tareas) {
			//System.out.println("--------------------------------------");
			System.out.printf(
					"%-3s %-40s %-10s %-10s%n", 
					tarea.getId(), 
					tarea.getNombre(), 
					tarea.getPrioridad(), 
					tarea.isCompletada());
			//tarea.mostrarInformacionTarea();
			//System.out.println("--------------------------------------");
		}
	}
	
	public void marcarTareaComoCompletada(int id) {
		for (Tarea tarea : tareas) {//forma más limpia con removeIf()
			if (tarea.getId() == id) {
				tarea.marcarComoCompletada();
				
				System.out.println("Tarea completada correctamente");
				
				return;
			}
		}
	}
	
	public void eliminarTarea(int id) {
		for (Tarea tarea : tareas) {//forma más limpia con removeIf()
			if (tarea.getId() == id) {
				tareas.remove(tarea);
				
				System.out.println("Tarea eliminada correctamente");
				
				return;
			}
		}
	}
	
	private int generarId() {
		int idGenerado = siguienteId;
		siguienteId++;
		
		return idGenerado;
	}

	public ArrayList<Tarea> getTareas() {
		return tareas;
	}
	
	
	
}
