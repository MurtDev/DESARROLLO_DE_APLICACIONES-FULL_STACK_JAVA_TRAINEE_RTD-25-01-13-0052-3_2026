package model;

/*
 * Representa una tarea dentro de la aplicación SmartTask
 *
 * @author Ricardo Vega
 * @version 1.0
 * */
public class Tarea {
	private int id;
	private String nombre;
	private String prioridad;
	private boolean completada;//estado
	
	
	/*
	 * Contructor parametrizado
	 * 
	 * @param nombre nombre de la tarea
	 * @param prioridad prioridad de la tarea
	 * 
	 * */
	public Tarea(int id, String nombre, String prioridad) {
		this.id = id;//TODO: Crear método para asignar
		this.nombre = nombre;
		this.prioridad = prioridad;
		this.completada = false;
	}


	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}


	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	/**
	 * @return the prioridad
	 */
	public String getPrioridad() {
		return prioridad;
	}


	/**
	 * @param prioridad the prioridad to set
	 */
	public void setPrioridad(String prioridad) {
		this.prioridad = prioridad;
	}


	/**
	 * @return the completada
	 */
	public boolean isCompletada() {
		return completada;
	}


	/**
	 * @param completada the completada to set
	 */
	public void marcarComoCompletada() {
		this.completada = true;
	}


	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	
	
	/*
	 * Muestra los datos de la tarea por consola
	 * */
	public void mostrarInformacionTarea() {
		System.out.println("ID: " + id);
		System.out.println("Nombre: " + nombre);
		System.out.println("Prioridad: " + prioridad);
		
		if(completada) {
			System.out.println("Estado: Completada");
		}else {
			System.out.println("Estado: Activa");
		}
		
	}
	
	
	
	
}
