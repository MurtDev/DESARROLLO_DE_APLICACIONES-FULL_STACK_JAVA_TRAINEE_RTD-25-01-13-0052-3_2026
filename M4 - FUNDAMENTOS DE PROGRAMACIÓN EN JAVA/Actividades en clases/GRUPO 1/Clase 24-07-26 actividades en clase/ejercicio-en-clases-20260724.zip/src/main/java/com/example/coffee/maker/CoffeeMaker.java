package com.example.coffee.maker;

public class CoffeeMaker {

    private int maxCapacity;
    private int currentAmount;

    public CoffeeMaker() {
        this.maxCapacity = 1000;
        this.currentAmount = 0;
    }

    public CoffeeMaker(int maxCapacity, int currentAmount) {
        this.maxCapacity = maxCapacity;
        this.currentAmount = Math.min(currentAmount, maxCapacity);
    }

    public int getMaxCapacity() {
        return maxCapacity;
    }

    public void setMaxCapacity(int maxCapacity) {
        this.maxCapacity = maxCapacity;
        if (currentAmount > maxCapacity) {
            currentAmount = maxCapacity;
        }
    }

    public int getCurrentAmount() {
        return currentAmount;
    }

    public void setCurrentAmount(int currentAmount) {
        this.currentAmount = Math.min(currentAmount, maxCapacity);
    }

    public void fillCoffeeMaker() {
        currentAmount = maxCapacity;
    }

    public void serveCup(int cupSize) {
        if (cupSize <= 0) {
            System.out.println("El tamaño de la taza debe ser mayor que cero.");
            return;
        }

        if (currentAmount >= cupSize) {
            currentAmount -= cupSize;
            System.out.println("La taza se llenó completamente.");
        } else {
            int servedAmount = currentAmount;
            currentAmount = 0;
            System.out.println("No se pudo llenar completamente la taza. Se sirvieron " + servedAmount
                    + " unidades y la taza quedó parcial.");
        }
    }

    public void emptyCoffeeMaker() {
        currentAmount = 0;
    }

    public void addCoffee(int amount) {
        if (amount <= 0) {
            System.out.println("La cantidad de café debe ser mayor que cero.");
            return;
        }

        currentAmount = Math.min(currentAmount + amount, maxCapacity);
    }
}
