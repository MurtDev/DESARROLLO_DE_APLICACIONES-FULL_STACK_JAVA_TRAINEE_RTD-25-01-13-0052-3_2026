package com.example.coffee.maker;

public class Main {
    public static void main(String[] args) {
        CoffeeMaker coffeeMaker = new CoffeeMaker(100, 0);
        System.out.println("Capacidad máxima: " + coffeeMaker.getMaxCapacity());
        coffeeMaker.fillCoffeeMaker();
        coffeeMaker.serveCup(250);
        coffeeMaker.emptyCoffeeMaker();
        coffeeMaker.addCoffee(400);
        System.out.println("Después de agregar café: " + coffeeMaker.getCurrentAmount());
    }
}
