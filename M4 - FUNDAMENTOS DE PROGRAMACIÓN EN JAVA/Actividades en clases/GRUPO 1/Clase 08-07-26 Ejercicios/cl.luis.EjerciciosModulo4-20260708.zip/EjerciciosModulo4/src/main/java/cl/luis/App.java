package cl.luis;

import java.util.Scanner;

public class App {
    private static final Scanner SCANNER = new Scanner(System.in);

    public static void main(String[] args) {
        menuEjercicios();
        SCANNER.close();
    }

    private static void menuEjercicios() {
        int opcion;

        do {
            System.out.println("\nSeleccione un ejercicio:");
            System.out.println("1. Temperatura");
            System.out.println("2. Sistema de acceso");
            System.out.println("3. Clasificación por edad");
            System.out.println("4. Número positivo, negativo o cero");
            System.out.println("5. Aprobado o reprobado");
            System.out.println("6. Menú de opciones");
            System.out.println("0. Salida");
            System.out.print("Ingrese una opción: ");

            opcion = SCANNER.nextInt();
            SCANNER.nextLine();

            switch (opcion) {
                case 1:
                    temp();
                    break;
                case 2:
                    acceso();
                    break;
                case 3:
                    clasificacionEdad();
                    break;
                case 4:
                    revisarNumero();
                    break;
                case 5:
                    aprobadoReprobado();
                    break;
                case 6:
                    menuOpciones();
                    break;
                default:
                    System.out.println("Opción incorrecta.");
                    break;
            }
        } while (opcion != 0);
    }

    private static void temp() {
        System.out.print("Ingrese la temperatura en grados Celsius: ");
        double celsius = SCANNER.nextDouble();

        if (celsius > 30) {
            System.out.println("Hace mucho calor.");
        } else {
            System.out.println("No hace calor LOL");
        }
    }

    private static void acceso() {
        System.out.print("Ingrese su nombre de usuario: ");
        String usuario = SCANNER.nextLine();

        System.out.print("Ingrese su contraseña: ");
        String contrasena = SCANNER.nextLine();

        if ("admin".equals(usuario) && "1234".equals(contrasena)) {
            System.out.println("Acceso permitido.");
        } else {
            System.out.println("Usuario o contraseña incorrectos.");
        }
    }

    private static void clasificacionEdad() {
        System.out.print("Ingrese su edad: ");
        int edad = SCANNER.nextInt();

        if (edad >= 0 && edad <= 11) {
            System.out.println("Niño");
        } else if (edad >= 12 && edad <= 17) {
            System.out.println("Adolescente");
        } else if (edad >= 18 && edad <= 64) {
            System.out.println("Adulto");
        } else if (edad >= 65) {
            System.out.println("Adulto mayor");
        } else {
            System.out.println("Edad no válida.");
        }
    }

    private static void revisarNumero() {
        System.out.print("Ingrese un número entero: ");
        int numero = SCANNER.nextInt();

        if (numero > 0) {
            System.out.println("El número es positivo.");
        } else if (numero < 0) {
            System.out.println("El número es negativo.");
        } else {
            System.out.println("El número es cero.");
        }
    }

    private static void aprobadoReprobado() {
        System.out.print("Ingrese la primera nota: ");
        double nota1 = SCANNER.nextDouble();
        System.out.print("Ingrese la segunda nota: ");
        double nota2 = SCANNER.nextDouble();
        System.out.print("Ingrese la tercera nota: ");
        double nota3 = SCANNER.nextDouble();

        if (nota1 < 1.0 || nota1 > 7.0 || nota2 < 1.0 || nota2 > 7.0 || nota3 < 1.0 || nota3 > 7.0) {
            System.out.println("Una o más notas no son válidas.");
            return;
        }

        double promedio = (nota1 + nota2 + nota3) / 3;
        System.out.println("El promedio obtenido es: " + promedio);

        if (promedio >= 4.0) {
            System.out.println("Aprobado.");
        } else {
            System.out.println("Reprobado.");
        }
    }

    private static void menuOpciones() {
        System.out.println("1. Saludar");
        System.out.println("2. Mostrar fecha de nacimiento");
        System.out.println("3. Salir");
        System.out.print("Ingrese una opción: ");

        int opcion = SCANNER.nextInt();

        switch (opcion) {
            default:
                System.out.println("Opción incorrecta.");
                break;
            case 1:
                System.out.println("Hola, bienvenido al programa.");
                break;
            case 2:
                System.out.print("Ingrese su año de nacimiento: ");
                int anioNacimiento = SCANNER.nextInt();
                System.out.println("Tu año de nacimiento es: " + anioNacimiento);
                break;
            case 3:
                System.out.println("Programa finalizado.");
                break;
        }
    }
}
