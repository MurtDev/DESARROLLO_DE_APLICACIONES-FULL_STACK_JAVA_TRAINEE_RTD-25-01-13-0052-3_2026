package Ejercicios;
import java.util.Scanner;

public class NumeroPositivoNegativoCero {

	public static void main(String[] args) {
		// Creamos nuestro objeto scanner:
		Scanner objScanner = new Scanner(System.in);

		System.out.println("Ingrese número:");
		int numero = objScanner.nextInt();

		if (numero > 0) {
			System.out.println("El número es positivo.");
		} else if (numero < 0) {
			System.out.println("El número es negativo.");

		} else {
			System.out.println("El número es cero.");

		}

		// Cerramos el scanner
		objScanner.close();

	}

}

/*
 * ### Ejercicio 4: Número positivo, negativo o cero
 * 
 * Crea un programa en Java que solicite al usuario ingresar un número entero.
 * 
 * El programa debe evaluar el número ingresado y mostrar uno de los siguientes
 * mensajes:
 * 
 * Si el número es mayor que 0, mostrar: **El número es positivo.** Si el número
 * es menor que 0, mostrar: **El número es negativo.** Si el número es igual a
 * 0, mostrar: **El número es cero.*
 */