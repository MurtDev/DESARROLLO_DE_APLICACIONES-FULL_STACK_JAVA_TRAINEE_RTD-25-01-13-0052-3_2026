package Ejercicios;
import java.util.Scanner;
import java.util.Locale;

public class AprobadoOReprobado {

	public static void main(String[] args) {
		Scanner ObjScanner = new Scanner(System.in);

		// Configuramos el Scanner para que acepte el punto como decimal
		ObjScanner.useLocale(Locale.US);

		System.out.println("Ingrese nota 1: ");
		double nota1 = ObjScanner.nextDouble();

		System.out.println("Ingrese nota 2: ");
		double nota2 = ObjScanner.nextDouble();

		System.out.println("Ingrese nota 3: ");
		double nota3 = ObjScanner.nextDouble();

		double promedio = (nota1 + nota2 + nota3) / 3;

		if (nota1 < 1.0 || nota1 > 7.0 || nota2 < 1.0 || nota2 > 7.0 || nota3 < 1.0 || nota3 > 7.0) {
			System.out.println("Una o más notas no son válidas.");
		} else {

			if (promedio >= 4.0) { // redondeamo el valo usando %.1f
				System.out.printf("Aprobado su nota es: %.1f ", promedio);
			} else if (promedio < 4.0) {
				System.out.printf("Reprobado su nota es: %.1f", promedio);

			}
		}
		// Cerramos el scanner
		ObjScanner.close();

	}

}

/*
 * ### Ejercicio 5: Aprobado o reprobado
 * 
 * Crea un programa en Java que solicite al usuario ingresar tres notas.
 * 
 * Las notas deben estar en escala de 1.0 a 7.0.
 * 
 * El programa debe calcular el promedio de las tres notas.
 * 
 * Luego debe mostrar:
 * 
 * El promedio obtenido. Si el promedio es mayor o igual a 4.0, mostrar:
 * Aprobado. Si el promedio es menor a 4.0, mostrar: Reprobado.
 * 
 * Además:
 * 
 * Si alguna nota ingresada es menor que 1.0 o mayor que 7.0, mostrar: Una o más
 * notas no son válidas.
 */