package Ejercicios;
import java.util.Scanner;

public class SistemaDeAcceso {

	public static void main(String[] args) {
		// Creamos nuestro objeto scanner:
		Scanner objScanner = new Scanner(System.in);

		System.out.println("Ingrese su usuario:");
		String nombre = objScanner.nextLine();

		System.out.println("Ingrese su contraseña:");
		int contrasenia = objScanner.nextInt();

		// reemplazamos el == por una funcion equeals() para comprara textos.
		if (nombre.equals("admin") && contrasenia == 1234) {
			System.out.println("Acceso permitido.");

		} else {
			System.out.println("Usuario o contraseña incorrectos.");

		}

		// Cerramos el scanner
		objScanner.close();
	}

}

/*
 * ### Ejercicio 2: Sistema de acceso
 * 
 * Crea un programa en Java que simule un sistema de acceso.
 * 
 * El programa debe solicitar al usuario:
 * 
 * Su nombre de usuario. Su contraseña.
 * 
 * El usuario correcto será:
 ** 
 * admin**
 * 
 * La contraseña correcta será:
 ** 
 * 1234**
 * 
 * Si el usuario y la contraseña son correctos, el programa debe mostrar:
 ** 
 * Acceso permitido.**
 * 
 * En caso contrario, debe mostrar:
 ** 
 * Usuario o contraseña incorrectos.**
 */