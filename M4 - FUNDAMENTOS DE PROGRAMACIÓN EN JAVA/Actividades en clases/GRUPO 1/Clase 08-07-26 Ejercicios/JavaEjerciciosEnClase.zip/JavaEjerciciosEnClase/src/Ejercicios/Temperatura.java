package Ejercicios;
import java.util.Scanner;

public class Temperatura {

	public static void main(String[] args) {

		// Creamos nuestro objeto scanner:
		Scanner objScanner = new Scanner(System.in);

		System.out.println("Ingrese temperatura actual en grados:");
		Double grados = objScanner.nextDouble();

		if (grados >= 30) {
			System.out.println("** Hace mucho calor. **");

		}

		// Cerramos el scanner
		objScanner.close();

	}

}

/*
 * ### Ejercicio 1: Temperatura
 * 
 * Crea un programa en Java que solicite al usuario ingresar la temperatura
 * actual en grados Celsius.
 * 
 * El programa debe evaluar si la temperatura es mayor a 30 grados.
 * 
 * Si la temperatura supera los 30 grados, debe mostrar el siguiente mensaje:
 ** 
 * Hace mucho calor.**
 */