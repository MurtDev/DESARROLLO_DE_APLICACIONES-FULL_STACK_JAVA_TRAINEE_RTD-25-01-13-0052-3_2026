package Ejercicios;
import java.util.Scanner;
import java.util.Locale;

public class MenuDeOpciones {

	public static void main(String[] args) {
		Scanner ObjScanner = new Scanner(System.in);

		// Configuramos el Scanner para que acepte el punto como decimal
		ObjScanner.useLocale(Locale.US);

		System.out.println("1. Saludar ");
		System.out.println("2. Fecha de Nacimiento ");
		System.out.println("3. Salir ");

		// Recibimo el número de la opción del menú
		int opcion = ObjScanner.nextInt();

		if (opcion == 1) {
			System.out.println("Hola, bienvenido al programa.");

		} else if (opcion == 2) {
			System.out.println("Ingrese su año de nacimiento:");
			int anio = ObjScanner.nextInt();
			System.out.println("Tu año de nacimiento es: " + anio);
		} else if (opcion == 3) {
			System.out.println("Programa finalizado.");
		} else {
			System.out.println("Opción incorrecta.");
		}

		// Cerramos el scanner
		ObjScanner.close();

	}

}

/*
 * ### Ejercicio 6: Menú de opciones
 * 
 * Crea un programa en Java que muestre el siguiente menú al usuario:
 * 
 * 1. Saludar 2. Mostrar fecha de nacimiento 3. Salir
 * 
 * Luego, el programa debe solicitar al usuario que ingrese una opción.
 * 
 * Según la opción ingresada, debe mostrar:
 * 
 * Si ingresa 1, mostrar: **Hola, bienvenido al programa.** Si ingresa 2,
 * solicitar el año de nacimiento y mostrar: Tu año de nacimiento es: [año
 * ingresado]** Si ingresa 3, mostrar: **Programa finalizado.** Si ingresa otra
 * opción, mostrar: **Opción incorrecta.**
 */