package Ejercicios;
import java.util.Scanner;

public class ClasificacionPorEdad {

	public static void main(String[] args) {
		// Creamos nuestro objeto scanner:
		Scanner objScanner = new Scanner(System.in);

		System.out.println("Ingrese su edad:");
		int edad = objScanner.nextInt();

		if (edad >= 0 && edad <= 11) {
			System.out.println("Niño");
		} else if (edad >= 12 && edad <= 17) {
			System.out.println("Adolescente");

		} else if (edad >= 18 && edad <= 64) {
			System.out.println("Adulto");

		} else if (edad >= 65) {
			System.out.println("Adulto mayor");

		}

		// Cerramos el scanner
		objScanner.close();

	}

}

/*
 * ### Ejercicio 3: Clasificación por edad
 * 
 * Crea un programa en Java que solicite al usuario ingresar su edad.
 * 
 * El programa debe mostrar una categoría según la edad ingresada:
 * 
 * Si tiene entre 0 y 11 años, mostrar: **Niño** Si tiene entre 12 y 17 años,
 * mostrar: **Adolescente** Si tiene entre 18 y 64 años, mostrar: **Adulto** Si
 * tiene 65 años o más, mostrar: **Adulto mayor**
 */