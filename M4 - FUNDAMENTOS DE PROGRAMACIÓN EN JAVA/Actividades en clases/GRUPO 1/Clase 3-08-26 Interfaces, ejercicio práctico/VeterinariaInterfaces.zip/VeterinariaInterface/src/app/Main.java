package app;

import model.Gato;
import model.Perro;

import java.util.ArrayList;

import interfaces.Vacunable;
//import model.*;
import model.Animal;
import model.Cocodrilo;

public class Main {
	private static int contador = 1;
	
	public static void salto() {
		System.out.printf("%n");
		System.out.println("══════════════════════════════");

		contador++;
		System.out.printf("%n");
		}
	
	//Polimorfismo con métodos
	public static void presentarAnimal(Animal animal) {
		System.out.println("Nombre: " + animal.getNombre());
		System.out.println("Peso: " + animal.getPeso());
		//System.out.println("Color: " + animal.getColor()); no podemos hacerlo, animal no tiene getColor solo Gato
		System.out.println("Sonido: " + animal.emitirSonido());
	}
	
	//Polimorfismo con interfaces en un método
	public static void vacunarPaciente(Vacunable paciente) {
		paciente.vacunar();
	}
	
			
	public static void main(String[] args) {
		
		Perro firulais = new Perro("Firulais", 14.4, "Labrador");
		
		firulais.mostrarInformación();
		firulais.comer();
		firulais.dormir();
		System.out.println(firulais.emitirSonido());
		System.out.println(firulais.getRaza());
		vacunarPaciente(firulais);
		System.out.println(firulais.estaVacunado());
		
		firulais.domesticar();
		System.out.println(firulais.estaDomesticado());
				
		firulais.jugar();
		
		
		System.out.println("------------------------------------");
		Gato gatuno = new Gato("Gatuno", 8.4, "Angora", "gris");
		gatuno.mostrarInformación();
		gatuno.comer();
		gatuno.dormir();
		System.out.println(gatuno.emitirSonido());
				
		vacunarPaciente(gatuno);
		System.out.println(gatuno.estaVacunado());
		gatuno.domesticar();
		System.out.println(gatuno.estaDomesticado());
				
		gatuno.jugar();
		
		System.out.println("------------------------------------");
		Cocodrilo aquiles = new Cocodrilo("Aquiles", 50, 75);
		aquiles.mostrarInformación();
		aquiles.comer();
		aquiles.dormir();
		System.out.println(aquiles.emitirSonido());
		
		//vacunarPaciente(aquiles);
		
	}

}
