package interfaces;

public interface Vacunable {
	public static final String TIPO_VACUNA = "Antirrábica";
	// Java lo convierte automáticamente en --> public static final String TIPO_VACUNA = "Antirrábica";
	
	int DOSIS_ANUALES = 2;// Java agrega de forma automática --> public static final
	
	public abstract void vacunar();//Se implementan en las clases que usen la interface
	
	boolean estaVacunado();
}

/*
 
En Java, una interfaz es una especie de contrato. 
Define un conjunto de reglas en forma de métodos y constantes, 
pero sin implementar su código. 

Las clases que deciden usar (implementar) esta interfaz 
están obligadas a escribir el código para cumplir 
con todas las acciones declaradas en ella


¿Por qué se utilizan?

Simulan herencia múltiple: A diferencia de las clases, 
una clase en Java puede implementar varias interfaces a la vez.

Polimorfismo: Permite tratar a objetos de diferentes clases 
de manera uniforme si comparten la misma interfaz.

Estandarización: Garantiza que distintas clases tengan el mismo conjunto 
de comportamientos básicos asegurando un diseño desacoplado.


Reglas básicas

Todos los métodos son públicos (public) y abstractos por defecto 
(no tienen llaves {}).

Todas las variables son públicas, estáticas (static) 
y constantes (final).

Una clase usa la palabra reservada implements para adoptar una interfaz.

 
 */



/*
 La regla general para nombres

En Java, las interfaces suelen nombrarse con un adjetivo 
o una palabra que describa una capacidad, normalmente terminada en:

-able
-ible
-dor / -ora (en español)

Porque responden a la pregunta:

¿Qué puede hacer o qué capacidad tiene este objeto?

| Interfaz       | Significado        |
| -------------- | ------------------ |
| `Vacunable`    | Puede vacunarse    |
| `Imprimible`   | Puede imprimirse   |
| `Comparable`   | Puede compararse   |
| `Serializable` | Puede serializarse |
| `Volador`      | Puede volar        |
| `Nadador`      | Puede nadar        |
| `Recargable`   | Puede recargarse   |
| `Pagable`      | Puede pagarse      |
| `Editable`     | Puede editarse     |
| `Exportable`   | Puede exportarse   |
 
 */

/*
 Comparación

| Clase Abstracta                   | Interfaz                             |
| --------------------------------- | ------------------------------------ |
| Representa qué es un objeto       | Representa qué puede hacer o que puede hacerse con el 
| Puede tener atributos             | No almacena estado del objeto        |
| Tiene constructor                 | No tiene constructor                 |
| Puede tener métodos implementados | Declara comportamientos obligatorios |
| Se utiliza con `extends`          | Se utiliza con `implements`          |
 */


