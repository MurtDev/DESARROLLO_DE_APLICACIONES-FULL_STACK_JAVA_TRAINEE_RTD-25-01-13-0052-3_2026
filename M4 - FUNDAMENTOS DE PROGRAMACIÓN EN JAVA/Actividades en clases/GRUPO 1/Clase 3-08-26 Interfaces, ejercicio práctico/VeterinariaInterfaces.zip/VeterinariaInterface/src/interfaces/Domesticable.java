package interfaces;

public interface Domesticable {
	int EDAD_MAXIMA_DOMESTICACION = 10;
	String TIPO_IDENTIFICACION = "Microchip";
	
	void domesticar();
	void jugar();
	boolean estaDomesticado();
}
