package model;

import interfaces.Domesticable;
import interfaces.Vacunable;

public class Perro extends Animal implements Vacunable, Domesticable{
	private String raza;
	private boolean vacunado;
	private boolean domesticado;
	
	public Perro(String nombre, double peso, String raza) {
		super(nombre, peso);
		this.raza = raza;
	}
	
	@Override
	public void vacunar() {
		vacunado = true;
		System.out.println(
				getNombre()
				+ " fue vacunado con la vacuna "
				+ Vacunable.TIPO_VACUNA);
		
		System.out.println(
				"Dosis anuales recomendadas: "
				+ Vacunable.DOSIS_ANUALES);
	}
	
	@Override
	public boolean estaVacunado() {
		return vacunado;
	}
	
	public void domesticar() {
		domesticado = true;
		
		System.out.println(getNombre() + " ha sido domesticado");
	}
	
	public void jugar() {
		System.out.println(getNombre() + " juega con una pelota");
	}
	
	public boolean estaDomesticado() {
		return domesticado;
	}
	
	
	public String getRaza() {
		return raza;
	}

	public void setRaza(String raza) {
		this.raza = raza;
	}
	
	@Override
	public void mostrarInformación() {
		super.mostrarInformación();
		System.out.printf("Raza: %s %n", raza);
	}
	
	@Override
	public String emitirSonido() {
		return "Guau!! Guau!!";
	}
	
	@Override
	public void dormir() {
		super.dormir();
	}
	
	
}
