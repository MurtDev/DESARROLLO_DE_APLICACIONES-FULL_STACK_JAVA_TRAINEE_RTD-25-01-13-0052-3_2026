package model;

public class Cocodrilo extends Animal{
	private int numeroDientes;
	

	public Cocodrilo(String nombre, double peso, int numeroDientes) {
		super(nombre, peso);
		this.numeroDientes = numeroDientes;
	}

		
	@Override
	public void mostrarInformación() {
		super.mostrarInformación();
		System.out.printf("Numero de Dientes: %d %n", numeroDientes);
	}
	
	@Override
	public String emitirSonido() {
		return "Grrrrr!!";
	}
	
	@Override
	public void dormir() {
		super.dormir();
	}

}
