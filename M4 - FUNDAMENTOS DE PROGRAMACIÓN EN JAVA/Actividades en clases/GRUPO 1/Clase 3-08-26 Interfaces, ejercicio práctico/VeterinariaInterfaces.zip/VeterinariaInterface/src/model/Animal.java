package model;

public class Animal {
	protected String nombre;
	protected double peso;
	
	//Constructor
	public Animal(String nombre, double peso) {
		this.nombre = nombre;
		this.peso = peso;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}
		
	public void comer() {
		System.out.println("El animal está comiendo");
	} 
	
	public void dormir() {
		System.out.println("El animal está durmiendo");
	}
	
	public String emitirSonido() {
		return "Sonido del animal";
	}
	
	public void mostrarInformación() {
		System.out.printf("Nombre: %s %nPeso: %.2f kg%n", nombre, peso);
	}
}
