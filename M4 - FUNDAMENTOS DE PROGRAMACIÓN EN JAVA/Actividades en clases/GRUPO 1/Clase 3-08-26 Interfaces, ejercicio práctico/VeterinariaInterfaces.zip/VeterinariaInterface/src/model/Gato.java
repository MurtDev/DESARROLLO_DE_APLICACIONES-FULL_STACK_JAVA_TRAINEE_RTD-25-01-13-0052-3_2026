package model;

import interfaces.Domesticable;
import interfaces.Vacunable;

public class Gato extends Animal implements Vacunable, Domesticable{
	private String raza;
	private String color;
	private boolean vacunado;
	private boolean domesticado;
	
	public Gato(String nombre, double peso, String raza, String color) {
		super(nombre, peso);
		this.raza = raza;
		this.color = color;
	}
	
	@Override
	public void vacunar() {
		vacunado = true;
		System.out.println(
				getNombre()
				+ " fue vacunado con la vacuna "
				+ Vacunable.TIPO_VACUNA);
		
		System.out.println(
				"Dosis anuales recomendadas: "
				+ Vacunable.DOSIS_ANUALES);
	}
	
	@Override
	public boolean estaVacunado() {
		return vacunado;
	}
	
	public void domesticar() {
		domesticado = true;
		
		System.out.println(getNombre() + " ha sido domesticado");
	}
	
	public void jugar() {
		System.out.println(getNombre() + " juega con una lana");
	}
	
	public boolean estaDomesticado() {
		return domesticado;
	}
	
	
	
	public String getRaza() {
		return raza;
	}

	public void setRaza(String raza) {
		this.raza = raza;
	}
	
	@Override
	public void mostrarInformación() {
		super.mostrarInformación();
		System.out.printf("Raza: %s %nColor: %s", raza, color);
	}

	@Override
	public String emitirSonido() {
		return "Miaaaauu!! Miaaaauu!!";
	}
}
