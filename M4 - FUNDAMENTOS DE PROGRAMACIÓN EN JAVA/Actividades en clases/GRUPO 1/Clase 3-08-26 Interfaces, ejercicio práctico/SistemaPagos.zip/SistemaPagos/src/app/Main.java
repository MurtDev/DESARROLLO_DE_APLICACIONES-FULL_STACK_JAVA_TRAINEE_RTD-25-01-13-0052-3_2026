package app;

import java.util.ArrayList;

import interfaces.Pagable;
import model.*;

public class Main {

	public static void realizarPago(Pagable metodo, double monto) {
		metodo.pagar(monto);
	}
	
	public static void main(String[] args) {
		TarjetaCredito credito = new TarjetaCredito("Roberto", 1000000.0, 6);
		TarjetaDebito debito = new TarjetaDebito("José", 2000000.0, "Chile");
		CuentaDigital digital = new CuentaDigital("Luis", 3000000.0, "Tenpo");
		
		ArrayList<FormaPago> formasPago = new ArrayList<>();
		
		formasPago.add(debito);
		formasPago.add(credito);
		formasPago.add(digital);
		
		System.out.println("==== FORMAS DE PAGO ====");
		
		for (FormaPago forma: formasPago) {
			System.out.println("-----------------------");
			forma.mostrarInformacion();
			System.out.println("");
			System.out.println("Tipo: " + forma.obtenerTipo());
		}
		
		realizarPago(credito, 850000);
		realizarPago(debito, 500000);
		realizarPago(digital, 600000);
		
		System.out.println("==== FORMAS DE PAGO SALDOS ACTUALIZADOS ====");
		for (FormaPago forma: formasPago) {
			System.out.println("-----------------------");
			forma.mostrarInformacion();
			System.out.println("");
			System.out.println("Tipo: " + forma.obtenerTipo());
		}
		

	}

}
