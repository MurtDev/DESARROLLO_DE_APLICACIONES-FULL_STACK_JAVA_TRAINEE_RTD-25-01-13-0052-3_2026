package interfaces;

public interface Pagable {
	void pagar(double monto);
}
