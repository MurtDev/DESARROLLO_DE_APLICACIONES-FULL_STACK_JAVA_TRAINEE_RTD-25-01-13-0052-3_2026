package model;

import interfaces.Pagable;

public class TarjetaDebito 
						extends FormaPago
						implements Pagable{
	
	private String banco;

	public TarjetaDebito(String titular, double saldo, String banco) {
		super(titular, saldo);
		this.banco = banco;
	}
	
	@Override
	public String obtenerTipo() {
		return "Tarjeta de débito";
	}
	
	@Override
	public void mostrarInformacion() {
		super.mostrarInformacion();
		System.out.print("Banco " + banco);
	}
	
	@Override
	public void pagar(double monto) {
		if(monto <= 0) {
			System.out.println("El monto debe ser mayor que cero.");
			return;
		}
		
		if (monto > getSaldo()) {
			System.out.println("El saldo no es suficiente para realizar el pago");
			return;
		}
		
		setSaldo(getSaldo() - monto);
		System.out.println("Pago realizado correctamente con tarjeta de débito");
	}
	
	
	
	
}
