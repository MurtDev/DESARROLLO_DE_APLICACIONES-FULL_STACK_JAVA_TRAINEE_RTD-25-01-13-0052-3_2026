package model;

import interfaces.Pagable;

public class TarjetaCredito 
						extends FormaPago
						implements Pagable{
	
	private int cantidadCuotas;

	public TarjetaCredito(String titular, double saldo, int cantidadCuotas) {
		super(titular, saldo);
		this.cantidadCuotas = cantidadCuotas;
	}
	
	@Override
	public String obtenerTipo() {
		return "Tarjeta de crédito";
	}
	
	@Override
	public void mostrarInformacion() {
		super.mostrarInformacion();
	}
	
	@Override
	public void pagar(double monto) {
		if(monto <= 0) {
			System.out.println("El monto debe ser mayor que cero.");
			return;
		}
		
		if (monto > getSaldo()) {
			System.out.println("El saldo no es suficiente para realizar el pago");
			return;
		}
		
		setSaldo(getSaldo() - monto);
		System.out.println("Pago realizado correctamente con tarjeta de crédito");
	}
	
	
	
	
}
