package model;

public abstract class FormaPago {
	private String titular;
	private double saldo;
	
	public FormaPago(String titular, double saldo) {
		this.titular = titular;
		this.saldo = saldo;
	}

	public String getTitular() {
		return titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	public void mostrarInformacion() {
		System.out.printf(
				"Titular: %s %nSaldo: %f%n",  
				titular, saldo);
	}
	
	public abstract String obtenerTipo();
	
}
