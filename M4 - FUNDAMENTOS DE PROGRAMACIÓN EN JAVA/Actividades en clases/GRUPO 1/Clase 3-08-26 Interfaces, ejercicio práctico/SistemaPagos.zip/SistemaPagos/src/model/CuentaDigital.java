package model;

import interfaces.Pagable;

public class CuentaDigital 
						extends FormaPago
						implements Pagable{
	
	private String plataforma;

	public CuentaDigital(String titular, double saldo, String plataforma) {
		super(titular, saldo);
		this.plataforma = plataforma;
	}
	
	@Override
	public String obtenerTipo() {
		return "Cuenta Digital";
	}
	
	@Override
	public void mostrarInformacion() {
		super.mostrarInformacion();
		System.out.print("Banco " + plataforma);
	}
	
	@Override
	public void pagar(double monto) {
		if(monto <= 0) {
			System.out.println("El monto debe ser mayor que cero.");
			return;
		}
		
		if (monto > getSaldo()) {
			System.out.println("El saldo no es suficiente para realizar el pago");
			return;
		}
		
		setSaldo(getSaldo() - monto);
		System.out.println("Pago realizado correctamente con " + plataforma);
	}
	
	
	
	
}
