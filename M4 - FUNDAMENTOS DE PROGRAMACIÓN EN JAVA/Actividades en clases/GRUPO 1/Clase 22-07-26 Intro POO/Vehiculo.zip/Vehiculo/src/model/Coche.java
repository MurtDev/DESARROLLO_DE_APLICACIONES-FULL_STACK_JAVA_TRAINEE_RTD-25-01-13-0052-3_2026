package model;

import java.util.Random;

public class Coche {
	private int id;
	private String marca;
	private String color;
	private Rueda[] ruedas;
	private Carroceria carroceria;
	

	//Método constructor
	public Coche() {
		System.out.println("========== Constructor sin parámetros =========="); 
		Random rand = new Random();
	     // Generar un número entero entre 0 y 99 (el límite superior es exclusivo)
	     this.id = rand.nextInt(100);
	}
	
	public Coche(int id, String marca, String color, String tipoCarroceria, int numeroPuertas) {
		System.out.println("========== Constructor con parámetros =========="); 
		this.id = id;
		this.marca = marca;
		this.color = color;
		
		//Composición
		/*
		 La composición es una relación donde un objeto "está formado por" otros objetos. Por
		ejemplo, una casa está formada por paredes, puertas y ventanas. Un empleado está formado
		por información personal.
		En la composición, los objetos relacionados dependen totalmente del objeto contenedor. Si
		eliminamos el objeto contenedor, los objetos contenidos dejan de existir.
		*/
		this.carroceria = new Carroceria(tipoCarroceria, numeroPuertas);
				
	}
	
	
	
	public Carroceria getCarroceria() {
		return carroceria;
	}

	public void setCarroceria(Carroceria carroceria) {
		this.carroceria = carroceria;
	}

	public Rueda[] getRuedas() {
		return ruedas;
	}
	
	public void setRuedas(Rueda[] nuevasRuedas) {
		this.ruedas = nuevasRuedas;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getId() {
		return id;
	}
	
	
	//Método getter
	/*
	 Los accesadores o métodos get se utilizan para consultar el estado de un objeto .
	Un método get se declara public y a continuación se indica el tipo de dato que devuelve.
	El método no recibe parámetros y en el cuerpo del método se utiliza return para devolver el
	valor correspondiente al atributo requerido.*/
	/*public String getMarca() {
		return this.marca;
	}
	
	public String getColor() {
		return this.color;
	}
	
	public int getId() {
		return this.id;
	}*/
	
	//Métodos Setters
	/*Los mutadores o métodos set se utilizan para modificar el estado de un objeto .
	Un método set se declara public y devuelve void.
	La lista de parámetros incluye el tipo y el valor a modificar y en el cuerpo del método se
	asigna el parámetro de la declaración al atributo del objeto.*/
	/*public void setMarca(String nuevaMarca) {
		this.marca = nuevaMarca;
	}
	
	public void setColor(String nuevoColor) {
		this.color = nuevoColor;
	}*/
	
	
	
}
