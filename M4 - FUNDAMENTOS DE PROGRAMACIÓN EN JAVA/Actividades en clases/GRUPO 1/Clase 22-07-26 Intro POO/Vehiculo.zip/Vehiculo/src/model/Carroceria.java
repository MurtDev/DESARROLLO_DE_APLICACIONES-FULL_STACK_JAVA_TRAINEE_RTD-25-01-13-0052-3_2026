package model;

public class Carroceria {
	private String tipo;
	private int numeroPuertas;
	
	public Carroceria(String tipo, int numeroPuertas) {
		this.tipo = tipo;
		this.numeroPuertas = numeroPuertas;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getNumeroPuertas() {
		return numeroPuertas;
	}

	public void setNumeroPuertas(int numeroPuertas) {
		this.numeroPuertas = numeroPuertas;
	}

	@Override
	public String toString() {
		return "Carroceria [tipo=" + tipo + ", numeroPuertas=" + numeroPuertas + "]";
	}
	
	
}
