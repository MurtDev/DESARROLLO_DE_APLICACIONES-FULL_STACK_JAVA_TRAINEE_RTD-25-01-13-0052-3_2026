package model;

public class Rueda {
	//Atributos --> caracteristicas del objeto
	private String marca;
	private int aro;//tamaño
	
	//Constructor --> método para instanciar nuestro objeto
	public Rueda(String marca, int aro) {
		this.marca = marca;
		this.aro = aro;
	}
	
	//Métodos
	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public int getAro() {
		return aro;
	}

	public void setAro(int aro) {
		this.aro = aro;
	}

	@Override
	public String toString() {
		return "marca:" + marca + ", aro:" + aro;
	}
	
	
}
