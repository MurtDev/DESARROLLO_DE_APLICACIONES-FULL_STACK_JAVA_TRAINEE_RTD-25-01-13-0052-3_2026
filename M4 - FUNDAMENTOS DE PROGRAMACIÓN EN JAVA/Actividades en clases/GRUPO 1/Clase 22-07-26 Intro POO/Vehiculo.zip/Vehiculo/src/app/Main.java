package app;

import model.Coche;
import model.Rueda;
import model.Carroceria;

public class Main {

	public static void main(String[] args) {
		Coche miAuto1 = new Coche(123, "Nissan", "Negro", "4x4", 4);
		Coche miAuto2 = new Coche(321, "Toyota", "Negro", "SUV", 5);
		Coche miAuto3 = new Coche();
		
		/*La agregación es una relación donde un objeto "tiene" a otros objetos. Por ejemplo, un
		automóvil tiene ruedas, un edificio tiene ventanas.
		En la agregación, los objetos relacionados pueden existir de forma independiente . Si
		eliminamos el objeto contenedor, los objetos contenidos pueden seguir existiendo.*/
		Rueda ruedaAro15 = new Rueda("Goodyear", 15);
		Rueda ruedaAro16 = new Rueda("Michelin", 16);
		Rueda ruedaAro17 = new Rueda("Michelin", 17);
		Rueda ruedaAro18 = new Rueda("Bridgestone ", 18);
				
		
		System.out.println("========== AUTO 1 ==========");
		System.out.println(miAuto1.getId());
		System.out.println(miAuto1.getMarca());
		System.out.println(miAuto1.getColor());
		System.out.println(miAuto1.getCarroceria().getTipo());
		System.out.println(miAuto1.getCarroceria().getNumeroPuertas());
		//System.out.println(miAuto1.getRuedas());
		System.out.println("========== AUTO 2 ==========");
		System.out.println(miAuto2.getId());
		System.out.println(miAuto2.getMarca());
		System.out.println(miAuto2.getColor());
		System.out.println(miAuto2.getCarroceria());
		//System.out.println(miAuto2.getRuedas());
		System.out.println("========== AUTO 3 ==========");
		System.out.println(miAuto3.getId());
		System.out.println(miAuto3.getMarca());
		System.out.println(miAuto3.getColor());
		//System.out.println(miAuto3.getRuedas());
		
		System.out.println("========== AUTO 1 MODIFICADO ==========");
		miAuto1.setColor("Rojo"); 
		
		Rueda[] ruedasParaAuto1 = {ruedaAro15, ruedaAro16, ruedaAro17, ruedaAro18};
		
		miAuto1.setRuedas(ruedasParaAuto1);
		
		//Forma 1, lo hicimos usando agregación
		Carroceria carroceriaAuto1 = new Carroceria("suv", 4);
		miAuto1.setCarroceria(carroceriaAuto1);
		
		//Forma 2, modificando la carroceria con la que se creo el auto, composición
		miAuto1.getCarroceria().setTipo("Sedán");
		miAuto1.getCarroceria().setNumeroPuertas(5);
		
		
		System.out.println(miAuto1.getId());
		System.out.println(miAuto1.getMarca());
		System.out.println(miAuto1.getColor());
		System.out.println(miAuto1.getCarroceria());
		
		/* Opción 1
		for (Rueda rueda : miAuto1.getRuedas()) {
			System.out.println(rueda.getMarca());
			System.out.println(rueda.getAro());
		}*/
		
		// Opción 2
		for (Rueda rueda : miAuto1.getRuedas()) {
			System.out.println(rueda);
		}
		
		
		
		System.out.println("========== AUTO 3 MODIFICADO ==========");
		miAuto3.setMarca("Tesla");
		miAuto3.setColor("Rosado"); 
		System.out.println(miAuto3.getId());
		System.out.println(miAuto3.getMarca());
		System.out.println(miAuto3.getColor());
		
		
		
	}

}
