package app;

import model.Gato;
import model.Perro;

import java.util.ArrayList;

//import model.*;
import model.Animal;

public class Main {
	private static int contador = 1;
	
	public static void salto() {
		System.out.printf("%n");
		System.out.println("══════════════════════════════");

		contador++;
		System.out.printf("%n");
		}
	
	//Perro firulais
	public static void presentarAnimal(Animal animal) {
		System.out.println("Nombre: " + animal.getNombre());
		System.out.println("Peso: " + animal.getPeso());
		//System.out.println("Color: " + animal.getColor()); no podemos hacerlo, animal no tiene getColor solo Gato
		System.out.println("Sonido: " + animal.emitirSonido());
	}
	
	/*Sin polimorfismo tendríamos que crear métodos separados para acada animal
	 presentarPerro(Perro perro)
	 presentarGato(Gato gato)
	 presentarCaballo(Caballo caballo)
	 presentarConejo(Conejo conejo)
	 presentarAve(Ave ave)
	 presentarPorcino(Porcino porcino)
	 
	 
	 con Polimorfismo hacemos
	 
	 presentarAnimal(Animal animal) --> perro, gato, caballo, conejo, ave, porcino
	 */
	
	
	
	public static void main(String[] args) {
		
		Perro firulais = new Perro("Firulais", 14.4, "Labrador");
		
		firulais.mostrarInformación();
		firulais.comer();
		firulais.dormir();
		System.out.println(firulais.emitirSonido());
		System.out.println(firulais.getRaza());
		//System.out.println(firulais.getPeso());
		//recuperación del peso usando el método de la padre "Animal"
		
		System.out.println("-----------------");
		Gato gatuno = new Gato("Gatuno", 8.4, "Angora", "gris");
		gatuno.mostrarInformación();
		gatuno.comer();
		gatuno.dormir();
		System.out.println(gatuno.emitirSonido());
		
   //tipo general          //Tipo especifíco
		Animal animal1 = new Perro("Boby", 18.5, "Pastor Alemán");
		Animal animal2 = new Gato("Aquiles", 6.4, "Angora", "gris");
		
		salto();
		System.out.println(animal1.emitirSonido());
		System.out.println(animal2.emitirSonido());
		
		System.out.println("============ Perro =============");
		//System.out.println(animal1.getRaza()); --> la clase Animal no tiene el método getRaza

		animal1.mostrarInformación();
		
		System.out.println("============= Gato ============");
		animal2.mostrarInformación();
		
		System.out.println("");
		System.out.println("========= Ejemplo con método que recibe Animal ========");
		
		System.out.println("============ Firualias =============");
		presentarAnimal(firulais);
		System.out.println("============ Gatuno =============");
		presentarAnimal(gatuno);
		
		System.out.println("============ animal1 =============");
		presentarAnimal(animal1);
		

		System.out.println("============ animal2 =============");
		presentarAnimal(animal2);
		
		System.out.println("============ Polimorfismo mediante ArryList =============");
		
		ArrayList<Animal> refugioAnimales = new ArrayList<>();
		
		refugioAnimales.add(firulais);
		refugioAnimales.add(gatuno);
		refugioAnimales.add(animal1);
		refugioAnimales.add(animal2);
		
		for (Animal animal : refugioAnimales) {
			salto();
			animal.mostrarInformación();
			salto();
		}
		
		
		
		
		
		
		
		
		
	}

}
