package model;

public class Gato extends Animal{
	private String raza;
	private String color;
	
	public Gato(String nombre, double peso, String raza, String color) {
		super(nombre, peso);
		this.raza = raza;
		this.color = color;
	}

	public String getRaza() {
		return raza;
	}

	public void setRaza(String raza) {
		this.raza = raza;
	}
	
	@Override
	public void mostrarInformación() {
		super.mostrarInformación();
		System.out.printf("Raza: %s %nColor: %s", raza, color);
	}

	@Override
	public String emitirSonido() {
		return "Miaaaauu!! Miaaaauu!!";
	}
}
