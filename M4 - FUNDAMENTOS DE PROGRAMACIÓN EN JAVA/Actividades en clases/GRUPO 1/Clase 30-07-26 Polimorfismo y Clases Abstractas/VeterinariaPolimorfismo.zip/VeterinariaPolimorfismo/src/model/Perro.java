package model;

public class Perro extends Animal{
	private String raza;
	
	public Perro(String nombre, double peso, String raza) {
		super(nombre, peso);
		this.raza = raza;
	}

	public String getRaza() {
		return raza;
	}

	public void setRaza(String raza) {
		this.raza = raza;
	}
	
	@Override
	public void mostrarInformación() {
		super.mostrarInformación();
		System.out.printf("Raza: %s %n", raza);
	}
	
	@Override
	public String emitirSonido() {
		return "Guau!! Guau!!";
	}
	
	@Override
	public void dormir() {
		super.dormir();
	}
}
