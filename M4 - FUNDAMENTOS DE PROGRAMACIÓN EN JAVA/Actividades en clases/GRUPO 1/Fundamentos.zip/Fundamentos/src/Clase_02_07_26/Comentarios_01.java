package Clase_02_07_26;

public class Comentarios_01 {

	public static void main(String[] args) {
		//**************** COMENTARIOS ***************************
		
		/*1. De una sola línea Se utilizan para notas cortas, explicar instrucciones 
		simples o desactivar temporalmente una línea de código.*/
		
		//Esto es un comentario de una línea
		
		/*
		2. De varias líneas Ideales para explicaciones más extensas, detallar algoritmos 
		o bloquear bloques enteros de código.
		*/
		
		/*
		Este es un comentario de varias líneas.
		Puedes escribir todo el texto que necesites
		y saltar líneas sin que afecte el programa.
		*/
		
		/*
		3. De documentación (Javadoc)
		Documentar en Java se realiza principalmente utilizando Javadoc, un estándar de Oracle.
		Sirven para generar documentación oficial sobre clases, interfaces y métodos. 
		*/
		System.out.print(calculadoraArea(5));
	}

	
	/*
	 * @author Nombre Autor
	 * @version 1.0
	 * @param radio: El radio del círculo
	 * @return El área calculada
	 * */
	public static double calculadoraArea(double radio) {
		return Math.PI * radio * radio;
	}
}
