package Clase_02_07_26;

public class Conversion_05 {

	public static void main(String[] args) {
		//*********************** Conversión de tipos (Casting) ***************
		//Conversión implícita
		int edad = 25;
		double numero = edad;//No pierde información
		
		System.out.println(numero);
		
		//Conversión Explícita
		double estatura = 1.67;
		System.out.println(estatura);
		
		int entero = (int) estatura;//Si pierde información
		System.out.println(entero);
		
		//Ejemplo 1 
		char letra = '2';
		int numeroLetra = (int) letra;
		

		//Uso de métodos utilitarios
		//Ejemplo 1
		String datoTextual = "42.5";
		System.out.println(datoTextual);
		
		double datoDecimal = Double.parseDouble(datoTextual);
		System.out.println(datoDecimal);
		
		//Ejemplo 2
		String texto = "25";
		System.out.println(texto);
		
		int edadDos = Integer.parseInt(texto);
		System.out.println(edadDos);
		
		//Y al inverso
		String numeroTres = String.valueOf(edadDos);
		System.out.println(numeroTres);
		
		//Conversión de número a texto
		String textoPuntos = String.valueOf(500);
		
		boolean valor = Boolean.parseBoolean("true");
		
		/*[!WARNING]
		 * Si la cadena no tiene el formato numérico correcto, 
		 * estos métodos lanzarán una excepción del tipo NumberFormatException.
		 * */

	}

}
