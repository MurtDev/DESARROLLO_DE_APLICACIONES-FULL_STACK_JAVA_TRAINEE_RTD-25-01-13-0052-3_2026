package Clase_02_07_26;

public class Variables_02 {

	public static void main(String[] args) {
		//*************** VARIABLES *******************
		/*
		Una variable es una caja etiquetada.

		+------------+
		|    edad    |
		+------------+
		|     25     |
		+------------+

		La caja puede cambiar su contenido.
		*/
		
		/*
		Nombrar variables correctamente en Java mejora la legibilidad y el mantenimiento del código. 
		Aplica siempre la convención camelCase, donde la primera letra es minúscula y 
		la primera letra de cada palabra posterior es mayúscula (ej. precioTotal).


		Sigue estas reglas y recomendaciones clave:

		- camelCase estricto: Comienza con minúscula y pon en mayúscula la primera letra de las siguientes palabras (ej. nombreUsuario, fechaNacimiento).
		- Nombres descriptivos: Usa nombres que expliquen el propósito de la variable. Evita abreviaturas confusas; es mejor escribir numeroDeIntentos que nIntentos.
		- Distinción de mayúsculas: Recuerda que Java es sensible a las mayúsculas; edad y Edad son variables distintas.
		- Constantes y Variables Globales: Escríbelas en MAYÚSCULAS y separa las palabras con guiones bajos (ej. MAXIMO_INTENTOS, TASA_IMPUESTO).
		- Evita caracteres extraños: No uses el símbolo de dólar $ ni guiones bajos _ al inicio del nombre.
		- Palabras reservadas: Nunca utilices palabras clave de Java (como class, int, for, static) como nombres.


		- Puede comenzar con letra

		- Puede comenzar con _

		- Puede comenzar con $

		- No puede comenzar con número

		*/
		
		//Declaración de una variables
		int edad;
		
		//Inicialización
		edad = 42;
		
		//Declaración e inicialización
		int cantidad = 25;
		
		//Java moderno (JDK 25) --> También existe la inferencia de tipos con var
		var nombre = "Juan"; //  --> String
		var sueldo = 1500000; // --> int
		
		//Ojo: "var" no significa tipo de dato. El compilador deduce el tipo de forma automática
		
		//Muy importante aclarar que el tipo no cambia
		var numero = 27;
		
		//No puedo hacer, numero sigue siendo del tipo int --> numerico
		//numero = "Hola mundo";
		
		
	}

}
