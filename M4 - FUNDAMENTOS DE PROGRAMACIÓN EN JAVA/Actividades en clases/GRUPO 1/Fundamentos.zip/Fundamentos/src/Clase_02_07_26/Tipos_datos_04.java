package Clase_02_07_26;

public class Tipos_datos_04 {

	public static void main(String[] args) {
		//**************** TIPOS DE DATOS *********************
		
		/*
		En Java, los tipos de datos se dividen en dos categorías principales: 
		Primitivos (los más básicos definidos por el lenguaje) y No Primitivos o de Referencia (objetos más complejos).
		*/
		
		//**** Tipos Primitivos ****
		
		//== Enteros ==
		//byte: 8 bits, para valores entre -128 y 127
		//Usado para valores pequeños
		byte edad = 25;
		
		//short: 16 bits, para valores entre -32.768 y 32.767
		short valor = 2500;
		
		//int: 32 bits, para valores -2.147.483.648 y 2.147.483.647. Es uno de los más utilizados
		int sueldo = 2500000;
		
		//long: 64 bits, para valores enteros extremadamente grandes -9.223.372.036.854.775.808 a 9.223.372.036.854.775.807
		//Se añade una 'L' al final del número, la L debe ser en mayúsculas por temas de legilibilidad  
		long poblacion = 8000000000L;
		
		
		//Que ocurre si defino un valor pequeño como int, por ejemplo un 2
		//No daria error, Java almacena el valor de forma correcta, aunque ese número 
		// podría caber perfectamente en un byte.
		
		
		//Visualmente
		int numero = 2;
		//32 bits reservados para almacenar esa variable numérica
		//00000000 00000000 00000000 00000010
		
		byte numeroDos = 2;
		//8 bits reservados
		//00000010
		
		//== Decimales (coma flotante) ==
		
		//float: 32 bits, precisión simple (añadir 'f' al final). Rango de valores Aprox. 1.4 × 10⁻⁴⁵ a 3.4 × 10³⁸ (precisión simple)
		float temperatura = 36.2f;
		
		//double: 64 bits, doble precisión. Es el estándar por defecto para decimales. Rango de valores Aprox. 4.9 × 10⁻³²⁴ a 1.8 × 10³⁰⁸ (doble precisión)
		double pi = 3.141592653589793;
		
		//== Carácter ==
		// char: 16 bits, almacena un solo carácter o símbolo Unicode (se delimita con comillas simples: 'a').
		char inicial = 'R';
		
		//== Boolean ==
		//boolean: 1 bit Solo acepta dos valores: true o false
		boolean activo = false; 
				
		
		//================== RESUMEN =========================
		/*
		| Tipo      |       Tamaño      | Rango de valores                                       | Valor por defecto* | Ejemplo                          |
		| --------- | :---------------: | ------------------------------------------------------ | ------------------ | -------------------------------- |
		| byte      |       8 bits      | -128 a 127                                             | 0                  | byte edad = 25;                |
		| short     |      16 bits      | -32.768 a 32.767                                       | 0                  | short año = 2025;              |
		| int       |      32 bits      | -2.147.483.648 a 2.147.483.647                         | 0                  | int sueldo = 850000;           |
		| long      |      64 bits      | -9.223.372.036.854.775.808 a 9.223.372.036.854.775.807 | 0L                 | long poblacion = 8000000000L;  |
		| float     |      32 bits      | ±1.4E-45 a ±3.4028235E38 (≈ 6-7 cifras)                | 0.0f               | float temperatura = 18.5f;     |
		| double    |      64 bits      | ±4.9E-324 a ±1.7976931348623157E308 (≈ 15-16 cifras)   | 0.0d               | double pi = 3.141592653589793; |
		| char      |      16 bits      | 0 a 65.535 (Unicode)                                   | '\u0000'           | char inicial = 'R';            |
		| boolean   | JVM dependiente** | true o false                                           | false              | boolean activo = true;         |


		- El valor por defecto aplica únicamente a atributos (variables de instancia o de clase), no a variables locales.
		** Aunque conceptualmente representa un solo valor lógico, la especificación de Java no define un tamaño fijo en memoria para boolean.


		| Tipo    | ¿Qué almacena?              |
		| ------- | --------------------------- |
		| byte    | Enteros pequeños            |
		| short   | Enteros medianos            |
		| int     | Enteros                     |
		| long    | Enteros muy grandes         |
		| float   | Decimales (menor precisión) |
		| double  | Decimales (mayor precisión) |
		| char    | Un único carácter Unicode   |
		| boolean | Valores lógicos             |

		*/
		
		
		//**** Tipos No Primitivos (Objeto/Referencia) ****
		/*
		A diferencia de los primitivos, estos no almacenan el valor directamente 
		en la variable, 
		sino que guardan una referencia (dirección de memoria) hacia el objeto. 
		También poseen métodos y atributos propios.
		*/
		
		//String: Cadenas de caracteres delimitadas por comillas
		String mensaje = "Hola mundo 🌎";
		
		//Para almacenar números 
		Integer numeroTres = 54;
		
		//Arreglos (Arrays): Colección de datos del mismo tipo
		int [] numeros = {1, 5, 10, 20};
		
		//Scanner teclado = new Scanner(System.in); --> Leer información desde el teclado
		//Persona alumno = new Persona();
		
		//============== Ejemplos de tipos de referencia =========
		/*
		| Tipo                          | Descripción                     | Ejemplo                  |
		| ----------------------------- | ------------------------------- | ------------------------ |
		| String                        | Cadena de texto                 | "Hola Mundo"             |
		| Scanner                       | Lectura de datos por teclado    | new Scanner(System.in)   |
		| Array                         | Arreglo de datos                | int[] notas              |
		| ArrayList                     | Lista dinámica                  | new ArrayList<>()        |
		| LocalDate                     | Fecha                           | LocalDate.now()          |
		| LocalDateTime                 | Fecha y hora                    | LocalDateTime.now()      |
		| Random                        | Generador de números aleatorios | new Random()             |
		| Math                          | Operaciones matemáticas         | Math.sqrt(25)            |
		| Clases creadas por el usuario | Objetos personalizados          | new Persona()            |

		*/
		
	}

}
