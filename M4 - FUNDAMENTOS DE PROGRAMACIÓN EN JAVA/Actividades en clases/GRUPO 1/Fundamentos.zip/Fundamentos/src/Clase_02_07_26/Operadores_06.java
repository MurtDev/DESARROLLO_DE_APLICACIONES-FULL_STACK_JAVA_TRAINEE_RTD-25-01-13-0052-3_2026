package Clase_02_07_26;

public class Operadores_06 {

	public static void main(String[] args) {
		//******************** OPERADORES ****************
		//*** Aritméticos ***
		int numUno = 20;
		int numDos = 6;
		
		System.out.println(numUno + numDos);
		System.out.println(numUno - numDos);
		System.out.println(numUno * numDos);
		System.out.println(numUno / numDos);
		System.out.println(numUno % numDos);
		
		//*** Relacionales ***
		//Mayor que (>)
		int edad = 17;
		System.out.println(edad > 18);//True o False		
		
		//Menor que (<)
		int nota = 35;
		System.out.println(nota < 60);//True o False
		
		//Igual que (==)
		int numero = 10;
		System.out.println(numero == 100);//True o False
		
		//Mayor o igual que (>=)
		int edadDos = 18;
		System.out.println(edadDos >= 18);//True o False		
		
		//Menor o igual que (<=)
		int numeroDos = 10;
		System.out.println(numero <= 100);//True o False
		
		//IMPORTANTE: == (doble =) compara, mientras que = (solo un =) asigna un valor
		
		//Distinto de (!=)
		int edadTres = 25;
		System.out.println(edadTres != 18);
		
		//*** Operadores lógicos ***
		//Se utilizan para combinar condiciones.

		//Operador AND (&&)
		//Todas las condiciones deben cumplirse.

		/*
		Tabla de verdad

		| A     | B     | A && B |
		| ----- | ----- | ------ |
		| true  | true  | true   |
		| true  | false | false  |
		| false | true  | false  |
		| false | false | false  |

		*/
		
		boolean tieneEntrada = true;
		int edadEstudiante = 18;
		
		//                           true       &&  true  --> true
		//                           false      &&  true  --> false
		System.out.println("Prueba");
		System.out.println(tieneEntrada == true && edadEstudiante >= 18);
		System.out.println(tieneEntrada && edadEstudiante >= 18);//No es necesario el == true
		
		
		boolean tieneEntrada2 = false;
		int edadEstudiante2 = 25;
		
		//                           true       &&  true  --> true
		//                           false      &&  true  --> false
		System.out.println(tieneEntrada2 == true && edadEstudiante >= 18);
		System.out.println(tieneEntrada2 && edadEstudiante >= 18);//No es necesario el == true

		//Operador OR (||)
		//Basta con que una condición sea verdadera
		
		/*
		Tabla de verdad

		| A     | B     | A || B |
		| ----- | ----- | ------ |
		| true  | true  | true   |
		| true  | false | true   |
		| false | true  | true   |
		| false | false | false  |

		*/
		
		boolean estudiante = false;
		boolean profesor = true;
		
		System.out.println(estudiante || profesor);
		
		
		boolean estudiante2 = false;
		boolean profesor2 = false;
		
		System.out.println(estudiante2 || profesor2);
		
		//Operador NOT (!)
		//Invertir el valor lógico
		
		boolean HaceFrio = true;
		System.out.println(!HaceFrio);
		
		
		//Operadores de asignación
		//Permiten asignar o midificar el valor de una variable
		
		//Asignación (=)
		int num =10;
		
		//Suma e incremento (+=)
		int num2 = 10;
		num2 += 5;//num2 = num2 + 5
		
		//Resta y asigna (-=)
		int num3 = 10;
		num3 -= 5;//num3 = num3 - 5
		
		//Multiplica y asigna (*=)
		int num4 = 10;
		num4 *= 5;//num4 = num4 * 5
		
		//Divide y asigna (/=)
		int num5 = 10;
		num5 /= 5;//num5 = num5 / 5
		
		//Módulo y asigna
		int num6 = 10;
		num6 %= 5;//num6 = num6 % 5
		
		
		//Incremento y Decremento
		int contador = 1;
		contador++; //--> 2 --> contador = contador + 1
		
		int contador2 = 10;
		contador--; //--> 9
		
		
	}

}
