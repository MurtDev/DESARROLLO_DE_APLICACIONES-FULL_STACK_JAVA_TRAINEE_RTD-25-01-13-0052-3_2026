package Clase_02_07_26;

public class Constantes_03 {

	public static void main(String[] args) {
		//******************* CONSTANTES *********************
		/*
		En Java, una constante es un valor inmutable que no puede modificarse durante la ejecución del programa. 
		Se declaran utilizando la palabra reservada final. Por convención, sus nombres se escriben completamente 
		en mayúsculas, separando las palabras con guiones bajos (ej. VALOR_MAXIMO).
		*/

		final int MAX_INTENTOS = 3;
		final String URL_SERVIDOR = "http://ejemplo.com";
		final double PI = 3.14159;
		
	}

}
