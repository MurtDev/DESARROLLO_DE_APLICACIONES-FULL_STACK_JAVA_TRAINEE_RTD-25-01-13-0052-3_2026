package Clase_10_07_26;

public class Arreglos_12 {

	public static void main(String[] args) {
		//**************** Arreglos ****************
		/*
		¿Qué es un arreglo?
		
		Un arreglo, también conocido como array , es una estructura de datos que puede
		almacenar una colección de elementos del mismo tipo . En Java, los arrays tienen un
		tamaño fijo que se define en el momento de su creación. Cada elemento del array se puede
		acceder mediante un índice numérico que representa su posición en el array.

		Para declarar un array en Java, debes especificar su tipo y su tamaño:

		int[] numeros = new int[4];

		Los corchetes indican que esta variable es del tipo arreglo y el prefijo int informa que
		almacenará números enteros. Además, especificamos su tamaño en 4 espacios.
		*/
		
		              // { , , , }
		int[] numeros = new int[4];
		//POSICION 0 1 2 3
		//        {20 , , ,10}
		numeros[3] = 10;//Asignación de valor a almacecnar en la posición 3
		numeros[0] = 20;
		numeros[1] = 30;
		numeros[2] = 40;
		
		for (int numero : numeros) {			
			System.out.println(numero);
		}
		
		
		//Declarar e inicializar un array
		int[] numeros2 = {20, 30, 40, 10};
		
		//
		int nota1 = 60;
		int nota2 = 55;
		int nota3 = 70;
		int nota4 = 45;
		
		int[] notasAlumnos = {60, 55, 70, 45};
		
		//Obtener cantidad de elementos o largo del array
		System.out.printf("Largo del array: %d %n", notasAlumnos.length);
		
		//Acceder a las posiciones y mostrar por consola
		/*
		 indices de izquera a derecha: 0,n
		 indices de derecha a izquerda: n-1
		 */
		System.out.println(notasAlumnos[0]);
		
		
		//La última posición siempre será
		System.out.println(notasAlumnos[notasAlumnos.length-1]);
		
		//La penultima posición siempre será
		System.out.println(notasAlumnos[notasAlumnos.length-2]);
		
		//Recorrer con for
		for (int i = 0; i <= notasAlumnos.length-1; i++) {
			
			System.out.println(notasAlumnos[i]);
		}
		
		//Recorrer con for each
		for (int nota : notasAlumnos) {
			System.out.println(nota);
		}
		
		
		//********** Arreglos Bidimensionales **************
		/*
		Matrices:
		Los arreglos bidimensionales o matrices tienen el mismo tratamiento que los arrays. La
		diferencia de sintaxis se centra en la creación:

		Declaración y creación de una Matriz

		int[][] arregloM = new int [Filas][Columnas] ;

		De esta manera podemos crear dos dimensiones diferentes para el mismo arreglo, es por esto
		que lleva dos corchetes.
		*/

		/*
		Esto crea una matriz con:

		2 filas.
		3 columnas.
		*/
		                       //F  C
		int[][] matriz = new int[2][3];
		
		matriz[0][0]  = 10;
		matriz[0][1]  = 20;
		matriz[0][2]  = 30;
		
		matriz[1][0]  = 40;
		matriz[1][1]  = 50;
		matriz[1][2]  = 60;
		
		/*
		 [10][20][30]
		 [40][50][60]
		 
		 */
		System.out.println("-------------- MATRIZ -----------");
		System.out.println(matriz[0][1]);
		
		//Declaración e inicialización
		int[][] matriz2 = {
				{10, 20, 30}, //fila 0
				{40, 50, 60}  //fila 1
		};
		
		//Recorrer matriz
		//matriz2.length-1 obtenemos la última posición de la fila
		//matriz2[fila].length-1 obtenemos la última posición de la columna
		System.out.println("-------------- MATRIZ 2 -----------");
		for (int fila = 0; fila <= matriz2.length-1; fila++) {
			System.out.println("Iteración fila: " + fila);
			
			for (int columna = 0; columna <= matriz2[fila].length-1; columna++) {
				System.out.println("Iteración columna: " + columna);
				System.out.printf("[%d][%d] %n",fila, columna);
			}
		}
		
		
		
	}

}
