package Clase_10_07_26;

import java.util.Scanner;

public class Estructuras_repetitivas_11 {

	public static void main(String[] args) {
		//************** Estructuras Repetitivas ****************
		//¿Qué es una estructura repetitiva?
		System.out.println("1");
		System.out.println("2");
		System.out.println("3");
		System.out.println("4");
		System.out.println("5");
		System.out.println("20");
		System.out.println("30");
		System.out.println("40");
		System.out.println("50");
		System.out.println("60");
		System.out.println("70");
		System.out.println("100");
		
		//**** 1.  while **** 
		/*Definición

		El ciclo while ejecuta un bloque de código mientras una 
		condición sea verdadera.
		
		Primero verifica la condición y luego ejecuta el bloque.
		Si la condición es falsa desde el inicio, nunca entra al ciclo.
		*/
		
		//Sintaxis
		/*
		while (condición) {

		    instrucciones;

		}
		*/
		
		//Ejemplo
		int contador = 1;
		
		while (contador <= 100) {
			System.out.println(contador);
			contador++;//incremento en 1
			//Error común es olvidar incrementar la variable que define el termico de bucle
		}
		/*
		boolean control = true;
		
		while(control){
			int opcion = teclado.nextInt();
			if(opcion==1){
				control = false;
			}
		}*/
		
		int fila = 1;

		while (fila <= 3) {

		if (fila == 1) {
		System.out.println(" /\\_/\\\\");
		} else if (fila == 2) {
		System.out.println("( o.o )");
		} else {
		System.out.println(" > ^ <");
		}

		fila++;
		}
		
		//**** 2. do while **** 
		//El ciclo do-while ejecuta el bloque al menos una vez, 
		//porque la condición se evalúa al final.
		
		/* Sintaxis
		do {

		    instrucciones;

		} while (condición);
		*/
		
		//ejemplo
		System.out.println("------------------------------");
		int contador2 = 6;
		
		do {
			System.out.println(contador2);//6
			contador2++;//7
		} while (contador2 <= 5);//false
		
		
		//Otro ejemplo
		/*Scanner teclado = new Scanner(System.in);
		String usuario, clave;
		do{
			System.out.println("usuario: ");
			usuario = teclado.nextLine();
			System.out.println("clave: ");
			clave= teclado.nextLine();
			System.out.println("credenciales incorrectas");

		}while(!usuario.equalsIgnoreCase("admin") && !clave.equalsIgnoreCase("1234"));
		
		System.out.println("acceso permitido");*/
		
		/*

		¿Cuándo usar do-while?

		Cuando una acción debe ejecutarse al menos una vez.

		Ejemplos:

		Menús.
		Validación de datos.
		Juegos.
		*/
		
		//***** for *****
		/*Definición

		El ciclo for se utiliza cuando sabemos cuántas veces queremos repetir una acción.*/
		
		//Sintaxis
		/*
		for (inicio; condición; incremento) {

		    instrucciones;

		}*/
		
		//ejemplo
		for (int indice = 5; indice <= 10; indice++) {
			System.out.println(indice);
		}
		
		//**** for -each
		//Sintaxis
		/*
		for (Tipo variable : colección) {

		}
		*/
		                         //Posiciones
		//ejemplo          // 0       1        2
		String[] nombres = {"Ana", "Pedro", "Juan"}; //--> largo o el .length = 3
		
		for (String nombre : nombres) {			
			System.out.println(nombre);
		}
		
		System.out.println("-------------");
		System.out.println(nombres.length);
		
		//Comparación con el for tradicional
		int cantIndice = nombres.length-1;//--> 2
								
		
		//ejemplo          // 0       1        2
	    //String[] nombres = {"Ana", "Pedro", "Juan"}; 
		
		//nombres[1]  ---> "Pedro"
		
		for (int indice = 0; indice <= cantIndice; indice++) {
			System.out.println(nombres[indice]);
		}
		
		
		//*********** break *************
		for (int indice = 1; indice <= 10; indice++) {
			
			if (indice == 6) {
				System.out.println("Entre en el if");
				break;
			}
			
			System.out.println(indice);
		}
		
		

		//*********** continue *************
		for (int indice = 1; indice <= 10; indice++) {
			System.out.println("Inicio");
			if (indice == 6) {
				System.out.println("Entre en el if");
				continue;
			}
			
			System.out.println(indice);
			System.out.println("FIN");
		}
		
		//¿Cuándo utilizar cada ciclo?

		/* 

		| Estructura | ¿Cuándo utilizarla?                                     | Ejemplo                                        |
		| ---------- | ------------------------------------------------------- | ---------------------------------------------- |
		| `while`    | No sabes cuántas veces se repetirá.                     | Validar una contraseña hasta que sea correcta. |
		| `do-while` | Debe ejecutarse al menos una vez.                       | Menús interactivos.                            |
		| `for`      | Sabes cuántas repeticiones habrá.                       | Imprimir los números del 1 al 100.             |
		| `for-each` | Recorrer todos los elementos de un arreglo o colección. | Mostrar una lista de nombres.                  |

		*/
		
		
	}

}
