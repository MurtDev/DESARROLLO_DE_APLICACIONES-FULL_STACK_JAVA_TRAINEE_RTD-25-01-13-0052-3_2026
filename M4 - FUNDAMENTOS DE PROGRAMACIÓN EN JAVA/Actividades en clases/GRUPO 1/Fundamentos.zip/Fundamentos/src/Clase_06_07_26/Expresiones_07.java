package Clase_06_07_26;

public class Expresiones_07 {

	public static void main(String[] args) {
		// ***************** Expresiones ******************
		/*
		 * ¿Qué es una expresión?
		 * 
		 * Una expresión es una combinación de valores, variables, operadores y/o
		 * llamadas a métodos que, al ser evaluada por Java, produce un único resultado.
		 * 
		 * En otras palabras: Una expresión es todo aquello que Java puede evaluar para
		 * obtener un valor.
		 * 
		 * Ese valor puede ser:
		 * 
		 * Un número (15) Un decimal (3.5) Un texto ("Hola Juan") Un carácter ('A') Un
		 * valor lógico (true o false)
		 */

		// ejemplo sencillo
		int resultado = 5 + 3;

		// Otro ejemplo con dos variables
		int nota1 = 60;
		int nota2 = 70;

		int promedio = (nota1 + nota2) / 2; // Expresión

		// **** Tipos de expresiones ****

		// 1. Expresiones aritméticas
		// Realizan operaciones
		int total = 10 + 5 * 2;

		// 2. Expresiones relacionales
		// siempre devuelve true o false --> Boolean

		int edad = 20;

		boolean mayor = edad >= 18;// Expresion --> edad >= 18

		// 3. Expresiones lógicas (combinan varias condiciones)
		int edad2 = 20;
		boolean tieneEntrada = true;

		boolean ingresar = edad >= 18 && tieneEntrada;// Expresión --> edad >= 18 && tieneEntrada

		// 4. Expresiones de asignación
		int resultado2 = 5 + 3; // Expresion --> 5 + 3

		// 5. Expresiones de concatenación (Une textos)
		String nombre = "Luis";
		String saludo = "Hola " + nombre;

		// Existe la interpolación en Java??

		/*
		 * let nombre = "Juan" console.log("Hola ${nombre}");
		 */

		String nombre2 = "Juan";
		int edad3 = 30;

		System.out.printf("Hola %s, tienes %d años. %n", nombre2, edad3);
		// Salto de línea %n

		/*
		 * %s → String %d → entero (int) %f → decimal (float o double), podedmos indicar
		 * la cantidad de decimales %.2f %c → carácter %b → booleano
		 */

		String nombre3 = "Juan";
		double estatura = 1.76;

		System.out.printf("Hola %s, tu estatura es %.2f %n", nombre3, estatura);

		// ======================== Otro ejemplo =================
		/*
		 * "|%cantidad de espacios a la izquerda s|%n
		 * 
		 * ejemplo: "|%10s|%n
		 * 
		 * cantidad de especios a la derecha : "|%-cantidad de espacios s|%n"
		 * 
		 * ejemplo: "|%-10s|%n"
		 * 
		 * %-10s : 10 espacios a la derecha. %10s: espacios a la izquerda.
		 */

		// Encabezado de la tabla
		System.out.printf("%-15s %-30s %-10s %-10s%n", "Producto", "Marca", "Precio", "Stock");

		System.out.println("-----------------------------------------------");

		// Datos de productos
		System.out.printf("%-15s %-10s %-10s %-10s%n", "Notebook", "Lenovo", "$650000", "12");

		System.out.printf("%-15s %-10s %-10s %-10s%n", "Mouse", "Logitech", "$12000", "35");

		System.out.printf("%-15s %-10s %-10s %-10s%n", "Teclado", "HP", "$25000", "20");

		System.out.printf("%-15s %-10s %-10s %-10s%n", "Monitor", "Samsung", "$180000", "8");

		// Usando String.format()
		// Muy útil cuando queremos contruir una cadena sin imprimirla inmediatamente
		String nombre4 = "José";
		String apellido = "Saavedra";
		int edad4 = 37;

		String mensaje = String.format("Hola %s %s, tienes %d años %n", nombre4, apellido, edad4);

		System.out.println(mensaje);

//Usando formatted

		String nombre5 = "Juan";
		String apellido5 = "Saavedra";
		int edad5 = 34;

		String mensaje2 = "Hola %s %s, tienes %d años %n".formatted(nombre5, apellido5, edad5);

		System.out.println(mensaje2);

         //**** 6. Expresión condicional (operarador ternario)
        //Devuelve un valor depediendo de la condición

		int edad6 = 18;
		                 // if --> true else --> false
		                // Condición ? Resultado si verdadero : Resultado si no verdadero (falso)
		String mensaje3 = edad6 >= 18 ? "Mayor de edad" : "Menor de edad";
		System.out.println(mensaje3);
		
		
		//**** 7 . Expresión con métodos
		//Una llamada a una función también puede formar parte de una expresión
		double raiz = Math.sqrt(25);
		System.out.println(raiz);
		

	}

}
