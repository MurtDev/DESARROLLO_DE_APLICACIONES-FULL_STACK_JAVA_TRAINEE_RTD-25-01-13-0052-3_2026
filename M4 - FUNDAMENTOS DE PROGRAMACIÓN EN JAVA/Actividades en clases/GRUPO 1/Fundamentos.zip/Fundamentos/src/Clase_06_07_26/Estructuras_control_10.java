package Clase_06_07_26;
import java.util.Locale;
import java.util.Scanner;


public class Estructuras_control_10 {

	public static void main(String[] args) {
		//********************** Estructuras de control ********************
		/*
		¿Qué es una estructura de control?

		Concepto de toma de decisiones.

		Ejemplo cotidiano:

		Si llueve, llevo paraguas.
		Si tengo dinero, compro.
		Si apruebo, paso de curso.

		¿Está lloviendo?

		SI
		 ↓
		Llevar paraguas

		NO
		 ↓
		No llevar paraguas
		*/
		
		//**** if (Condicional simple)
		//Sintaxis
		/*
		if(condición) {
			bloque de código
		}
		*/
		
		//ejemplo
		int edad = 27;
		
		if(edad >= 18) {
			System.out.println("Es mayor de edad");
		}
		
		//Pedir la edad del usuario
		/*
		Scanner teclado = new Scanner(System.in);
		System.out.print("Ingrese su edad: ");
		int edadUsuario = teclado.nextInt();
		
		if(edadUsuario >= 18) {
			System.out.println("Puede ingresar");
		}
		
		teclado.close();*/
		
		
		//if - else
		//Permite ejecutar un bloque cuando la condición es verdadera y otro cuando es falsa
		//Sintaxis
		/*
		if(condición) {
			bloque de código
		}
		
		else {
			otro bloque
		}
		*/
		
		//ejemplo 
		int nota = 65;
		
		if(nota >=60) {
			System.out.println("Aprabado");
		}
		else {
			System.out.println("Reprobado");
		}
		
		
		//ejemplo 2
		int saldo = 5000;
		int compra = 15000;
		
		if(saldo >= compra) {
			System.out.println("Compra realizada");
		}
		else {
			System.out.println("Saldo insuficiente");
		}
		
		//if anidado
		//Un if dentro de otro
		//Se utiliza cuando una decisión depende de otra
		
		boolean tieneEntrada = true;
		int edad2 = 20;
		String mensaje;
		
		if(tieneEntrada) {
			if (edad2 >= 18) {
				mensaje = "Puede entrar";
			}
			else {
				mensaje = "No puede entrar";
			}
		}
		else {
			mensaje = "No puede entrar";
		}
		
		System.out.println(mensaje);
		
		//if - else if - else
		//Se utiliza cuando existen varias condiciones posibles
		//Sintaxis
		/*
		if(condición) {
			bloque de código
		}
		
		else if(condición) {
			    bloque de código
		}
		
		else if(condición) {
			    bloque de código
		}
		
		else if(condición) {
			    bloque de código
		}
		
		else {
			otro bloque
		}
		*/
		
		//ejemplo: clasificar una nota
		double promedio = 5.3;
		
		
		if (promedio >= 6.0) {
			System.out.println("Excelente");
		}
		
		else if (promedio >= 5.0) {
			System.out.println("Buena");
		}
		
		else if (promedio >= 4.0) {
			System.out.println("Suficiente");
		}
		
		else {
			System.out.println("Reprobado");
		}
		
		
		//¿Qué pasa si tenemos muchas opciones?
		/*
		1 Registar
		2 Buscar
		3 Modificar
		4 eliminar
		5 Salir
		*/
		
		//Switch
		//Sintaxis
		/*switch(variable){
		 case valor:
		          break;
		          
		 case valor:
		          break;
		 
		 default: Bloque de código
		 
		 }*/
		
		
		//ejemplo
		/*
		1 Registar
		2 Buscar
		3 Modificar
		4 eliminar
		5 Salir*/
		System.out.println("1 Registar\n2 Buscar\n3 Modificar\n4 eliminar\n5 Salir");
		
		int opcion = 4;
		
		switch (opcion) {
			case 1: System.out.println("Registar"); 
					break;
			case 2: System.out.println("Buscar"); 
					break;
			case 3: System.out.println("Modificar"); 
					break;
			case 4: System.out.println("eliminar"); 
					break;
			case 5: System.out.println("Salir"); 
					break;
			default: System.out.println("Opción no válida"); 
		}
		
		//Otra forma (desde la versión Java 14)
		String dia = "LUNES";
		
		switch (dia) {
			case "LUNES" -> System.out.println("Inicio la semana"); 
			
			case "VIERNES" -> System.out.println("Ya casi es fin de");
			
			default -> System.out.println("Otro día"); 
		
		}
		
	}

}
