package Clase_06_07_26;
import java.util.Locale;
import java.util.Scanner;


public class Entrada_teclado_09 {

	public static void main(String[] args) {
		//******************** Entrada por teclado ********************
		/*
		¿Qué es la entrada por teclado?

		La entrada por teclado es el proceso mediante el cual un programa 
		solicita información al usuario mientras se está ejecutando.

		Por ejemplo:

		Ingresar un nombre.
		Ingresar la edad.
		Escribir una nota.
		Ingresar el precio de un producto.

		En Java, la forma más común de leer datos desde el teclado es 
		utilizando la clase Scanner.
		*/

		/*
		¿Qué es Scanner?

		Scanner es una clase de la biblioteca estándar de Java que permite 
		leer información desde diferentes fuentes, como:

		El teclado.
		Un archivo.
		Un texto.
		Un flujo de datos.
		*/
		
		//Antes de utilizar la clase debemos importarla
		//import java.util.Scanner; se importo en línea 2
		Scanner teclado = new Scanner(System.in);//System.in --> Entrada estándar (teclado)
		
		//ejemplo
		//System.out.println("Ingrese su nombre: ");
		//String nombre = teclado.nextLine();
		//System.out.printf("Hola %s %n", nombre);
		
		
		//Métodos más utilizados de Scanner

		/*
		| Método          | Tipo de dato leído | Ejemplo    |
		| --------------- | ------------------ | ---------- |
		| next()          | Una palabra        | Juan       |
		| nextLine()      | Una línea completa | Juan Pérez |
		| nextInt()       | Entero             | 25         |
		| nextDouble()    | Decimal            | 15.8       |
		| nextFloat()     | Decimal float      | 5.5f       |
		| nextLong()      | Entero largo       | 1000000000 |
		| nextBoolean()   | Boolean            | true       |
		| nextByte()      | Byte               | 100        |
		| nextShort()     | Short              | 300        |

		*/
		
		//next()
		//Lee una sola palabra
		//System.out.println("Ingrese su nombre: ");
		//String nombre2 = teclado.next();
		//System.out.printf("Hola %s %n", nombre2);
		
		
		//nextLine()
		//Lee toda la línea
		//System.out.println("Ingrese su nombre: ");
		//String nombre = teclado.nextLine();
		//System.out.printf("Hola %s %n", nombre);
		
		
		//nextInt()
		//Lee un número entero
		//System.out.println("Ingrese un número: ");
		//int numero = teclado.nextInt();
		//System.out.println(numero);
		
		//nextDouble()
		//Lee un decimal
		//System.out.println("Ingrese estatura en metros: ");
		//Configuración de la región
		//teclado.useLocale(Locale.US);//lo dejamos con US para usar . como separador de decimales
		//double estatura = teclado.nextDouble();
		//System.out.println(estatura);
		

		//teclado.useLocale(Locale.CL);
		
		
		//nextBoolean()
		//Lee un valor true o false
		//System.out.println("¿Es estudainte?: ");
		//boolean esEstudiante = teclado.nextBoolean();
		//System.out.println(esEstudiante);
		
		
		// Lectura del nombre
		System.out.print("Ingresa tu nombre completo: ");
		String nombre = teclado.nextLine();

		// Otros datos
		String direccion = "Av. Siempre Viva 123";
		String telefono = "+56 9 1234 5678";
		String correo = "mauricio@gmail.com";

		// Crear el texto
		String carta = String.format("DATOS DEL USUARIO%n" + "------------------------%n" + "Nombre : %s%n"
		+ "Dirección : %s%n" + "Teléfono : %s%n" + "Correo : %s", nombre, direccion, telefono, correo);

		System.out.println();
		System.out.println(carta);
		
		
		//terminamos de usar teclado
		teclado.close();
		
	}

}
