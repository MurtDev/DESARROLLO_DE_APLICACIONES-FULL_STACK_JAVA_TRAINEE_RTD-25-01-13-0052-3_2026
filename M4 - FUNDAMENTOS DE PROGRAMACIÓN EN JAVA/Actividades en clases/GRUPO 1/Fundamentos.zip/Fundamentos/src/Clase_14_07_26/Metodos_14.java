package Clase_14_07_26;

public class Metodos_14 {
	
	//*********** Método sin parametros y sin retorno ************
	public static void saludar() {
		System.out.println("Hola Mundo 🌍");
	}
	
	//*********** Método con parametros y sin retorno *******
	public static void saludarConNombre(String nombreUsuario) {
		System.out.println("Hola " + nombreUsuario);
	}
	
	
	public static void mostrarPersona(String nombrePersona, int edadPersona) {
		System.out.printf(
				"Nombre Persona: %s %nEdad Persona: %d %n", 
				nombrePersona, 
				edadPersona
				);	
	}
	
	//***************** Método con retorno ************
	public static int sumar(int num1, int num2) {
		int resultadoSuma = num1 + num2; 
		return resultadoSuma; 
	}
	
	//Otro ejemplo                                                  
	public static double calcularValorConImpuesto(int valorNeto, double impuesto) {
		double montoImpuesto = valorNeto * (impuesto/100);
		double montoTotal = valorNeto + montoImpuesto;
		
		return montoTotal;
	}
	
	//*********************** Sobrecarga de métodos **********
	//método v1
	public static int multiplicar(int num1, int num2) {
		System.out.println("Método v1");
		int resultado = num1 * num2; 
		return resultado; 
	}
	
	//método v2
	public static double multiplicar( double num1, double num2) {
		System.out.println("Método v2");
		double resultado = num1 * num2; 
		return resultado; 
	}
	
	//método v3
	public static int multiplicar( int num1, int num2, int num3) {
		System.out.println("Método v3");
		int resultado = num1 * num2 * num3; 
		return resultado; 
	}
	
	
	
	
	public static void main(String[] args) {
		// ************ Métodos *************** (Funciones)

		/*
		 * ¿Qué es un método?
		 * 
		 * Un conjunto de instrucciones que realizan una tarea específica y que pueden
		 * reutilizarse cada vez que sea necesario.
		 * 
		 * "un método en Java es lo mismo que una función en otros lenguajes"
		 */

		/*
		 * Sintaxis de un método modificador tipoRetorno nombreMetodo(){
		 * 
		 * }
		 */
		saludar();
		saludar();
		saludar();
		saludar();
		saludar();
		
		/*
		| Elemento | Descripción               |
		| -------- | ------------------------- |
		| public   | Modificador de acceso.    |
		| static   | Pertenece a la clase.     |
		| void     | No devuelve ningún valor. |
		| saludar  | Nombre del método.        |
		| ()       | Parámetros.               |
		| {}       | Bloque de instrucciones.  |

		*/
		
		
		saludarConNombre("Juan");
		saludarConNombre("Ana");
		
		String n = "José";
		saludarConNombre(n);
		
		mostrarPersona("Roberto", 39);
		mostrarPersona("Luis", 47);
		
		//public static String valueOf(boolean b)
		//Parámetros vs Argumentos
		/*
		 Parametro : Variable definida en le método
		 
		 Argumento : valor enviado al método
		 
		 public static void metodo(tipo_dato parametro){

			// codigo
		}
		
		metodo(argumento);
		 
		 */
		
		int result = sumar(10, 20);
		System.out.println(result);
		
		System.out.println(calcularValorConImpuesto(1000, 19));
		
		//Scope o ámbito de la variable resultadoSuma sólo es el 
		//método donde fue dedfinida
		// en otras palabras sólo existe dentro de ese métedo
		//System.out.println(resultadoSuma);
		
		//Ejemplos sobrecarga
		System.out.println(multiplicar(5, 3));
		System.out.println(multiplicar(5.8, 3.7));
		System.out.println(multiplicar(5, 3, 10));
		
		
	}

}