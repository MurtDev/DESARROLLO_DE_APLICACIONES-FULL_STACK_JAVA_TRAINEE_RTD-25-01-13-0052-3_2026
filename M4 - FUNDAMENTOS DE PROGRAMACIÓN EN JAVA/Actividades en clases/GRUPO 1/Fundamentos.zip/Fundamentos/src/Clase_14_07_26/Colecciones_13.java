package Clase_14_07_26;

import java.util.ArrayList;

public class Colecciones_13 {

	public static void main(String[] args) {
		//**************** Colecciones ***************
		/*
		¿Qué son las colecciones?:
		
		Una colección representa un grupo de objetos,
		conocidos como elementos. 

		Podemos crear una colección con cualquier tipo de objeto, 
		incluso los creados por nosotros. La única restricción es que no podremos crear
		una colección sólo de tipo primitivo , para eso
		usaremos los tipos de objetos equivalentes a los
		primitivos.

		Por ejemplo: en vez de int, hay que utilizar
		Integer.
		*/

		/*Una colección es una estructura que permite almacenar y 
		 administrar grupos de objetos.

		Java incluye diferentes tipos de colecciones:*/

		/*

		Collection
		├── List
		│   ├── ArrayList
		│   └── LinkedList
		│
		├── Set
		│   └── HashSet
		│
		└── Map
		    └── HashMap
		*/
		
		
		//**** ArrayList ****
		/*
		Un ArrayList almacena elementos en una lista ordenada.

		Características:

		Mantiene el orden de inserción.
		Permite elementos repetidos.
		Permite acceder por índice.
		Su tamaño puede cambiar.
		*/
		
		//Importación 
		//import java.util.ArrayList;
		
		//Creación
		ArrayList<String> productos = new ArrayList<>();
		
		//Agregar elemantos
		productos.add("Teclado");
		productos.add("Mouse");
		productos.add("Monitor");
		
		
		//Mostrar la lista
		System.out.println(productos);
		
		//Obtener un elemento
		String producto1 = productos.get(2);
		System.out.println(producto1);
		
		//Modificar un elemento
		String productoAIngresar = "Mouse inalámbrico";
		productos.set(1, productoAIngresar);
		System.out.println(productos);
		
		//Eliminar un elemento
		//por indice
		//productos.remove(2);
		System.out.println(productos);
		
		//Por contenido o por elemento --> "Teclado"
		//productos.remove("Teclado");
		System.out.println(productos);
		
		
		//Cantidad de elementos
		int cantidadElementos = productos.size();//obtener última posición -1 se puede
		System.out.println("Cantidad de elementos: " + cantidadElementos);
		
		
		//Verificar si contiene un elemento en particular
		String productoBuscar = "Teclado";
		boolean contieneProducto = productos.contains(productoBuscar); 
		
		if (contieneProducto) {
			System.out.printf("Se encontro \"%s\" en la lista %n", productoBuscar);
		}
		else {
			System.out.printf("No se encontro \"%s\" en la lista %n", productoBuscar);
		}
		
		
		//Otra opción 
		boolean contieneMouse = productos.contains(productoBuscar); 
		String mensaje = contieneMouse ? 
				"Se encontro en la lista %s".formatted(productoBuscar) : 
				"No se encontro en la lista %s".formatted(productoBuscar);
		
		System.out.println(mensaje);
		
		
		//vaciar la colección
		//productos.clear();
		//System.out.println(productos);
		
		//Verificar si la lista está vacía
		if (productos.isEmpty()) {
			System.out.println("La lista está vacía");
		}
		else {
			System.out.println("La lista no está vacía");
		}
		
		//Recorrer un ArrayList
		//con for
		for (int indice = 0; indice <= productos.size()-1; indice++) {
			System.out.println(productos.get(indice));
		}
		
		//con for each
		for (String producto : productos) {
			System.out.println(producto);
		}
		
		
		productos.forEach(System.out::println);
		
		
		//Las colecciones no utilizan o no trabajan directamente con tipos de 
		//datos primitivos
		
		//por ejemplo
		//ArryList<int> numeros; --> no es correcto
		
		ArrayList<Integer> numeros = new ArrayList<>();
		
		/*

		| Tipo primitivo | Clase envolvente |
		| -------------- | ---------------- |
		| `int`          | `Integer`        |
		| `double`       | `Double`         |
		| `boolean`      | `Boolean`        |
		| `char`         | `Character`      |
		| `long`         | `Long`           |
		| `float`        | `Float`          |
		*/
		
	}

}
