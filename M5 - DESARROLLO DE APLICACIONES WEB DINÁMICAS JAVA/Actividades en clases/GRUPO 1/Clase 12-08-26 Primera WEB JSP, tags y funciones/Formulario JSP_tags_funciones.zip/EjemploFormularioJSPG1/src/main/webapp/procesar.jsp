<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%-- 
----------------
    JSTL CORE 
----------------
c:set
s:out
c:if
c:choose
c:forEach

etc
--%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<%-- 
---------------------	
	JSTL Functions 
---------------------

fn:length()
fn:toUpperCase()
fn:replace()

etc

	--%>    
<%@ taglib uri="jakarta.tags.functions" prefix="fn" %>    
    
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<link
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
	rel="stylesheet"
	integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB"
	crossorigin="anonymous">

<title>Resultado del registro</title>
</head>
<body>

<!-- Barra de navegación -->
	<nav class="navbar bg-dark text-bg-dark" data-bs-theme="dark">
		<div class="container">
			<span>Aplicación Java Web</span>
		</div>
	</nav>
	<div class="container mt-5">
		<div class="row justify-content-center">
			<div class="col-md-6">
				
			<!-- Tarjeta o card -->
				<div class="card shadow">
					<div class="card-body p-5">
					
						<h2 class="text-center">Datos del estudiante</h2>
						
						<%-- 
						---------------
						    c:set  
						--------------
						permite crear una variable 
						
						En este caso creamos la variable y 
						convertimo a mayúscula en nombre del estudiante
						utilizando la función fn:toUpperCase()
						
						--%>
						<c:set var="nombreEstudianteMayuscula" value="${ fn:toUpperCase(param.nombre) }"/>
						
						<div class="mb-3">
							<strong>Nombre:</strong>
							<c:out value="${ nombreEstudianteMayuscula }" default="Nombre no informado"/>
						</div>	
						
						<div class="mb-3">
							<strong>Edad:</strong>
							<c:out value=" ${ param.edad } " default="Edad no informada"/>
						</div>
						
						<div class="mb-3">
							<strong>Curso:</strong>
							<c:out value=" ${ param.curso } "/>
						</div>
						
						<div class="mb-3">
							<strong>Correo:</strong>
							<c:out value=" ${ param.correo } "/>
						</div>	
						
						<hr>
						
						<%--
						-------------
						fn:length()
						-------------
						
						Devuelve la cantidad de elementos o caracteres del String
						
						Ejemplo:
						
						Ricardo
						
						Devuelve 7 caracteres
						
						 --%>
						<p>
							El nombre contiene
							
							<strong>
							  <c:out value="${ fn:length(param.nombre) }"/>
							</strong>
							
							caracteres.
						</p>
						
						<%-- 
						------------- 
						fn:contains()
						------------
						
						Verifica si una cadena contiene determinado texto
						
						En este ejemplo verificamos que el correo contenga el @
						--%>	
					
						<c:if test="${ fn:contains(param.correo, '@') }">
							<div class="alert alert-success" role="alert">
								El correo contiene un formato básico válido
							</div>
						</c:if>
						
						<%-- 
						-------------
						    c:if
						------------
						Funciona de manera similar a:
						
						if(condicion) {
							si condición verdadera
						}
						
						Solamente ejecuta su contenido cuando la condición es verdadera
						
						--%>
						
						<c:if test="${ param.edad < 18 }">
							<div class="alert alert-danger" role="alert">
								No puede registrarse al estudiante 
								<strong>
									<c:out value="${ param.nombre }" />
								</strong>
								, ya que es menor de edad.
							</div>
						</c:if>
						
						
						<h4>Segmentación por edad</h4>
						
						<%--
						-------------------
						    c:choose
						-------------------
						
						Podemos compararlo conceptualemente con una estructura:
						if
						else if
						else if
						else
						
						o con un 
						
						switch case
						
						Donde tenemos varias opciones posibles		
				
						 --%>
						
						<c:choose>
							<c:when test="${ param.edad < 18 }">
								<div class="alert alert-warning" role="alert">
								El estudiante 
								<strong>
									<c:out value="${ param.nombre }" />
								</strong>
								es menor de edad.
							</div>
							</c:when>
							
							<c:when test="${ param.edad <= 40  }">
								<div class="alert alert-info" role="alert">
								El estudiante 
								<strong>
									<c:out value="${ param.nombre }" />
								</strong>
								es adulto joven.
							</div>
							</c:when>
							
							<%-- Si ninguna condición anterior
							se cumple, entra aquí --%>
							<c:otherwise>
								<div class="alert alert-secondary" role="alert">
								El estudiante 
								<strong>
									<c:out value="${ param.nombre }" />
								</strong>
								es adulto.
							</div>
							</c:otherwise>
						
						</c:choose>	
						
						<div class="mb-3">

							<strong>Áreas de interés:</strong>
							
							<c:if test="${empty paramValues.intereses}">
								<div class="alert alert-danger" role="alert">
									<span>No se seleccionaron intereses</span>
								</div>
							</c:if>
							
							
							<%--
		                        --------------
		                        c:forEach
		                        --------------
		
		                        Permite recorrer:
		
		                        listas
		                        arrays
		                        colecciones
		                        mapas
		
		                        En este caso:
		
		                        paramValues.intereses
		
		                        es un arreglo con todos los checkbox
		                        seleccionados por el usuario.
		
		                        Cada elemento será almacenado
		                        temporalmente en:
		
		                        interes
		                    --%>
							<ul class="list-group mb-4">
							
								<c:forEach var="interes" items="${paramValues.intereses}">
								
								<li class="list-group-item">
									<span class="badge bg-primary me-1"> 
										<c:out value="${interes}" />
									</span>
								</li>
								</c:forEach>
							</ul>
						</div>											
					</div>
				</div>
				
			</div>
		</div>
	</div>	




<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
		crossorigin="anonymous"></script>
</body>
</html>