<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<link
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
	rel="stylesheet"
	integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB"
	crossorigin="anonymous">


<title>Registro de Estudiantes</title>
</head>
<body>
	<!-- Barra de navegación -->
	<nav class="navbar bg-dark text-bg-dark" data-bs-theme="dark">
		<div class="container">
			<span>Aplicación Java Web</span>
		</div>
	</nav>
	<div class="container mt-5">
		<div class="row justify-content-center">
			<div class="col-md-6">
				
			<!-- Tarjeta o card -->
				<div class="card shadow">
					<div class="card-body p-5">
					
						<h2 class="text-center">Registro de estudiantes</h2>
						

						<!-- Formulario -->
						<form action="procesar.jsp" method="POST">
							<div class="mb-3">
								<label class="form-lable">Nombre</label> 
								<input type="text" class="form-control" name="nombre" required>
							</div>
							
							<div class="mb-3">
								<label class="form-lable">Edad</label> 
								<input type="number" class="form-control" name="edad" min="1" required>
							</div>
							
							<div class="mb-3">
								<label class="form-lable">Correo</label> 
								<input type="email" class="form-control" name="correo" required>
							</div>
							<div class="mb-3">
								<label class="form-lable">Curso</label> <select
									class="form-select" name="curso" required>
									<option value="">Selecione un curso...</option>
									<option value="Java">Java</option>
									<option value="Python">Python</option>
									<option value="Php">Php</option>
								</select>
							</div>
							
							<div class="mb-3">
								<label class="form-lable">Áreas de interés</label>
								
								<div class="form-check">
									<input 
										type="checkbox" 
										class="form-check-input" 
										name="intereses" 
										value="backend" 
										>
									<label class="form-check-label">Backend</label>
								</div>
								
								<div class="form-check">
									<input 
										type="checkbox" 
										class="form-check-input" 
										name="intereses" 
										value="frontend" 
										>
									<label class="form-check-label">Frontend</label>
								</div>
								
								<div class="form-check">
									<input 
										type="checkbox" 
										class="form-check-input" 
										name="intereses" 
										value="base de datos" 
										>
									<label class="form-check-label">Base de datos</label>
								</div>
							</div>

							<button type="submit" class="btn btn-primary w-100">Registrar</button>

						</form>
					</div>
				</div>
				
			</div>
		</div>
	</div>	



	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
		crossorigin="anonymous"></script>
</body>
</html>