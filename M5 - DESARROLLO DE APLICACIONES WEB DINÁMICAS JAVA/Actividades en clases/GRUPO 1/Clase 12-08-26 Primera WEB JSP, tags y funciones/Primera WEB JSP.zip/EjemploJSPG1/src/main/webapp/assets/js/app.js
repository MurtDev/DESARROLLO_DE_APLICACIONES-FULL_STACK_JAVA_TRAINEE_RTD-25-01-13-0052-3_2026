//Recuperar valor de input oculto
const hayEstudiante = document.getElementById("hayEstudiante").value;
console.log(hayEstudiante);

//Si el formulario fue enviado con datos
if (hayEstudiante === "true") {
    //Buscamos el modal
    const elementoModal = document.querySelector("#modalDatosEstudiante");

    //const elementoModal = document.getElementById("modalDatosEstudiante");

    //Creamos el modal new bootstrap.Modal
    const modal = new bootstrap.Modal(elementoModal);

    //Mostrar el modal
    modal.show();
}

