<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>


<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Mi primera JSP</title>

<link
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
	rel="stylesheet"
	integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB"
	crossorigin="anonymous">

</head>
<body class="text-bg-dark">
	<!-- Barra de navegación -->
	<nav class="navbar bg-primary" data-bs-theme="dark">
		<div class="container">
			<span>Aplicación Java Web</span>
		</div>
	</nav>

	<!-- Contenido principal -->
	<div class="container mt-5">
		<div class="row justify-content-center">
			<div class="col-md-6">
				<!-- Tarjeta o card -->
				<div class="card">
					<div class="card-body">
						<h2 class="text-center">Mi primera página JSP</h2>
						<%
						java.util.Date fecha = new java.util.Date();
						%>
						<p class="text-center">
							Fecha actual:
							<%=java.text.DateFormat.getDateInstance().format(fecha)%>
						</p>
						<!-- Formulario -->
						<form action="index.jsp" method="POST">
							<div class="mb-3">
								<label class="form-lable">Nombre</label> <input type="text"
									class="form-control" name="nombre" required>
							</div>
							<div class="mb-3">
								<label class="form-lable">Correo</label> <input type="email"
									class="form-control" name="correo" required>
							</div>
							<div class="mb-3">
								<label class="form-lable">Curso</label> <select
									class="form-select" name="curso" required>
									<option value="">Selecione un curso...</option>
									<option value="Java">Java</option>
									<option value="Python">Python</option>
									<option value="Php">Php</option>
								</select>
							</div>

							<button type="submit" class="btn btn-primary">Registrar</button>

						</form>
					</div>
				</div>

			</div>
		</div>
	</div>

	<div class="modal fade" id="modalDatosEstudiante" tabindex="-1" aria-labelledby="modalDatosEstudiante" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Datos Estudiante</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal"
						aria-label="Close"></button>
				</div>
				<div class="modal-body">
					<p>Nombre: ${param.nombre}</p>
					<p>Correo: ${param.correo}</p>
					<p>Curso: ${param.curso}</p>
				</div>
				<!--
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary"
						data-bs-dismiss="modal">Close</button>
					<button type="button" class="btn btn-primary">Save changes</button>
				</div>
				 -->
			</div>
		</div>
	</div>
	
	<!-- Detectar si llegarón los datos               retorna true o false      --> 
	<input type="hidden" id="hayEstudiante" value="${ not empty param.nombre }">
	
	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
		crossorigin="anonymous"></script>
	
	<script src="./assets/js/app.js" type="text/javascript"></script>
	
</body>
</html>