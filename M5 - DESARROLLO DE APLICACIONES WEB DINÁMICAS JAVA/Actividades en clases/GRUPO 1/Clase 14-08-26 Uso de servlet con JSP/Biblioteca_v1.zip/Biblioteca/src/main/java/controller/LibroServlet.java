package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;

import model.Libro;


/**
 * Servlet implementation class LibroServlet
 */
@WebServlet("/libros")
public class LibroServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /*
     doGet() --> HTTP GET 
      
      1. /libros
      2. /libros?buscar=java
      
     */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1. Verificar sesión
		/*
		  request.getSession(false)
		  
		  Dame la session existente,
		  pero NO me crees una nueva
		 */
		HttpSession session = request.getSession(false);
		
		if (session == null || session.getAttribute("usuario") == null) {
			//se construye la ruta desde la raíz de la aplicación web, 
			//por lo que suele ser más seguro usar request.getContextPath() + "/index.jsp".
			response.sendRedirect(request.getContextPath() + "/index.jsp");
			return;
		}
		
		//2. Recuperar datos (Libros)
		ArrayList<Libro> libros = new ArrayList();
		
		libros.add(
					new Libro(
							1, 
							"Clean Code", 
							"Robert Cecil Martin.", 
							"852741963", 
							true
							)
				);
		
	     libros.add(
	                new Libro(
	                        2,
	                        "Effective Java",
	                        "Joshua Bloch",
	                        "9780134685991",
	                        true
	                )
	        );
	     
	     libros.add(
	                new Libro(
	                        3,
	                        "Head First Java",
	                        "Kathy Sierra",
	                        "9781491910771",
	                        false
	                )
	        );
		
	       libros.add(
	                new Libro(
	                        4,
	                        "Java: The Complete Reference",
	                        "Herbert Schildt",
	                        "9781260463415",
	                        true
	                )
	        );
	}

	
	//TODO: se puede usar para agregar un libro
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
