<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<%@ page import="java.text.DateFormat"%>
<%@ page import="java.util.Date"%>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<link
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
	rel="stylesheet"
	integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB"
	crossorigin="anonymous">

<title>Mi primera web JSP</title>
</head>
<body>
	<!-- Barra de navegación -->
	<nav class="navbar bg-dark border-bottom border-body"
		data-bs-theme="dark">
		<div class="container">
			<!-- Navbar content -->
			<span class="navbar-brand">Aplicación Java Web</span>
		</div>
	</nav>

	<!-- Contenido principal -->
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-6">
				<div class="card shadow">
					<div class="card-body">
						<h5 class="card-title">Formulario</h5>
						<%
						Date fechaActual = new Date();
						%>
						<p>
							Fecha Actual:
							<%=java.text.DateFormat.getDateInstance().format(fechaActual)%></p>
						<!-- Formulario -->
						<form action="index.jsp" method="GET">
							<div class="mb-3">
								<label class="form-label">Nombre</label> <input
									class="form-control" type="text" name="nombre" required>
							</div>
							<div class="mb-3">
								<label class="form-label">Correo</label> <input
									class="form-control" type="email" name="correo" required>
							</div>
							<div class="mb-3">
								<label class="form-label">Curso</label> <select
									class="form-select" name="curso" required>
									<option value="">Selecione una opción...</option>
									<option value="Java">Java</option>
									<option value="Python">Python</option>
									<option value="JavaScript">JavaScript</option>
								</select>
							</div>

							<button type="submit" class="btn btn-primary">Registrar</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Detectar si llagan los datos -->
	<input type="hidden" id="hayDatos" value="${ not empty param.nombre }">

	<!-- Modal con la información de registro -->
	<div class="modal fade" id="modalEstudiante" tabindex="-1"
		aria-labelledby="modalEstudianteLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Estudiante Registrado</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal"
						aria-label="Close"></button>
				</div>
				<div class="modal-body">
					<p>Nombre: ${ param.nombre }</p>
					<p>Correo: ${ param.correo }</p>
					<p>Curso: ${ param.curso }</p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary"
						data-bs-dismiss="modal">Close</button>
					<button type="button" class="btn btn-primary">Save changes</button>
				</div>
			</div>
		</div>
	</div>

	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
		crossorigin="anonymous"></script>

	<script>
		const hayEstudiante = document.getElementById("hayDatos").value;
		console.log(hayEstudiante);

		if (hayEstudiante) {
			const elementoModal = document.getElementById("modalEstudiante");
			const modal = new bootstrap.Modal(elementoModal);

			modal.show();
		}
	</script>


</body>
</html>