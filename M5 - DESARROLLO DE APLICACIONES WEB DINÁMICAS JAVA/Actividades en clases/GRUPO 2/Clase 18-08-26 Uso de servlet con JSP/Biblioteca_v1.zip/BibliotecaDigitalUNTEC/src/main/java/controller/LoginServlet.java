package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;


import model.Usuario;
import jakarta.servlet.http.HttpSession;


/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Paso 1: recuperar los párametros del formulario
		String correo = request.getParameter("correo");
		String password = request.getParameter("password");
		
		//Paso 2: Validación básica
		if(correo == null || correo.isBlank() || password ==null || password.isBlank()) {
			request.setAttribute("error", "Debe completar todos los campos");
			request.getRequestDispatcher("/index.jsp").forward(request, response);
			return;
		}
		
		//Paso 3: validar  al usuario
		if(correo.equals("admin@untec.cl") && password.equals("1234")) {
			Usuario usuario = new Usuario(1, "Administrador UNTEC", correo, "ADMIN");
			
			//Paso 4: Crear la sesión
			HttpSession session =  request.getSession();
			session.setAttribute("usuario",usuario);
			
			//redireccionamos
			response.sendRedirect(request.getContextPath()+ "/libros");
			
		}else {
			request.setAttribute("error", "Correo o contraseña incorrectos");
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		}
		
	
	
	}

}
