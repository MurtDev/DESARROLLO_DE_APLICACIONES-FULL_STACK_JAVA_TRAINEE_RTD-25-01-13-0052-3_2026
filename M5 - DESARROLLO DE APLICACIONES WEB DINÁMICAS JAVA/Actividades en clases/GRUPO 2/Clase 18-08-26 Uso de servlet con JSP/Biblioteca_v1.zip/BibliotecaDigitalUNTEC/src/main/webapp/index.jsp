<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.functions" prefix="fn" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Biblioteca Digital UNTEC</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">

</head>
<body>
			<!-- Contenido principal -->
	<div class="container mt-5">
		<div class="row justify-content-center">
			<div class="col-md-5">
				<div class="card shadow p-4">
					<div class="card-body">
						<h4 class="card-title text-center mb-2">Biblioteca Digital UNTEC</h4>
						<p class="text-center text-muted mb-4">Iniciar sesión</p>
						
						<%-- 
						     Si LoginServlet envía un atributo 
						     llamado "error" mostramos el mensaje de alerta 
						--%>
						
						<c:if test="${ not empty error }">
							<div class="alert alert-danger" role="alert">
    							<c:out  value="${ error }" />
							</div>
						</c:if>
		
						<!-- Formulario -->
						<form action="${pageContext.request.contextPath}/login" method="POST">
							<div class="mb-3">
								<label class="form-label">Correo</label> <input
									class="form-control" type="text" name="correo">
							</div>
							<div class="mb-3">
								<label class="form-label">Contraseña</label> 
								<input class="form-control" type="password" name="password">
							</div>
							

							<button type="submit" class="btn btn-primary w-100">Ingresar</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>

</body>
</html>