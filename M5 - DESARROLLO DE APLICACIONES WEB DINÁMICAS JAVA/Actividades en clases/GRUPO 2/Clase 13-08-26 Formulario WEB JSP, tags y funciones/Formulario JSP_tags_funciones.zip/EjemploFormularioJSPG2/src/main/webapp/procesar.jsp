<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%-- 
------------------
 JSTL FUNCTIONS
------------------

El prefijo "fn" no permitira utilizar funciones sobre Strings y colecciones:

fn: length()
fn: toUpperCase()
fn: contains()
fn: replace()

etc.
 --%>

<%@ taglib uri="jakarta.tags.functions" prefix="fn" %>

<%-- 
------------------
    JSTL CORE
------------------

El prefijo "c" nos permitirá utiliizar:

c:set
c:out
c:if
c:choose
c:when
c:forEach
etc.

--%>

<%@ taglib uri="jakarta.tags.core" prefix="c" %>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
<title>Resultado estudiantes</title>
</head>
<body>
<!-- Barra de navegación -->
	<nav class="navbar bg-dark border-bottom border-body" data-bs-theme="dark">
		<div class="container">
			<!-- Navbar content -->
			<span class="navbar-brand">Aplicación Java Web</span>
		</div>
	</nav>
		<!-- Contenido principal -->
	<div class="container mt-5">
		<div class="row justify-content-center">
			<div class="col-md-6">
				<div class="card shadow p-4">
					<div class="card-body">
						<h4 class="card-title">Resultado de estudiantes</h4>
						
						<c:set var="nombreMayuscula" value="${ fn:toUpperCase(param.nombre) }"/>
						
						<div class="mb-3">
							<strong>Nombre: </strong>
							<c:out value="${ nombreMayuscula }" default="Nombre no informado"></c:out>
						</div>
						<div class="mb-3">
							<strong>Edad: </strong>
							<c:out value="${ param.edad }"></c:out>
						</div>
						
						<div class="mb-3">
							<strong>Curso: </strong>
							<c:out value="${ param.curso }"></c:out>
						</div>
						
						<hr>
						
						<p>
							El nombre del estudiante tiene
							<strong>
								<c:out value="${ fn:length(param.nombre) }"/>
							</strong>
							caracteres.
						</p>
						
						<c:if test="${!fn:contains(param.correo, '@')}">
							<div class="alert alert-danger" role="alert">
    							El correo ingresado no es válido porque le falta el signo @.
							</div>
						</c:if>
						
						
						<c:if test="${ fn:contains(param.correo, '@') }">
							<div class="alert alert-success" role="alert">
							  El correo contiene el @!
							</div>
						</c:if>	
						
						<c:if test="${ param.edad >= 18 }">
							<div class="alert alert-success" role="alert">
							  Bienvenido 
							  <strong>
								<c:out value="${ param.nombre }"/>
							  </strong>
							  , eres mayor de edad.
							</div>
						</c:if>
						
						<hr>
						
						<h4>Clasificación por edad</h4>
						
						<c:choose>
							<%-- Primera condición --%>
							<c:when test="${ param.edad < 18 }">
								<div class="alert alert-warning" role="alert">
									Estudiante menor de edad.
								</div>
							</c:when>
							
							<%-- Segunda condición --%>
							<c:when test="${ param.edad < 40 }">
								<div class="alert alert-info" role="alert">
									Estudiante es adulto joven.
								</div>
							</c:when>
							
							<c:otherwise>
								<div class="alert alert-secondary" role="alert">
									Estudiante es adulto.
								</div>
							</c:otherwise>
						</c:choose>
						
						<hr>
						<h4>Áreas de interés</h4>
						<c:if test="${ empty paramValues.intereses }">
							<div class="alert alert-danger" role="alert">
    							No se selecionaron áreas de interés.
							</div>
						</c:if>
						
						<ul class="list-group">
							<c:forEach var="interes" items="${ paramValues.intereses }">
								
								<li class="list-group-item">
									<strong class="badge text-bg-primary text-wrap">
									<c:out value="${ interes }"/>
									</strong>
								</li>
							
							</c:forEach>
						</ul>
						
						<a class="btn btn-primary mt-3 w-100" href="index.jsp">
							Registrar otro estudiante
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>

</body>
</html>