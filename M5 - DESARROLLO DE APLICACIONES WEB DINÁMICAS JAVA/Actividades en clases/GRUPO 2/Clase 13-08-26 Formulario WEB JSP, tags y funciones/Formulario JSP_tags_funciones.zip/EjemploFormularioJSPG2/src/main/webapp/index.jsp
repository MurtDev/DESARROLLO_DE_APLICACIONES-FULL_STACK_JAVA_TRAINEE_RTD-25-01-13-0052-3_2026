<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">

<title>Registro estudiantes</title>
</head>
<body>
    <!-- Barra de navegación -->
	<nav class="navbar bg-dark border-bottom border-body" data-bs-theme="dark">
		<div class="container">
			<!-- Navbar content -->
			<span class="navbar-brand">Aplicación Java Web</span>
		</div>
	</nav>
		<!-- Contenido principal -->
	<div class="container mt-5">
		<div class="row justify-content-center">
			<div class="col-md-5">
				<div class="card shadow p-4">
					<div class="card-body">
						<h4 class="card-title">Registro de estudiantes</h4>
						
						<!-- Formulario -->
						<form action="procesar.jsp" method="POST">
							<div class="mb-3">
								<label class="form-label">Nombre</label> 
								<input class="form-control" type="text" name="nombre" required>
							</div>
							<div class="mb-3">
								<label class="form-label">Edad</label> 
								<input class="form-control" type="number" name="edad" required>
							</div>
							
							<div class="mb-3">
								<label class="form-label">Correo</label> <input
									class="form-control" type="text" name="correo" required>
							</div>
							<div class="mb-3">
								<label class="form-label">Curso</label> <select
									class="form-select" name="curso" required>
									<option value="">Selecione una opción...</option>
									<option value="Java">Java</option>
									<option value="Python">Python</option>
									<option value="JavaScript">JavaScript</option>
								</select>
							</div>
							<div class="mb-3">
								<label class="form-label">Áreas de interés</label> 
								<div class="form-check">
									<input 
										id="backend" 
										class="form-check-input" 
										type="checkbox" 
										name="intereses" 
										value="Backend">
									<label class="form-check-label" for="backend">Backend</label>
								</div>
								<div class="form-check">
									<input 
										id="frontend" 
										class="form-check-input" 
										type="checkbox" 
										name="intereses" 
										value="Frontend">
									<label class="form-check-label" for="frontend">Frontend</label>
								</div>
								<div class="form-check">
									<input 
										id="java" 
										class="form-check-input" 
										type="checkbox" 
										name="intereses" 
										value="Java">
									<label class="form-check-label" for="java">Java</label>
								</div>
							</div>

							<button type="submit" class="btn btn-primary w-100">Registrar</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>

</body>
</html>